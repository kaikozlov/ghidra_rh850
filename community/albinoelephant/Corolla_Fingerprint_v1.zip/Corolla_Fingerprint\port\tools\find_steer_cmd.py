#!/usr/bin/env python3
"""Find the TSS3 steering command by correlating CAN fields vs measured steer angle.

During stock LTA, the commanded steer angle tracks the measured angle. So a
16-bit signed field somewhere carries the command and correlates strongly with
carState.steeringAngleDeg. Scans every byte offset on the given buses, ranks by
|r|, and flags known feedback messages so we can spot the COMMAND.

    python find_steer_cmd.py rlog... 
"""
import sys, math, bisect
from collections import defaultdict

def s16be(d, i):
    if i + 1 >= len(d): return None
    v = (d[i] << 8) | d[i+1]
    return v - 0x10000 if v >= 0x8000 else v

def main(paths):
    from openpilot.tools.lib.logreader import LogReader as OP
    from opendbc.car.logreader import LogReader as CAN
    # measured steering angle timeline
    ang=[]; t0=None
    for p in paths:
        for m in OP(p):
            if m.which()=="carState":
                t=m.logMonoTime/1e9
                if t0 is None: t0=t
                ang.append((t-t0, m.carState.steeringAngleDeg))
    at=[a[0] for a in ang]
    def ang_at(tq):
        i=bisect.bisect_left(at,tq); b=None
        for j in (i-1,i):
            if 0<=j<len(ang) and abs(ang[j][0]-tq)<0.05:
                if b is None or abs(ang[j][0]-tq)<abs(ang[b][0]-tq): b=j
        return ang[b][1] if b is not None else None
    # gather CAN frames per (bus,addr)
    frames=defaultdict(list); t0b=None
    for p in paths:
        for m in CAN(p, only_union_types=True):
            if m.which()!="can": continue
            t=m.logMonoTime/1e9
            if t0b is None: t0b=t
            for c in m.can:
                if c.src in (0,1,2): frames[(c.src,c.address)].append((t-t0b, bytes(c.dat)))
    # only bother if the angle actually moved
    amax=max(abs(a) for _,a in ang) if ang else 0
    print(f"carState angle samples {len(ang)}, |angle| max {amax:.0f} deg")
    known={0x8A,0x30,0xDA,0x25}  # steer feedback we already decoded (exclude)
    results=[]
    for (bus,addr),fr in frames.items():
        if len(fr)<200: continue
        dlc=min(len(d) for _,d in fr)
        n=len(fr)
        ys=[]; xs_by_off=defaultdict(list)
        for t,d in fr:
            a=ang_at(t)
            if a is None: continue
            ys.append(a)
            for off in range(dlc-1):
                xs_by_off[off].append(s16be(d,off))
        if len(ys)<200: continue
        my=sum(ys)/len(ys); syy=sum((y-my)**2 for y in ys)
        if syy<=0: continue
        for off,xs in xs_by_off.items():
            if any(x is None for x in xs) or len(set(xs))<8: continue
            mx=sum(xs)/len(xs); sxx=sum((x-mx)**2 for x in xs)
            if sxx<=0: continue
            r=sum((x-mx)*(y-my) for x,y in zip(xs,ys))/math.sqrt(sxx*syy)
            if abs(r)>0.6: results.append((abs(r),r,bus,addr,off,min(xs),max(xs)))
    results.sort(reverse=True)
    print(f"\n{'|r|':>5} {'bus':>3} {'addr':>7} {'byte':>4} {'range':>16}  note")
    seen=set()
    for _,r,bus,addr,off,lo,hi in results[:30]:
        k=(bus,addr,off//2)
        note=""
        if addr in known: note="(known steer feedback)"
        print(f"{abs(r):5.2f} {bus:3d} {addr:#07x} {off:4d}  {lo:7d}..{hi:<7d} {r:+.2f} {note}")
    return 0

if __name__=="__main__":
    sys.exit(main(sys.argv[1:]))
