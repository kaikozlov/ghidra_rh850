import glob
from openpilot.tools.lib.logreader import LogReader
notrunning=set(); last=None
for s in sorted(glob.glob("/data/media/0/realdata/00000022--6299eff795--*/rlog.zst")):
    for m in LogReader(s):
        if m.which()=="managerState":
            for p in m.managerState.processes:
                if p.shouldBeRunning and not p.running:
                    notrunning.add(p.name)
print("processes shouldBeRunning but NOT running:", sorted(notrunning))
