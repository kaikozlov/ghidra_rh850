#!/usr/bin/env python3
"""Validate the 0x160 E2E counter openpilot transmits is +1 continuous at ~40Hz.

Replays a realistic timing mismatch: the camera advances its byte-2 counter at
40 Hz while openpilot's carcontroller runs at 100 Hz. The old code re-seeded the
counter every cycle and sent at 50 Hz, producing ~20% duplicate counters that
the gateway rejected (the "System Malfunction"). This asserts the new logic emits
exactly one frame per camera frame, with the counter advancing by exactly +1 and
a valid E2E CRC.

    PYTHONPATH=$PWD python test_counter_continuity.py
"""
import sys
from opendbc.car import structs
from opendbc.car.toyota.carcontroller import CarController
from opendbc.car.toyota.carstate import CarState
from opendbc.car.toyota.interface import CarInterface
from opendbc.car.toyota.values import CAR, DBC, TSS3LongMode
from opendbc.car.toyota.e2e import e2e_160_valid, apply_e2e_160
import opendbc.car.toyota.carcontroller as ccmod
import opendbc.car.toyota.interface as imod

PLATFORM = "TOYOTA_COROLLA_TSS3"


def main():
  imod.TSS3_LONG_MODE = TSS3LongMode.LIVE
  ccmod.TSS3_LONG_MODE = TSS3LongMode.LIVE
  CP = CarInterface.get_params(PLATFORM, {i: {} for i in range(8)}, [], alpha_long=True, is_release=False, docs=False)
  CarInterface.get_params_sp(CP, PLATFORM, {i: {} for i in range(8)}, [], True, False, False)
  CP.wheelSpeedFactor = 1.0
  CP_SP = structs.CarParamsSP()

  cc = CarController(DBC[PLATFORM], CP, CP_SP)
  cc.CP = CP

  # a fake CarState carrying the template + gates
  cs = CarState(CP, CP_SP)
  cs.tss3_stock_lon_active = True
  out = structs.CarState(vEgo=10.0)      # above TSS3_MIN_OVERRIDE_SPEED
  out.cruiseState.enabled = True         # == panda controls_allowed source
  out.gasPressed = False
  cs.out = out

  # base 32-byte camera frame (constants set); byte2 is the camera counter
  base = bytearray(32)
  base[3] = 0x82; base[6] = 0x40; base[15] = 0x80; base[16] = 0x02

  emitted = []
  cam_counter = 100
  cam_accum = 0.0
  CAM_HZ, LOOP_HZ = 40.0, 100.0
  for i in range(1000):  # 10s at 100Hz
    # advance the camera counter at 40Hz relative to the 100Hz loop
    cam_accum += CAM_HZ / LOOP_HZ
    if cam_accum >= 1.0:
      cam_accum -= 1.0
      cam_counter = (cam_counter + 1) & 0xFF
    frame = bytearray(base)
    frame[2] = cam_counter
    # give the camera a plausible accel so the template is realistic
    frame[4] = 0x80; frame[5] = 0x10
    cs.tss3_accel_template = apply_e2e_160(bytes(frame))  # valid camera frame

    CC = structs.CarControl()
    CC.enabled = CC.latActive = CC.longActive = True
    CC.actuators.accel = -0.7
    _, sends = cc.update(CC.as_reader(), structs.CarControlSP(), cs, i * 10_000_000)
    for m in sends:
      if m[0] == 0x160:
        emitted.append(bytes(m[1]))

  n = len(emitted)
  dur = 1000 / LOOP_HZ
  rate = n / dur
  counters = [d[2] for d in emitted]
  breaks = sum(1 for a, b in zip(counters, counters[1:]) if (a + 1) & 0xFF != b)
  valid = sum(1 for d in emitted if e2e_160_valid(d))

  print(f"emitted 0x160        : {n} over {dur:.1f}s -> {rate:.1f} Hz  (want ~40)")
  print(f"counter breaks (!=+1): {breaks}  (want 0)")
  print(f"E2E CRC valid        : {valid}/{n}  (want {n})")
  print(f"first counters       : {counters[:15]}")

  # the emitted counter must equal the CAMERA's own counter each frame -- that is
  # what makes override<->passthrough handoffs seamless. Since the test camera
  # starts at 100 and advances +1, the first emitted counter should be 101.
  starts_at_camera = counters[0] == 100
  print(f"first emitted counter: {counters[0]}  (want 100 = camera value)")

  ok = (abs(rate - 40) < 3) and breaks == 0 and valid == n and n > 300 and starts_at_camera
  print("\nPASS" if ok else "\nFAIL")
  return 0 if ok else 1


if __name__ == "__main__":
  sys.exit(main())
