#!/usr/bin/env python3
"""Which angle-tracking field LEADS the measured angle -> the steering COMMAND.
Feedback is in lock-step (best r at lag 0); a command leads (best r at the field
preceding the angle). Tests candidates at time shifts; also reports msg length."""
import sys, bisect, math
from collections import defaultdict

CANDS=[(1,0x371,16),(0,0x1a0,11),(1,0x81,16),(1,0x90,12),(1,0x8A,18)]  # 0x8A = feedback ref

def s16be(d,i):
    if i+1>=len(d): return None
    v=(d[i]<<8)|d[i+1]; return v-0x10000 if v>=0x8000 else v

def corr(xs,ys):
    n=len(xs)
    if n<50: return float('nan')
    mx=sum(xs)/n;my=sum(ys)/n
    sxx=sum((x-mx)**2 for x in xs);syy=sum((y-my)**2 for y in ys)
    return sum((x-mx)*(y-my) for x,y in zip(xs,ys))/math.sqrt(sxx*syy) if sxx>0 and syy>0 else float('nan')

def main(paths):
    from openpilot.tools.lib.logreader import LogReader as OP
    from opendbc.car.logreader import LogReader as CAN
    ang=[];t0=None
    for p in paths:
        for m in OP(p):
            if m.which()=="carState":
                t=m.logMonoTime/1e9
                if t0 is None:t0=t
                ang.append((t-t0,m.carState.steeringAngleDeg))
    at=[a[0] for a in ang]
    def ang_at(tq):
        i=bisect.bisect_left(at,tq)
        for j in (i-1,i):
            if 0<=j<len(ang) and abs(ang[j][0]-tq)<0.05: return ang[j][1]
        return None
    frames=defaultdict(list);lens={};t0b=None
    want={a for _,a,_ in CANDS}
    for p in paths:
        for m in CAN(p,only_union_types=True):
            if m.which()!="can": continue
            t=m.logMonoTime/1e9
            if t0b is None:t0b=t
            for c in m.can:
                if c.address in want and c.src in (0,1,2):
                    frames[(c.src,c.address)].append((t-t0b,bytes(c.dat)));lens[(c.src,c.address)]=len(bytes(c.dat))
    print("field                 best_lag(ms)  r@best   (neg lag => field LEADS angle => COMMAND)")
    for bus,addr,off in CANDS:
        fr=frames.get((bus,addr))
        if not fr: continue
        best=(0,-9)
        for lag_ms in range(-400,401,50):
            lag=lag_ms/1000.0
            xs=[];ys=[]
            for t,d in fr:
                a=ang_at(t+lag)   # compare field(t) with angle(t+lag): if lag>0, angle later => field leads
                v=s16be(d,off)
                if a is None or v is None: continue
                xs.append(v);ys.append(a)
            r=corr(xs,ys)
            if not math.isnan(r) and abs(r)>abs(best[1]): best=(lag_ms,r)
        lead="LEADS (command?)" if best[0]>50 else ("lockstep (feedback)" if abs(best[0])<=50 else "lags")
        print(f"bus{bus} {addr:#07x} b{off} len{lens[(bus,addr)]:>2}   {best[0]:+5d}      {best[1]:+.2f}   {lead}")
    return 0

if __name__=="__main__":
    sys.exit(main(sys.argv[1:]))
