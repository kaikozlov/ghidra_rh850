#!/usr/bin/env python3
"""Map every varying byte of 0x160 against ACC state, decoded from 0x13C.

For each 0x160 frame, find the nearest 0x13C (bus 1) sample and label it with
the stock system's state at that instant:
    OFF      no LON_ACTIVE recently
    ACTIVE   0x13C LON_ACTIVE set
Then, per candidate byte, show the value distribution in each state. A control
bit shows a clean split; a data byte does not.

    python map_160_fields.py rlog... 
"""
import sys
import glob
import bisect
from collections import defaultdict, Counter

from opendbc.car.logreader import LogReader

ADAS, PT, ADDR, ACC = 0, 1, 0x160, 0x13C
VARYING = [4, 5, 7, 8, 9, 10, 12, 13, 14, 17, 18, 19, 20, 21, 22, 23]


def main(paths):
    frames = []
    acc = []                      # (t, lon_active, accel, dist_active)
    t0 = None
    for p in paths:
        for m in LogReader(p, only_union_types=True):
            if m.which() != "can":
                continue
            t = m.logMonoTime / 1e9
            if t0 is None:
                t0 = t
            for c in m.can:
                if c.src == ADAS and c.address == ADDR:
                    frames.append((t - t0, bytes(c.dat)))
                elif c.src == PT and c.address == ACC:
                    d = bytes(c.dat)
                    if len(d) >= 8:
                        raw = (d[0] << 8) | d[1]
                        a = (raw - 0x10000 if raw >= 0x8000 else raw) * 0.001
                        acc.append((t - t0, bool(d[4] & 0x20), a, bool(d[4] & 0x08)))

    at = [x[0] for x in acc]
    labelled = []
    for t, d in frames:
        i = bisect.bisect_left(at, t)
        best = None
        for j in (i - 1, i):
            if 0 <= j < len(acc) and abs(at[j] - t) < 0.05:
                if best is None or abs(at[j] - t) < abs(at[best] - t):
                    best = j
        if best is not None:
            labelled.append((d, acc[best][1], acc[best][2], acc[best][3]))

    active = [x for x in labelled if x[1]]
    off = [x for x in labelled if not x[1]]
    print(f"labelled 0x160 frames: {len(labelled)}  (ACTIVE {len(active)}, OFF {len(off)})\n")

    print("=== byte value distribution: OFF vs ACTIVE ===")
    for i in VARYING:
        vo = Counter(d[i] for d, *_ in off)
        va = Counter(d[i] for d, *_ in active)
        so = set(vo)
        sa = set(va)
        only_off = so - sa
        only_act = sa - so
        tag = ""
        if only_act and not (sa & so):
            tag = "  <-- DISJOINT: pure state bit"
        elif only_act or only_off:
            tag = "  <- partial split"
        top_o = " ".join(f"{v:#04x}:{vo[v]}" for v in sorted(vo, key=lambda k: -vo[k])[:4])
        top_a = " ".join(f"{v:#04x}:{va[v]}" for v in sorted(va, key=lambda k: -va[k])[:4])
        print(f" byte {i:2d}:")
        print(f"    OFF    {top_o}")
        print(f"    ACTIVE {top_a}{tag}")

    # byte 7 state field vs distance-active (lead present)
    print("\n=== byte 7 vs stock DISTANCE_ACTIVE (lead engaged) ===")
    b7 = defaultdict(Counter)
    for d, la, a, da in active:
        b7[d[7]][("lead" if da else "nolead")] += 1
    for v in sorted(b7):
        print(f"  0x{v:02x}: {dict(b7[v])}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
