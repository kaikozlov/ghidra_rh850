import glob, bisect, math
from openpilot.tools.lib.logreader import LogReader as OP
from opendbc.car.logreader import LogReader as CAN
segs=sorted(glob.glob("/data/media/0/realdata/00000023--4b94a1ecef--*/rlog.zst"))
op=[]; meas=[]; t0=None
for s in segs:
    for m in OP(s):
        w=m.which(); t=m.logMonoTime/1e9
        if t0 is None: t0=t
        if w=="carControl":
            op.append((t-t0, m.carControl.actuators.steeringAngleDeg, bool(m.carControl.latActive)))
        elif w=="carState":
            meas.append((t-t0, m.carState.steeringAngleDeg))
gw=[]; t0b=None; reqset=0; gwn=0
for s in segs:
    for m in CAN(s, only_union_types=True):
        if m.which()!="can": continue
        t=m.logMonoTime/1e9
        if t0b is None: t0b=t
        for c in m.can:
            if c.src in (0,2) and c.address==0x1a0:
                d=bytes(c.dat); v=(d[11]<<8)|d[12]; v=v-0x10000 if v>=0x8000 else v
                gw.append((t-t0b, v*0.0148, (d[6]>>6)&1)); gwn+=1
                if (d[6]>>6)&1: reqset+=1
mt=[x[0] for x in meas]
def M(tq):
    i=min(bisect.bisect_left(mt,tq),len(meas)-1); return meas[i][1]
gt=[g[0] for g in gw]
def G(tq):
    i=min(bisect.bisect_left(gt,tq),len(gw)-1); return gw[i]
print("0x1A0 frames", gwn, "request-bit set", reqset, f"({100*reqset/max(gwn,1):.0f}%)")
lat=[o for o in op if o[2]]
print("op latActive frames", len(lat))
# correlate op desired vs gateway angle and vs measured, during op latActive
def corr(xs,ys):
    n=len(xs)
    if n<50: return float('nan'), n
    mx=sum(xs)/n; my=sum(ys)/n
    sxx=sum((x-mx)**2 for x in xs); syy=sum((y-my)**2 for y in ys)
    return (sum((x-mx)*(y-my) for x,y in zip(xs,ys))/math.sqrt(sxx*syy) if sxx>0 and syy>0 else float('nan')), n
xg=[];yg=[];xm=[];ym=[]
for t,a_op,la in lat:
    g=G(t)
    xg.append(g[1]); yg.append(a_op)
    xm.append(M(t)); ym.append(a_op)
rg,ng=corr(xg,yg); rm,nm=corr(xm,ym)
print(f"op desired vs GATEWAY 0x1A0 angle: r={rg:+.2f} n={ng}")
print(f"op desired vs MEASURED angle:      r={rm:+.2f} n={nm}")
if yg: print(f"op desired range {min(yg):+.1f}..{max(yg):+.1f}, gateway range {min(xg):+.1f}..{max(xg):+.1f}")
