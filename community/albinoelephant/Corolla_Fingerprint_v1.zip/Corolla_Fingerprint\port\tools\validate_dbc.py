#!/usr/bin/env python3
"""Run the TSS3 DBC through a real CANParser against a real rlog.

This is validation-gate step 2 (port doc section 9): prove the CAN FD parse path
loads and produces sane values BEFORE flashing anything. Every number in the DBC
is decoded from passive logs and has never executed on a car.

    python validate_dbc.py <route-or-rlog-path>

Checks, in order of how likely they are to fail:
  1. the DBC loads at all (CANParser raises if a message name is missing)
  2. each message is actually seen on bus 0
  3. decoded values sit in physically plausible ranges
  4. the two independently decoded steering angles (0x30 and 0x8A) agree --
     they are supposed to be the same physical value, so a mismatch means at
     least one bit position is wrong
  5. every 0x13C the CAR sent passes the Toyota checksum, and repacking it
     through CANPacker reproduces the original bytes -- that is the strongest
     available proof the 0x13C layout is right, short of transmitting

API verified against commaai/opendbc @ 3e92d11: CANParser.update() takes
[(nanos, [(addr, dat, src), ...])] and returns the set of updated addresses.
"""
import sys

from opendbc.can import CANParser, CANPacker

try:
    # opendbc ships its own reader: takes a plain rlog path or URL, no openpilot
    # dependency. Preferred.
    from opendbc.car.logreader import LogReader
except ImportError:  # pragma: no cover
    try:
        from openpilot.tools.lib.logreader import LogReader
    except ImportError:
        sys.exit("run this inside a sunnypilot/openpilot checkout, with the repo root "
                 "and opendbc_repo on PYTHONPATH")

DBC = "toyota_corolla_tss3_pt"

# float("nan") means "do not check liveness" -- see the carstate snippet.
MESSAGES = [
    ("WHEEL_SPEEDS", float("nan")),
    ("STEER_ANGLE_ACC_STATUS", float("nan")),
    ("STEER_ANGLE_SENSOR", float("nan")),
    ("KINEMATICS", float("nan")),
    ("STEER_TORQUE_SENSOR", float("nan")),
    ("BRAKE_MODULE", float("nan")),
    ("GEAR_PACKET", float("nan")),
    ("SECOC_SYNCHRONIZATION", float("nan")),
    ("ACC_CONTROL", float("nan")),
]

# (message, signal, plausible min, plausible max)
RANGES = [
    ("WHEEL_SPEEDS", "WHEEL_SPEED_FL", -1., 250.),
    ("WHEEL_SPEEDS", "WHEEL_SPEED_FR", -1., 250.),
    ("WHEEL_SPEEDS", "WHEEL_SPEED_RL", -1., 250.),
    ("WHEEL_SPEEDS", "WHEEL_SPEED_RR", -1., 250.),
    ("STEER_ANGLE_ACC_STATUS", "STEER_ANGLE", -600., 600.),
    ("STEER_ANGLE_SENSOR", "STEER_ANGLE", -600., 600.),
    ("KINEMATICS", "YAW_RATE", -100., 100.),
    ("BRAKE_MODULE", "BRAKE_PRESSED", 0., 1.),
    ("ACC_CONTROL", "ACCEL_CMD", -5., 5.),
]

ACC_CONTROL_ADDR = 0x13C


def toyota_checksum(addr: int, dat: bytes) -> int:
    s = len(dat)
    a = addr
    while a:
        s += a & 0xFF
        a >>= 8
    return (s + sum(dat[:-1])) & 0xFF


def main(route):
    cp = CANParser(DBC, MESSAGES, 0)
    packer = CANPacker(DBC)
    print(f"DBC {DBC} loaded, {len(cp.addresses)} addresses")

    seen = {name: 0 for name, _ in MESSAGES}
    by_addr = {}
    for name, _ in MESSAGES:
        by_addr[cp.dbc.name_to_msg[name].address] = name

    out_of_range: dict[str, tuple[float, float]] = {}
    angle_pairs = []
    prev_angle = [None]
    acc_total = acc_checksum_ok = acc_repack_ok = 0
    frames = 0

    for msg in LogReader(route, only_union_types=True):
        if msg.which() != "can":
            continue
        can = [(c.address, c.dat, c.src) for c in msg.can]
        updated = cp.update([(msg.logMonoTime, can)])
        frames += 1

        for addr in updated:
            if addr in by_addr:
                seen[by_addr[addr]] += 1

        for m, s, lo, hi in RANGES:
            v = cp.vl[m][s]
            if not lo <= v <= hi:
                prev = out_of_range.get(f"{m}.{s}", (v, v))
                out_of_range[f"{m}.{s}"] = (min(prev[0], v), max(prev[1], v))

        # Only compare when the wheel is moving SLOWLY. 0x8A is 40 Hz and 0x30
        # is ~33 Hz, so they are sampled at different instants; at 300 deg/s a
        # 25 ms offset alone accounts for 7.5 deg. Measured on a real drive:
        # 0.12 deg median when calm, 10.3 deg median when slewing fast. The
        # disagreement is timing, not bit positions.
        ang = cp.vl["STEER_ANGLE_ACC_STATUS"]["STEER_ANGLE"]
        slew = abs(ang - prev_angle[0]) / 0.025 if prev_angle[0] is not None else 0.0
        prev_angle[0] = ang
        if slew < 50 and {"STEER_ANGLE_ACC_STATUS", "STEER_ANGLE_SENSOR"} <= set(
                by_addr[a] for a in updated if a in by_addr):
            angle_pairs.append((ang, cp.vl["STEER_ANGLE_SENSOR"]["STEER_ANGLE"]))

        # Round-trip the car's own ACC_CONTROL frames through our DBC.
        for addr, dat, src in can:
            if addr != ACC_CONTROL_ADDR or src != 0 or len(dat) != 8:
                continue
            acc_total += 1
            if dat[7] == toyota_checksum(addr, dat):
                acc_checksum_ok += 1
            v = cp.vl["ACC_CONTROL"]
            _, repacked, _ = packer.make_can_msg("ACC_CONTROL", 0, {
                "ACCEL_CMD": v["ACCEL_CMD"],
                "BYTE2_FLAGS": v["BYTE2_FLAGS"],
                "LON_BASE": v["LON_BASE"],
                "LON_ACTIVE": v["LON_ACTIVE"],
                "DISTANCE_ACTIVE": v["DISTANCE_ACTIVE"],
            })
            if bytes(repacked) == bytes(dat):
                acc_repack_ok += 1

    print(f"\n{frames} can events\n")
    ok = True
    for name, n in seen.items():
        if not n:
            ok = False
        print(f"  {'ok ' if n else 'MISSING'} {name:<26} {n} updates")

    if out_of_range:
        ok = False
        print("\nOUT OF PLAUSIBLE RANGE (bit position or factor is wrong):")
        for k, (lo, hi) in out_of_range.items():
            print(f"  {k}: observed {lo:.2f} .. {hi:.2f}")

    if angle_pairs:
        diffs = [abs(a - b) for a, b in angle_pairs]
        print(f"\n0x8A vs 0x30 steering angle: mean |diff| {sum(diffs)/len(diffs):.2f} deg, "
              f"worst {max(diffs):.2f} deg")
        if max(diffs) > 5.:   # calm-steering samples only
            ok = False
            print("  -> these should be the SAME physical angle. A large diff means at least")
            print("     one of the two bit positions (byte 18-19 / byte 20-21) is wrong.")

    if acc_total:
        print(f"\n0x13C ACC_CONTROL: {acc_total} frames from the car")
        print(f"  checksum verified: {acc_checksum_ok}/{acc_total}")
        print(f"  byte-exact repack: {acc_repack_ok}/{acc_total}")
        if acc_repack_ok < acc_total:
            ok = False
            print("  -> repack mismatch means the DBC does not account for every bit the car")
            print("     sets. Diff a failing frame before enabling longitudinal.")
    else:
        print("\n0x13C ACC_CONTROL: not present in this log (was ACC ever on?)")

    print("\nRESULT:", "parse path looks sane -- still must be checked on the car" if ok else "FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
