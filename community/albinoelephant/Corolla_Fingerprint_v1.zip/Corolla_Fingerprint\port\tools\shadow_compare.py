#!/usr/bin/env python3
"""Compare openpilot's INTENDED longitudinal accel against the stock system's.

This is port doc section 12.4, the zero-risk validation of the whole longitudinal
command path. In TSS3_LONG_MODE = SHADOW openpilot runs its longitudinal planner
and logs what it wanted, while safety stays noOutput so nothing is transmitted
and the factory ACC actually drives the car. If openpilot's intent tracks the
stock 0x13C.ACCEL_CMD, the planner and the command construction are sane.

    python shadow_compare.py rlog1.zst [rlog2.zst ...]

Reads:
  carControl.actuators.accel   openpilot's intended accel  (m/s^2)
  0x13C ACCEL_CMD              what the stock ACC actually commanded (m/s^2)

Only samples where the STOCK system was actively controlling (0x13C LON_ACTIVE)
are compared -- openpilot's plan is meaningless when the car isn't under ACC.
"""
import sys
import math

try:
    from opendbc.car.logreader import LogReader
except ImportError as e:  # pragma: no cover
    sys.exit(f"need opendbc importable: {e}")


def main(paths):
    stock = []      # (t, accel, lon_active)
    op = []         # (t, accel)
    t0 = None

    for path in paths:
        for msg in LogReader(path, only_union_types=True):
            w = msg.which()
            t = msg.logMonoTime / 1e9
            if t0 is None:
                t0 = t
            if w == "can":
                for c in msg.can:
                    if c.src != 0 or c.address != 0x13C:
                        continue
                    d = bytes(c.dat)
                    if len(d) < 8:
                        continue
                    raw = (d[0] << 8) | d[1]
                    if raw >= 0x8000:
                        raw -= 0x10000
                    stock.append((t - t0, raw * 0.001, bool(d[4] & 0x20)))
            elif w == "carControl":
                cc = msg.carControl
                try:
                    op.append((t - t0, cc.actuators.accel, bool(cc.longActive)))
                except Exception:
                    pass

    if not stock:
        sys.exit("no 0x13C frames found -- wrong bus or not an rlog?")
    if not op:
        print("NO carControl MESSAGES FOUND.")
        print("openpilot was not running its longitudinal planner. Check that:")
        print("  - TSS3_LONG_MODE is SHADOW or LIVE in toyota/values.py")
        print("  - AlphaLongitudinalEnabled param is 1 (read at car start, so it")
        print("    needs an ignition cycle after you change it)")
        print("  - the car fingerprinted as TOYOTA_COROLLA_TSS3, not MOCK")
        return 1

    # nearest-neighbour align openpilot samples onto stock samples
    op.sort()
    ot = [o[0] for o in op]
    import bisect
    pairs = []
    for t, a_stock, active in stock:
        if not active:
            continue
        i = bisect.bisect_left(ot, t)
        best = None
        for j in (i - 1, i):
            if 0 <= j < len(op) and abs(op[j][0] - t) < 0.15:
                if best is None or abs(op[j][0] - t) < abs(op[best][0] - t):
                    best = j
        if best is not None and op[best][2]:      # openpilot longActive too
            pairs.append((t, a_stock, op[best][1]))

    print(f"stock 0x13C samples : {len(stock)}")
    print(f"carControl samples  : {len(op)}")
    print(f"compared (both active): {len(pairs)}")
    if len(pairs) < 50:
        print("\nToo few overlapping samples to judge. openpilot needs to be ENGAGED")
        print("at the same time the stock ACC is controlling.")
        return 1

    n = len(pairs)
    xs = [p[1] for p in pairs]
    ys = [p[2] for p in pairs]
    mx, my = sum(xs) / n, sum(ys) / n
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys, strict=True))
    sxx = sum((x - mx) ** 2 for x in xs)
    syy = sum((y - my) ** 2 for y in ys)
    r = sxy / math.sqrt(sxx * syy) if sxx > 0 and syy > 0 else float('nan')
    rms = math.sqrt(sum((x - y) ** 2 for x, y in zip(xs, ys, strict=True)) / n)
    bias = my - mx
    worst = max(pairs, key=lambda p: abs(p[1] - p[2]))

    print(f"\nstock accel   mean {mx:+.3f}  range {min(xs):+.2f} .. {max(xs):+.2f} m/s^2")
    print(f"openpilot     mean {my:+.3f}  range {min(ys):+.2f} .. {max(ys):+.2f} m/s^2")
    print(f"\ncorrelation r : {r:+.3f}")
    print(f"RMS difference: {rms:.3f} m/s^2")
    print(f"mean bias     : {bias:+.3f} m/s^2  (openpilot minus stock)")
    print(f"worst sample  : t={worst[0]:.1f}s  stock {worst[1]:+.2f}  op {worst[2]:+.2f}")

    print("\nHow to read this:")
    print("  r > 0.8 and RMS < 0.5   openpilot wants roughly what the car wants.")
    print("                          That validates the planner and the units.")
    print("  large positive bias     openpilot would accelerate harder than stock.")
    print("  large negative bias     openpilot would brake harder than stock.")
    print("  r near 0                something is wrong -- units, sign, or the")
    print("                          planner has no lead/target information.")
    print("\nThis does NOT validate that the car would ACCEPT a comma-originated")
    print("0x13C. Only a real transmission can show that, and it needs the panda")
    print("safety change plus the relay question answered first.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
