#!/usr/bin/env python3
"""Try to reproduce bytes 0-1 of 0x160 as a CRC/checksum over the rest.

If a standard CRC-16 matches every frame, the field is computable and openpilot
can forge the message. If nothing matches, it is probably a keyed MAC and
longitudinal via 0x160 is dead.

    python crack_crc.py rlog.zst [...]
"""
import sys
import glob
from opendbc.car.logreader import LogReader

ADDR = 0x160

# name: (poly, init, refin, refout, xorout)
CATALOG = {
    "CCITT-FALSE": (0x1021, 0xFFFF, False, False, 0x0000),
    "XMODEM":      (0x1021, 0x0000, False, False, 0x0000),
    "KERMIT":      (0x1021, 0x0000, True,  True,  0x0000),
    "MCRF4XX":     (0x1021, 0xFFFF, True,  True,  0x0000),
    "X-25":        (0x1021, 0xFFFF, True,  True,  0xFFFF),
    "GENIBUS":     (0x1021, 0xFFFF, False, False, 0xFFFF),
    "AUG-CCITT":   (0x1021, 0x1D0F, False, False, 0x0000),
    "ARC":         (0x8005, 0x0000, True,  True,  0x0000),
    "MODBUS":      (0x8005, 0xFFFF, True,  True,  0x0000),
    "USB":         (0x8005, 0xFFFF, True,  True,  0xFFFF),
    "MAXIM":       (0x8005, 0x0000, True,  True,  0xFFFF),
    "BUYPASS":     (0x8005, 0x0000, False, False, 0x0000),
    "DDS-110":     (0x8005, 0x800D, False, False, 0x0000),
    "CMS":         (0x8005, 0xFFFF, False, False, 0x0000),
    "DECT-R":      (0x0589, 0x0000, False, False, 0x0001),
    "DNP":         (0x3D65, 0x0000, True,  True,  0xFFFF),
    "EN-13757":    (0x3D65, 0x0000, False, False, 0xFFFF),
    "T10-DIF":     (0x8BB7, 0x0000, False, False, 0x0000),
    "TELEDISK":    (0xA097, 0x0000, False, False, 0x0000),
    "OPENSAFETY-A":(0x5935, 0x0000, False, False, 0x0000),
    "OPENSAFETY-B":(0x755B, 0x0000, False, False, 0x0000),
    "PROFIBUS":    (0x1DCF, 0xFFFF, False, False, 0xFFFF),
    "RIELLO":      (0x1021, 0xB2AA, True,  True,  0x0000),
    "TMS37157":    (0x1021, 0x89EC, True,  True,  0x0000),
    "A":           (0x1021, 0xC6C6, True,  True,  0x0000),
}


def rev16(x):
    return int(f"{x:016b}"[::-1], 2)


def rev8(x):
    return int(f"{x:08b}"[::-1], 2)


def crc16(data, poly, init, refin, refout, xorout):
    reg = init
    for b in data:
        if refin:
            b = rev8(b)
        reg ^= b << 8
        for _ in range(8):
            reg = ((reg << 1) ^ poly) & 0xFFFF if reg & 0x8000 else (reg << 1) & 0xFFFF
    if refout:
        reg = rev16(reg)
    return reg ^ xorout


def main(paths):
    data = []
    for p in paths:
        for m in LogReader(p, only_union_types=True):
            if m.which() != "can":
                continue
            for c in m.can:
                if c.src == 0 and c.address == ADDR:
                    data.append(bytes(c.dat))
    print(f"{len(data)} frames of {ADDR:#05x}")
    sample = data[:300]

    # candidate byte ranges over which the CRC might be taken
    ranges = {
        "2..31": lambda d: d[2:],
        "2..23": lambda d: d[2:24],
        "3..31": lambda d: d[3:],
        "2..15": lambda d: d[2:16],
        "addr+2..31": lambda d: bytes([ADDR >> 8, ADDR & 0xFF]) + d[2:],
        "addr+2..23": lambda d: bytes([ADDR >> 8, ADDR & 0xFF]) + d[2:24],
    }
    be = lambda d: (d[0] << 8) | d[1]
    le = lambda d: (d[1] << 8) | d[0]

    hits = []
    for rname, rfn in ranges.items():
        for cname, (poly, init, refin, refout, xorout) in CATALOG.items():
            for ename, efn in (("BE", be), ("LE", le)):
                ok = all(crc16(rfn(d), poly, init, refin, refout, xorout) == efn(d)
                         for d in sample)
                if ok:
                    hits.append((cname, rname, ename))

    if hits:
        print("\n*** CATALOGUE HIT ***")
        for cname, rname, ename in hits:
            poly, init, refin, refout, xorout = CATALOG[cname]
            full = all(crc16(ranges[rname](d), poly, init, refin, refout, xorout)
                       == (be(d) if ename == "BE" else le(d)) for d in data)
            print(f"  {cname} over bytes {rname}, {ename}: "
                  f"{'VERIFIED on all %d frames' % len(data) if full else 'FAILED full verify'}")
        return 0

    print("\nno catalogue match. widening: search all 65536 polys "
          "(init 0x0000/0xFFFF, both reflections, xorout 0/0xFFFF)")
    small = data[:12]
    found = []
    for rname, rfn in list(ranges.items())[:3]:
        msgs = [rfn(d) for d in small]
        tgt_be = [be(d) for d in small]
        tgt_le = [le(d) for d in small]
        for poly in range(0x10000):
            for init in (0x0000, 0xFFFF):
                for refin, refout in ((False, False), (True, True)):
                    for xorout in (0x0000, 0xFFFF):
                        c0 = crc16(msgs[0], poly, init, refin, refout, xorout)
                        if c0 != tgt_be[0] and c0 != tgt_le[0]:
                            continue
                        tgt = tgt_be if c0 == tgt_be[0] else tgt_le
                        if all(crc16(m, poly, init, refin, refout, xorout) == t
                               for m, t in zip(msgs, tgt)):
                            found.append((rname, poly, init, refin, refout, xorout))
        if found:
            break
    if found:
        print("*** CUSTOM POLY FOUND ***")
        for rname, poly, init, refin, refout, xorout in found[:5]:
            print(f"  bytes {rname}: poly={poly:#06x} init={init:#06x} "
                  f"refin={refin} refout={refout} xorout={xorout:#06x}")
    else:
        print("nothing. bytes 0-1 are not a CRC-16 over any range tried.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
