#!/usr/bin/env python3
"""Focused SHADOW check: does openpilot brake sensibly when it matters?

Global r over a whole drive is deflated by set-speed cruising (both controllers
sit near 0). The safety question is the ACTIVE-accel regime, especially the
lead-follow-to-stop. This:
  1. recomputes correlation restricted to |camera accel| > 0.3 (real events)
  2. cross-correlates over time lags (two controllers can lag each other)
  3. isolates the lowest-speed lead-follow window (the trail to a stop) and
     prints openpilot vs camera accel there
"""
import sys, glob, bisect, math
from openpilot.tools.lib.logreader import LogReader as OP
from opendbc.car.logreader import LogReader as CAN


def a160(d):
  raw = ((d[4] & 0x7F) << 8) | d[5]
  if d[4] & 0x40: raw -= 0x8000
  return raw * 0.001


def main(paths):
  op=[]; t0=None
  vego=[]
  for p in paths:
    for m in OP(p):
      w=m.which(); t=m.logMonoTime/1e9
      if t0 is None: t0=t
      if w=="carControl":
        try: op.append((t-t0, m.carControl.actuators.accel, bool(m.carControl.longActive)))
        except: pass
      elif w=="carState":
        vego.append((t-t0, m.carState.vEgo))
  cam=[]; act=[]; t0b=None
  for p in paths:
    for m in CAN(p, only_union_types=True):
      if m.which()!="can": continue
      t=m.logMonoTime/1e9
      if t0b is None: t0b=t
      for c in m.can:
        if c.src in (0,2) and c.address==0x160: cam.append((t-t0b, a160(bytes(c.dat))))
        elif c.src==1 and c.address==0x13C:
          d=bytes(c.dat)
          if len(d)>=8: act.append((t-t0b, bool(d[4]&0x20)))
  at=[x[0] for x in act]
  def stock_on(tq):
    if not at: return False
    i=min(bisect.bisect_left(at,tq),len(act)-1); return act[i][1]
  ct=[c[0] for c in cam]
  def cam_at(tq, tol=0.1):
    i=bisect.bisect_left(ct,tq); best=None
    for j in (i-1,i):
      if 0<=j<len(cam) and abs(cam[j][0]-tq)<tol:
        if best is None or abs(cam[j][0]-tq)<abs(cam[best][0]-tq): best=j
    return cam[best][1] if best is not None else None

  # 1. correlation restricted to active-accel events
  pairs=[]
  for t,a_op,la in op:
    if not la or not stock_on(t): continue
    ac=cam_at(t)
    if ac is None: continue
    pairs.append((t,ac,a_op))
  ev=[p for p in pairs if abs(p[1])>0.3]
  def corr(ps):
    n=len(ps)
    if n<30: return float('nan'),0
    xs=[p[1] for p in ps]; ys=[p[2] for p in ps]
    mx=sum(xs)/n; my=sum(ys)/n
    sxy=sum((x-mx)*(y-my) for x,y in zip(xs,ys)); sxx=sum((x-mx)**2 for x in xs); syy=sum((y-my)**2 for y in ys)
    return (sxy/math.sqrt(sxx*syy) if sxx>0 and syy>0 else float('nan')), n
  r_all,n_all=corr(pairs); r_ev,n_ev=corr(ev)
  print(f"all engaged pairs      : n={n_all}  r={r_all:+.3f}")
  print(f"active-accel (|cam|>0.3): n={n_ev}  r={r_ev:+.3f}")

  # 2. cross-correlation over lag (openpilot may lead/lag the camera)
  print("\ncross-correlation vs time shift (op shifted by lag):")
  best=(0,-9)
  for lag_ms in range(-1500,1501,250):
    lag=lag_ms/1000.0
    ps=[]
    for t,a_op,la in op:
      if not la or not stock_on(t+lag): continue
      ac=cam_at(t+lag)
      if ac is not None and abs(ac)>0.3: ps.append((t,ac,a_op))
    r,n=corr(ps)
    if not math.isnan(r):
      print(f"  lag {lag_ms:+5d} ms : r={r:+.3f} (n={n})")
      if r>best[1]: best=(lag_ms,r)
  print(f"  best lag {best[0]:+d} ms, r={best[1]:+.3f}")

  # 3. the trail-to-stop: lowest-speed window with a lead
  vt=[v[0] for v in vego]
  def v_at(tq):
    i=min(bisect.bisect_left(vt,tq),len(vego)-1); return vego[i][1]
  # find the longest run where speed decreases from >18 m/s to <2 m/s
  stops=[]
  for t,a_op,la in op:
    if la and stock_on(t): stops.append((t,v_at(t)))
  # print accel around the deepest deceleration (min vEgo while engaged)
  if stops:
    tmin=min(stops,key=lambda s:s[1])[0]
    print(f"\ntrail-to-stop window around t={tmin:.0f}s (deepest engaged decel):")
    print(f"  {'t':>7} {'vEgo':>6} {'cam_a':>7} {'op_a':>7}")
    for t,a_op,la in op:
      if abs(t-tmin)<6 and la:
        ac=cam_at(t)
        if ac is not None and int(t*5)%5==0:
          print(f"  {t:7.1f} {v_at(t)*2.237:6.1f} {ac:+7.2f} {a_op:+7.2f}")
  return 0

if __name__=="__main__":
  sys.exit(main(sys.argv[1:]))
