# Panda firmware with TSS 3.0 longitudinal safety

**Do not copy these onto the device unless you mean to reflash the panda.**
They are kept out of `port/files/` on purpose so that the ordinary
`scp -r port/files/... ` deploy cannot flash your panda by accident.

## What this is

`panda_h7.bin.signed` — panda H7 firmware built 2026-09-08 with the TSS3 safety
mode from `../panda-safety-tss3.patch` compiled in.

```
sha256  3194c979ffaaa4aaf43c760711a12a1dbd373c079a42a4ecdb7ab475ea27a34d
size    103240 bytes
```

`bootstub.panda_h7.bin` is included because debug-signed firmware needs a
bootstub that trusts the debug key. You only need it if the app firmware refuses
to boot (see below).

## How it was built

- panda sources: `commaai/panda` @ `75aa44bec9140849868239b1f1e3f22624adb8fe`
- **with sunnypilot's 4 patched firmware files overlaid** — `board/main.c`,
  `board/main_comms.h`, `board/health.h`, `board/drivers/registers.h`. Building
  stock comma firmware instead would silently drop sunnypilot's panda changes.
- safety headers from the **patched sunnypilot `opendbc_repo`** via
  `PYTHONPATH`, because `panda/SConscript` does `import opendbc` and uses
  `opendbc.INCLUDE_PATH`. Pointing that at upstream opendbc would silently give
  you stock Toyota safety with no TSS3 **and no MADS**.
- toolchain: `arm-none-eabi-gcc 13.2.1` (apt `gcc-arm-none-eabi`), WSL Ubuntu 24.04
- signed with `board/certs/debug` (no `RELEASE` env set)

## Proof the TSS3 safety is actually in it

Built twice from identical trees, differing only in which `toyota.h` the
`PYTHONPATH` opendbc supplied:

```
tss3    103104 bytes  sha a67c9c6d5e98b4a4
stock   102724 bytes  sha 7b537d180b255986
RESULT: DIFFERENT -> TSS3 safety IS compiled in (+380 bytes)
```

That is the check worth repeating if you ever rebuild: a build that silently
picked up the wrong opendbc produces a *working* binary, just without your
safety mode.

## Reproducible on your own toolchain

Built twice more, with pip scons 4.11.1 and with your apt scons 4.5.2 + system
python3. All three agree byte for byte, including the signed artifact:

```
venv   scons 4.11.1  103104 bytes  b93f269fac39f0dcc64fdbdc
system scons 4.5.2   103104 bytes  b93f269fac39f0dcc64fdbdc
signed (both)        sha256 3194c979ffaaa4aaf43c760711a12a1dbd373c079a42a4ecdb7ab475ea27a34d
```

So the binary in this directory is exactly what your own machine produces. To
rebuild it yourself:

```bash
PYTHONPATH=<sunnypilot>/opendbc_repo scons -j8      # from the panda tree
```

## Deploying

```bash
scp panda_h7.bin.signed comma@<device-ip>:/data/openpilot/panda/board/obj/
ssh comma@<device-ip> 'sudo reboot'   # updates already disabled; do NOT touch .git
```

pandad flashes automatically — it compares the running panda's signature against
the signature in this file and reflashes on mismatch:

```python
fw_signature = get_expected_signature()          # from panda_h7.bin.signed
if panda.bootstub or panda_signature != fw_signature:
    panda.flash()
```

If the debug-signed app will not boot on a release bootstub, pandad handles it:
it flashes the development bootloader and calls `panda.recover()`. That is what
`bootstub.panda_h7.bin` is for if you ever need to do it by hand.

## Notes before you flash

- This build has **`-DALLOW_DEBUG`** set (the default when `RELEASE` is unset).
  That also un-gates `TOYOTA_PARAM_SECOC`, which stock release firmware ignores.
  Fine here, but it means the firmware is more permissive than stock in general.
- Flashing this **alone actuates nothing**. It is the limiter that would *permit*
  `0x13C`. You still need `TSS3_LONG_MODE = LIVE` in
  `opendbc/car/toyota/values.py`, and LIVE is still blocked on the engage/cancel
  decode — see `../NOTES.md`.
- Reverting is just as easy: restore the stock `panda_h7.bin.signed` from a
  fresh sunnypilot checkout and reboot; pandad reflashes it the same way.
