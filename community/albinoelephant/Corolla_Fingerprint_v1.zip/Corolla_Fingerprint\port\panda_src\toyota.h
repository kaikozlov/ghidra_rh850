#pragma once

#include "opendbc/safety/declarations.h"

// Stock longitudinal
#define TOYOTA_BASE_TX_MSGS \
  {0x191, 0, 8, .check_relay = true}, {0x412, 0, 8, .check_relay = true}, {0x1D2, 0, 8, .check_relay = false},  /* LKAS + LTA + PCM cancel cmd */  \

#define TOYOTA_COMMON_TX_MSGS \
  TOYOTA_BASE_TX_MSGS \
  {0x2E4, 0, 5, .check_relay = true}, \
  {0x343, 0, 8, .check_relay = false},  /* ACC cancel cmd */  \

#define TOYOTA_COMMON_SECOC_TX_MSGS \
  TOYOTA_BASE_TX_MSGS \
  {0x2E4, 0, 8, .check_relay = true}, {0x131, 0, 8, .check_relay = true}, \
  {0x343, 0, 8, .check_relay = false},  /* ACC cancel cmd */ \

#define TOYOTA_COMMON_LONG_TX_MSGS \
  TOYOTA_COMMON_TX_MSGS \
  /* DSU bus 0 */ \
  {0x283, 0, 7, .check_relay = false}, {0x2E6, 0, 8, .check_relay = false}, {0x2E7, 0, 8, .check_relay = false}, {0x33E, 0, 7, .check_relay = false}, \
  {0x344, 0, 8, .check_relay = false}, {0x365, 0, 7, .check_relay = false}, {0x366, 0, 7, .check_relay = false}, {0x4CB, 0, 8, .check_relay = false}, \
  /* DSU bus 1 */ \
  {0x128, 1, 6, .check_relay = false}, {0x141, 1, 4, .check_relay = false}, {0x160, 1, 8, .check_relay = false}, {0x161, 1, 7, .check_relay = false}, \
  {0x470, 1, 4, .check_relay = false}, \
  /* PCS_HUD */                        \
  {0x411, 0, 8, .check_relay = false}, \
  /* radar diagnostic address */       \
  {0x750, 0, 8, .check_relay = false}, \
  /* ACC */                            \
  {0x343, 0, 8, .check_relay = true},  \

#define TOYOTA_COMMON_SECOC_LONG_TX_MSGS \
  TOYOTA_COMMON_SECOC_TX_MSGS \
  {0x343, 0, 8, .check_relay = true}, \
  {0x183, 0, 8, .check_relay = true},  /* ACC_CONTROL_2 */ \

// TSS 3.0 (CAN FD + SecOC) longitudinal, this port only.
// The camera's ACC request 0x160 is a 32-byte CAN FD frame on the ADAS bus
// (relayed pair, panda bus 0). check_relay=true permits openpilot to transmit it.
// disable_static_blocking=true means the static forwarder does NOT always block
// the camera's own 0x160 -- toyota_fwd_hook decides dynamically, blocking the
// camera copy ONLY while openpilot is actively controlling (controls_allowed).
// Otherwise the camera's request passes through natively, so the ADAS system
// keeps working when openpilot is not engaged (a static block starved the gateway
// of 0x160 and tripped "System Malfunction" on the first LIVE attempt).
// NOTE: distinct from the legacy DSU {0x160, 1, 8} above -- 8 bytes on bus 1.
// 0x160 carries BOTH the accel request (bytes 4-5) AND the steer request (bytes
// 22-23) -- it is the single combined camera->gateway ADAS request. openpilot is
// the sole writer of 0x160, so lateral rides in this same frame (no separate
// 0x1A0 tx: 0x1A0 is gateway-NATIVE on bus0, and claiming it here tripped
// relayMalfunction -> "System Malfunction" on the first lateral attempt).
#define TOYOTA_TSS3_LONG_TX_MSGS \
  {0x160, 0, 32, .check_relay = true, .disable_static_blocking = true},  /* ADAS_ACC_REQUEST (TSS3) accel + steer */ \

#define TOYOTA_COMMON_RX_CHECKS(lta)                                                                                                       \
  {.msg = {{ 0xaa, 0, 8, 83U, .ignore_checksum = true, .ignore_counter = true}, { 0 }, { 0 }}},      \
  {.msg = {{0x260, 0, 8, 50U, .ignore_counter = true, .ignore_quality_flag=!(lta)}, { 0 }, { 0 }}},  \

#define TOYOTA_RX_CHECKS(lta)                                                                                                               \
  TOYOTA_COMMON_RX_CHECKS(lta)                                                                                                              \
  {.msg = {{0x1D2, 0, 8, 33U, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}},                            \
  {.msg = {{0x226, 0, 8, 40U, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true},  { 0 }, { 0 }}},  \

#define TOYOTA_ALT_BRAKE_RX_CHECKS(lta)                                                                                                    \
  TOYOTA_COMMON_RX_CHECKS(lta)                                                                                                             \
  {.msg = {{0x1D2, 0, 8, 33U, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}},                           \
  {.msg = {{0x224, 0, 8, 40U, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}},  \

#define TOYOTA_SECOC_RX_CHECKS                                                                                                             \
  TOYOTA_COMMON_RX_CHECKS(false)                                                                                                           \
  {.msg = {{0x176, 0, 8, 32U, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}},                           \
  {.msg = {{0x116, 0, 8, 42U, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}},  \
  {.msg = {{0x101, 0, 8, 50U, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}},  \

// TSS 3.0 safety inputs, all on the POWERTRAIN bus (bus 1) with stock wiring.
// Addresses/bits decoded and validated from route 16 (see port NOTES.md).
//   0x8A  STEER_ANGLE_ACC_STATUS  cruise-engaged bit (byte 22 mask 0x10)
//   0xAA  WHEEL_SPEEDS            vehicle speed
//   0x101 BRAKE_MODULE            brake pressed (bit 3)
//   0x116 GAS_PEDAL               driver gas (byte 1)
#define TOYOTA_TSS3_RX_CHECKS                                                                                                              \
  {.msg = {{ 0xaa, 1, 8, 80U, .ignore_checksum = true, .ignore_counter = true}, { 0 }, { 0 }}},                                \
  {.msg = {{ 0x8a, 1, 32, 40U, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}},  \
  {.msg = {{0x101, 1, 8, 50U, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}},   \
  {.msg = {{0x116, 1, 8, 42U, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}},   \

#define TOYOTA_PCM_CRUISE_2_ADDR_CHECK                                                                                                     \
  {.msg = {{0x1D3, 0, 8, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true, .frequency = 33U}, { 0 }, { 0 }}},  \

#define TOYOTA_DSU_CRUISE_ADDR_CHECK                                                                                                      \
  {.msg = {{0x365, 0, 7, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true, .frequency = 5U, .ignore_frequency_check = true}, { 0 }, { 0 }}},  \

#define TOYOTA_GAS_INTERCEPTOR_ADDR_CHECK                                                   \
  {.msg = {{0x201, 0, 6, 50U, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}}, \

static bool toyota_secoc = false;
static bool toyota_tss3 = false;
static int tss3_last_steer_angle = 0;   // last accepted 0x1A0 STEER_ANGLE_CMD (rate limit)
static bool tss3_steer_angle_inited = false;  // seed the rate baseline on the engage edge
static bool toyota_alt_brake = false;
static bool toyota_stock_longitudinal = false;
static bool toyota_lta = false;
static int toyota_dbc_eps_torque_factor = 100;   // conversion factor for STEER_TORQUE_EPS in %: see dbc file

static uint32_t toyota_compute_checksum(const CANPacket_t *msg) {
  int len = GET_LEN(msg);
  uint8_t checksum = (uint8_t)(msg->addr) + (uint8_t)((unsigned int)(msg->addr) >> 8U) + (uint8_t)(len);
  for (int i = 0; i < (len - 1); i++) {
    checksum += (uint8_t)msg->data[i];
  }
  return checksum;
}

static uint32_t toyota_get_checksum(const CANPacket_t *msg) {
  int checksum_byte = GET_LEN(msg) - 1U;
  return (uint8_t)(msg->data[checksum_byte]);
}

static bool toyota_get_quality_flag_valid(const CANPacket_t *msg) {
  bool valid = false;
  if (msg->addr == 0x260U) {
    valid = !GET_BIT(msg, 3U);  // STEER_TORQUE_SENSOR.STEER_ANGLE_INITIALIZING
  } else if (msg->addr == 0xaaU) {  // WHEEL_SPEEDS
    // each wheel speed is 1-bit fault + 15-bit speed
    valid = true;
    for (uint8_t i = 0U; i < 4U; i += 1U) {
      if (GET_BIT(msg, (i * 16U) + 7U)) {  // WHEEL_SPEED_xx_FAULT
        valid = false;
        break;
      }
    }
  } else {
  }
  return valid;
}

static int TOYOTA_GET_INTERCEPTOR(const CANPacket_t *msg) {
  uint16_t val1 = (uint16_t)((uint16_t)msg->data[0] << 8U) | (uint16_t)msg->data[1];
  uint16_t val2 = (uint16_t)((uint16_t)msg->data[2] << 8U) | (uint16_t)msg->data[3];
  uint16_t avg  = (uint16_t)((val1 + val2) / 2U);

  return (int)avg;
}

static void toyota_rx_hook(const CANPacket_t *msg) {
  if (msg->bus == 0U) {

    // get eps motor torque (0.66 factor in dbc)
    if (msg->addr == 0x260U) {
      int torque_meas_new = (msg->data[5] << 8) | msg->data[6];
      torque_meas_new = to_signed(torque_meas_new, 16);

      // scale by dbc_factor
      torque_meas_new = (torque_meas_new * toyota_dbc_eps_torque_factor) / 100;

      // update array of sample
      update_sample(&torque_meas, torque_meas_new);

      // increase torque_meas by 1 to be conservative on rounding
      torque_meas.min--;
      torque_meas.max++;

      // driver torque for angle limiting
      int torque_driver_new = (msg->data[1] << 8) | msg->data[2];
      torque_driver_new = to_signed(torque_driver_new, 16);
      update_sample(&torque_driver, torque_driver_new);

      // LTA request angle should match current angle while inactive, clipped to max accepted angle.
      // note that angle can be relative to init angle on some TSS2 platforms, LTA has the same offset
      bool steer_angle_initializing = GET_BIT(msg, 3U);
      if (!steer_angle_initializing) {
        int angle_meas_new = (msg->data[3] << 8U) | msg->data[4];
        angle_meas_new = to_signed(angle_meas_new, 16);
        update_sample(&angle_meas, angle_meas_new);
      }
    }

    // enter controls on rising edge of ACC, exit controls on ACC off
    // exit controls on rising edge of gas press, if not alternative experience
    // exit controls on rising edge of brake press
    if (toyota_secoc) {
      if (msg->addr == 0x176U) {
        bool cruise_engaged = GET_BIT(msg, 5U);  // PCM_CRUISE.CRUISE_ACTIVE
        pcm_cruise_check(cruise_engaged);
      }
      if (msg->addr == 0x116U) {
        gas_pressed = msg->data[1] != 0U;  // GAS_PEDAL.GAS_PEDAL_USER
      }
      if (msg->addr == 0x101U) {
        brake_pressed = GET_BIT(msg, 3U);  // BRAKE_MODULE.BRAKE_PRESSED (toyota_rav4_prime_generated.dbc)
      }
    } else {
      if (msg->addr == 0x1D2U) {
        bool cruise_engaged = GET_BIT(msg, 5U);  // PCM_CRUISE.CRUISE_ACTIVE
        pcm_cruise_check(cruise_engaged);

        if (!enable_gas_interceptor) {
          gas_pressed = !GET_BIT(msg, 4U);  // PCM_CRUISE.GAS_RELEASED
        }
      }
      if (!toyota_alt_brake && (msg->addr == 0x226U)) {
        brake_pressed = GET_BIT(msg, 37U);  // BRAKE_MODULE.BRAKE_PRESSED (toyota_nodsu_pt_generated.dbc)
      }
      if (toyota_alt_brake && (msg->addr == 0x224U)) {
        brake_pressed = GET_BIT(msg, 5U);  // BRAKE_MODULE.BRAKE_PRESSED (toyota_new_mc_pt_generated.dbc)
      }
    }

    // sample speed
    if (msg->addr == 0xaaU) {
      int speed = 0;
      // sum 4 wheel speeds. conversion: raw * 0.01 - 67.67
      for (uint8_t i = 0U; i < 8U; i += 2U) {
        int wheel_speed = ((msg->data[i] & 0x7FU) << 8U) | msg->data[(i + 1U)];
        speed += wheel_speed - 6767;
      }
      // check that all wheel speeds are at zero value
      vehicle_moving = speed != 0;

      UPDATE_VEHICLE_SPEED(speed / 4.0 * 0.01 * KPH_TO_MS);
    }

    if (msg->addr == 0x1D3U) {
      acc_main_on = GET_BIT(msg, 15U);
    }

    if (msg->addr == 0x365U) {
      acc_main_on = GET_BIT(msg, 0U);
    }

    // sample gas interceptor
    if (msg->addr == 0x201U) {
      // panda interceptor threshold needs to be equivalent to openpilot threshold to avoid controls mismatches
      // If thresholds are mismatched then it is possible for panda to see the gas fall and rise while openpilot is in the pre-enabled state
      // Threshold calculated from DBC gains: round((((15 + 75.555) / 0.159375) + ((15 + 151.111) / 0.159375)) / 2) = 805
      const int toyota_gas_interceptor_thrsld = 805;

      int gas_interceptor = TOYOTA_GET_INTERCEPTOR(msg);
      gas_pressed = gas_interceptor > toyota_gas_interceptor_thrsld;

      gas_interceptor_prev = gas_interceptor;
    }
  }

  // TSS 3.0: all safety inputs are on the POWERTRAIN bus (bus 1), not bus 0.
  // Addresses/bits decoded + validated from route 16 (see port NOTES.md).
  if (toyota_tss3 && (msg->bus == 1U)) {
    // 0x8A STEER_ANGLE_ACC_STATUS: cruise engaged (byte 22 mask 0x10, i.e. bit
    // 22*8+4 = 180), 99.67% agreement with 0x13C LON_ACTIVE. Enters/exits
    // controls on the stock ACC engage edge -- driver engages with the stalk.
    if (msg->addr == 0x8AU) {
      bool cruise_engaged = GET_BIT(msg, 180U);
      pcm_cruise_check(cruise_engaged);
      // ACC_STATE byte 7 != 0 means the system is on/responding (MADS only).
      acc_main_on = msg->data[7] != 0U;
    }

    // 0xAA WHEEL_SPEEDS: same layout/scale as classic Toyota (raw*0.01-67.67).
    if (msg->addr == 0xAAU) {
      int speed = 0;
      for (uint8_t i = 0U; i < 8U; i += 2U) {
        int wheel_speed = ((msg->data[i] & 0x7FU) << 8U) | msg->data[(i + 1U)];
        speed += wheel_speed - 6767;
      }
      vehicle_moving = speed != 0;
      UPDATE_VEHICLE_SPEED(speed / 4.0 * 0.01 * KPH_TO_MS);
      // while disengaged openpilot does not emit 0x1A0 (the camera's own frame
      // passes through), so clear the rate baseline; it is re-seeded from the
      // first frame openpilot sends on the engage edge (below).
      if (!controls_allowed) { tss3_steer_angle_inited = false; }
    }

    // 0x101 BRAKE_MODULE: brake pressed, bit 3 (same as the SecOC rav4 path).
    if (msg->addr == 0x101U) {
      brake_pressed = GET_BIT(msg, 3U);
    }

    // 0x116 GAS_PEDAL: driver gas, byte 1. Rest is a true 0, verified 100% zero
    // while braking. Matches carstate's gasPressed = (byte1 != 0) exactly.
    if (msg->addr == 0x116U) {
      gas_pressed = msg->data[1] != 0U;
    }
  }
}

static bool toyota_tx_hook(const CANPacket_t *msg) {
  const TorqueSteeringLimits TOYOTA_TORQUE_STEERING_LIMITS = {
    .max_torque = 1500,
    .max_rate_up = 15,          // ramp up slow
    .max_rate_down = 25,        // ramp down fast
    .max_torque_error = 350,    // max torque cmd in excess of motor torque
    .max_rt_delta = 450,        // the real time limit is 1800/sec, a 20% buffer
    .type = TorqueMotorLimited,

    // the EPS faults when the steering angle rate is above a certain threshold for too long. to prevent this,
    // we allow setting STEER_REQUEST bit to 0 while maintaining the requested torque value for a single frame
    .min_valid_request_frames = 17,
    .max_invalid_request_frames = 1,
    .min_valid_request_rt_interval = 162000,  // 162ms; a ~10% buffer on cutting every 18 frames
    .has_steer_req_tolerance = true,
  };

  static const AngleSteeringLimits TOYOTA_ANGLE_STEERING_LIMITS = {
    // LTA angle limits
    // factor for STEER_TORQUE_SENSOR->STEER_ANGLE and STEERING_LTA->STEER_ANGLE_CMD (1 / 0.0573)
    .max_angle = 1657,  // EPS only accepts up to 94.9461
    .angle_deg_to_can = 17.452007,
    .angle_rate_up_lookup = {
      {5., 25., 25.},
      {0.3, 0.15, 0.15}
    },
    .angle_rate_down_lookup = {
      {5., 25., 25.},
      {0.36, 0.26, 0.26}
    },
  };

  const int TOYOTA_LTA_MAX_MEAS_TORQUE = 1500;
  const int TOYOTA_LTA_MAX_DRIVER_TORQUE = 150;

  // longitudinal limits
  const LongitudinalLimits TOYOTA_LONG_LIMITS = {
    .max_accel = 2000,   // 2.0 m/s2
    .min_accel = -3500,  // -3.5 m/s2
  };

  // TSS 3.0 0x160 ACCEL_REQ, 0.001 m/s^2/count. Matches the STOCK Toyota accel
  // envelope, because openpilot RELAYS the camera's own 0x160 verbatim when it is
  // not actively controlling (standstill / below min speed / gas), and the camera
  // commands down to about -3.3 m/s^2 for stops -- a tighter limit would block
  // those relayed frames and reopen the gap. openpilot's OWN substituted accel is
  // separately clamped to +/-1.5 in the carcontroller.
  const LongitudinalLimits TOYOTA_TSS3_LONG_LIMITS = {
    .max_accel = 2000,   // 2.0 m/s2
    .min_accel = -3500,  // -3.5 m/s2
  };

  // TSS 3.0 steer request rides in 0x160 bytes 22-23 (16-bit signed BE, ~537.7
  // counts/deg, zero-centered). openpilot is the sole writer of 0x160 and RELAYS
  // the camera's own steer request when not actively steering, so -- exactly like
  // the accel envelope -- the panda must let the camera's full field range through
  // (it saturates ~+/-60 deg). The per-frame rate cap is the real backstop against
  // a snapped command; openpilot's OWN angle is separately clamped tighter in the
  // carcontroller. Baseline seeded on the engage edge (rx 0xAA clears it while
  // disengaged). DELTA generous so relaying stock LTA never glitches -- TUNE on car.
  const int TOYOTA_TSS3_MAX_STEER_DELTA = 1500;   // counts/frame (~2.8 deg) -- TUNE + TEST

  bool tx = true;

  // Check if msg is sent on BUS 0
  if (msg->bus == 0U) {
    // ACCEL: safety check on byte 1-2
    if (msg->addr == 0x343U) {
      int desired_accel = (msg->data[0] << 8) | msg->data[1];
      desired_accel = to_signed(desired_accel, 16);

      bool violation = false;
      if (toyota_secoc) {
        // SecOC cars move accel to 0x183. Only allow inactive accel on 0x343 to match stock behavior
        violation = desired_accel != TOYOTA_LONG_LIMITS.inactive_accel;
      }
      violation |= longitudinal_accel_checks(desired_accel, TOYOTA_LONG_LIMITS);

      // only ACC messages that cancel are allowed when openpilot is not controlling longitudinal
      if (toyota_stock_longitudinal) {
        bool cancel_req = GET_BIT(msg, 24U);
        if (!cancel_req) {
          violation = true;
        }
        if (desired_accel != TOYOTA_LONG_LIMITS.inactive_accel) {
          violation = true;
        }
      }

      if (violation) {
        tx = false;
      }
    }

    if (msg->addr == 0x183U) {
      int desired_accel = (msg->data[0] << 8) | msg->data[1];
      desired_accel = to_signed(desired_accel, 16);

      tx = !longitudinal_accel_checks(desired_accel, TOYOTA_LONG_LIMITS);
    }

    // TSS 3.0 ADAS_ACC_REQUEST (0x160): bound BOTH openpilot's accel AND steer,
    // which share this one combined camera->gateway request frame.
    //   ACCEL_REQ = bits 33..47, 15-bit signed BE: byte4 bits 6..0 + byte5
    //               (byte4 bit7 0x80 is a constant flag above the field, masked).
    //   STEER_REQ = bytes 22-23, 16-bit signed BE (~537.7 counts/deg).
    // Accel: allowed only when longitudinal is allowed (controls_allowed && !gas)
    // and within the TSS3 limits. Steer: openpilot is the sole writer and relays
    // the camera's own steer request when not actively steering, so allow the full
    // field range and rely on the per-frame rate cap (seeded on the engage edge)
    // to block a snapped command. openpilot only emits 0x160 while engaged.
    if (toyota_tss3 && (msg->addr == 0x160U)) {
      int desired_accel = ((msg->data[4] & 0x7FU) << 8) | msg->data[5];
      desired_accel = to_signed(desired_accel, 15);
      bool violation = longitudinal_accel_checks(desired_accel, TOYOTA_TSS3_LONG_LIMITS);

      int desired_steer = (msg->data[22] << 8) | msg->data[23];
      desired_steer = to_signed(desired_steer, 16);
      if (controls_allowed) {
        if (tss3_steer_angle_inited) {
          if ((desired_steer - tss3_last_steer_angle) > TOYOTA_TSS3_MAX_STEER_DELTA) { violation = true; }
          if ((tss3_last_steer_angle - desired_steer) > TOYOTA_TSS3_MAX_STEER_DELTA) { violation = true; }
        }
        tss3_steer_angle_inited = true;
        tss3_last_steer_angle = desired_steer;   // track for rate limiting
      }

      tx = !violation;
    }

    // AEB: block all actuation. only used when DSU is unplugged
    if (msg->addr == 0x283U) {
      // only allow the checksum, which is the last byte
      bool block = (GET_BYTES(msg, 0, 4) != 0U) || (msg->data[4] != 0U) || (msg->data[5] != 0U);
      if (block) {
        tx = false;
      }
    }

    // STEERING_LTA angle steering check
    if (msg->addr == 0x191U) {
      // check the STEER_REQUEST, STEER_REQUEST_2, TORQUE_WIND_DOWN, STEER_ANGLE_CMD signals
      bool lta_request = GET_BIT(msg, 0U);
      bool lta_request2 = GET_BIT(msg, 25U);
      int torque_wind_down = msg->data[5];
      int lta_angle = (msg->data[1] << 8) | msg->data[2];
      lta_angle = to_signed(lta_angle, 16);

      bool steer_control_enabled = lta_request || lta_request2;
      if (!toyota_lta) {
        // using torque (LKA), block LTA msgs with actuation requests
        if (steer_control_enabled || (lta_angle != 0) || (torque_wind_down != 0)) {
          tx = false;
        }
      } else {
        // check angle rate limits and inactive angle
        if (steer_angle_cmd_checks(lta_angle, steer_control_enabled, TOYOTA_ANGLE_STEERING_LIMITS)) {
          tx = false;
        }

        if (lta_request != lta_request2) {
          tx = false;
        }

        // TORQUE_WIND_DOWN is gated on steer request
        if (!steer_control_enabled && (torque_wind_down != 0)) {
          tx = false;
        }

        // TORQUE_WIND_DOWN can only be no or full torque
        if ((torque_wind_down != 0) && (torque_wind_down != 100)) {
          tx = false;
        }

        // check if we should wind down torque
        int driver_torque = SAFETY_MIN(SAFETY_ABS(torque_driver.min), SAFETY_ABS(torque_driver.max));
        if ((driver_torque > TOYOTA_LTA_MAX_DRIVER_TORQUE) && (torque_wind_down != 0)) {
          tx = false;
        }

        int eps_torque = SAFETY_MIN(SAFETY_ABS(torque_meas.min), SAFETY_ABS(torque_meas.max));
        if ((eps_torque > TOYOTA_LTA_MAX_MEAS_TORQUE) && (torque_wind_down != 0)) {
          tx = false;
        }
      }
    }

    // STEERING_LTA_2 angle steering check (SecOC)
    if (toyota_secoc && (msg->addr == 0x131U)) {
      // SecOC cars block any form of LTA actuation for now
      bool lta_request = GET_BIT(msg, 3U);  // STEERING_LTA_2.STEER_REQUEST
      bool lta_request2 = GET_BIT(msg, 0U);  // STEERING_LTA_2.STEER_REQUEST_2
      int lta_angle_msb = msg->data[2];  // STEERING_LTA_2.STEER_ANGLE_CMD (MSB)
      int lta_angle_lsb = msg->data[3];  // STEERING_LTA_2.STEER_ANGLE_CMD (LSB)

      bool actuation = lta_request || lta_request2 || (lta_angle_msb != 0) || (lta_angle_lsb != 0);
      if (actuation) {
        tx = false;
      }
    }

    // STEER: safety check on bytes 2-3
    if (msg->addr == 0x2E4U) {
      int desired_torque = (msg->data[1] << 8) | msg->data[2];
      desired_torque = to_signed(desired_torque, 16);
      bool steer_req = GET_BIT(msg, 0U);
      // When using LTA (angle control), assert no actuation on LKA message
      if (!toyota_lta) {
        if (steer_torque_cmd_checks(desired_torque, steer_req, TOYOTA_TORQUE_STEERING_LIMITS)) {
          tx = false;
        }
      } else {
        if ((desired_torque != 0) || steer_req) {
          tx = false;
        }
      }
    }

    // GAS PEDAL: safety check
    if (msg->addr == 0x200U) {
      if (longitudinal_interceptor_checks(msg)) {
        tx = false;
      }
    }
  }

  // UDS: Only tester present ("\x0F\x02\x3E\x00\x00\x00\x00\x00") allowed on diagnostics address
  if (msg->addr == 0x750U) {
    // this address is sub-addressed. only allow tester present to radar (0xF)
    bool invalid_uds_msg = (GET_BYTES(msg, 0, 4) != 0x003E020FU) || (GET_BYTES(msg, 4, 4) != 0x0U);
    if (invalid_uds_msg) {
      tx = false;
    }
  }

  return tx;
}

static safety_config toyota_init(uint16_t param) {
  static const CanMsg TOYOTA_TX_MSGS[] = {
    TOYOTA_COMMON_TX_MSGS
  };

  static const CanMsg TOYOTA_SECOC_TX_MSGS[] = {
    TOYOTA_COMMON_SECOC_TX_MSGS
  };

  static const CanMsg TOYOTA_LONG_TX_MSGS[] = {
    TOYOTA_COMMON_LONG_TX_MSGS
  };

  static const CanMsg TOYOTA_SECOC_LONG_TX_MSGS[] = {
    TOYOTA_COMMON_SECOC_LONG_TX_MSGS
  };

  static const CanMsg TOYOTA_INTERCEPTOR_TX_MSGS[] = {
    TOYOTA_COMMON_LONG_TX_MSGS
    {0x200, 0, 6, .check_relay = false},  // gas interceptor
  };

  static const CanMsg TOYOTA_TSS3_LONG_TX_MSGS_ARR[] = {
    TOYOTA_TSS3_LONG_TX_MSGS
  };

  // safety param flags
  // first byte is for EPS factor, second is for flags
  const uint32_t TOYOTA_PARAM_OFFSET = 8U;
  const uint32_t TOYOTA_EPS_FACTOR = (1UL << TOYOTA_PARAM_OFFSET) - 1U;
  const uint32_t TOYOTA_PARAM_ALT_BRAKE = 1UL << TOYOTA_PARAM_OFFSET;
  const uint32_t TOYOTA_PARAM_STOCK_LONGITUDINAL = 2UL << TOYOTA_PARAM_OFFSET;
  const uint32_t TOYOTA_PARAM_LTA = 4UL << TOYOTA_PARAM_OFFSET;

  const uint16_t TOYOTA_PARAM_SP_UNSUPPORTED_DSU = 1;
  const uint16_t TOYTOA_PARAM_SP_GAS_INTERCEPTOR = 2;

#ifdef ALLOW_DEBUG
  const uint32_t TOYOTA_PARAM_SECOC = 8UL << TOYOTA_PARAM_OFFSET;
  toyota_secoc = GET_FLAG(param, TOYOTA_PARAM_SECOC);
  // TSS 3.0 CAN FD longitudinal (this port). Experimental -> ALLOW_DEBUG only.
  const uint32_t TOYOTA_PARAM_TSS3 = 16UL << TOYOTA_PARAM_OFFSET;
  toyota_tss3 = GET_FLAG(param, TOYOTA_PARAM_TSS3);
#endif

  toyota_alt_brake = GET_FLAG(param, TOYOTA_PARAM_ALT_BRAKE);
  toyota_stock_longitudinal = GET_FLAG(param, TOYOTA_PARAM_STOCK_LONGITUDINAL);
  toyota_lta = GET_FLAG(param, TOYOTA_PARAM_LTA);
  toyota_dbc_eps_torque_factor = param & TOYOTA_EPS_FACTOR;

  const bool toyota_unsupported_dsu = GET_FLAG(current_safety_param_sp, TOYOTA_PARAM_SP_UNSUPPORTED_DSU);
  enable_gas_interceptor = GET_FLAG(current_safety_param_sp, TOYTOA_PARAM_SP_GAS_INTERCEPTOR);

  // gas interceptor should not be used if openpilot is not controlling longitudinal or is a TSK car
  if (toyota_stock_longitudinal || toyota_secoc) {
    enable_gas_interceptor = false;
  }

  safety_config ret;
  // TSS 3.0 takes precedence: this car is also SecOC, but its openpilot
  // longitudinal is the 0x160 modify-and-forward, not the SecOC 0x2E4/0x343 tx.
  // Lateral is not sent on this platform, so the tx table is just 0x160.
  if (toyota_tss3) {
    SET_TX_MSGS(TOYOTA_TSS3_LONG_TX_MSGS_ARR, ret);
  } else if (toyota_secoc) {
    if (toyota_stock_longitudinal) {
      SET_TX_MSGS(TOYOTA_SECOC_TX_MSGS, ret);
    } else {
      SET_TX_MSGS(TOYOTA_SECOC_LONG_TX_MSGS, ret);
    }
  } else {
    if (toyota_stock_longitudinal) {
      SET_TX_MSGS(TOYOTA_TX_MSGS, ret);
    } else {
      SET_TX_MSGS(TOYOTA_LONG_TX_MSGS, ret);
    }
  }

  if (toyota_tss3) {
    static RxCheck toyota_tss3_rx_checks[] = {
      TOYOTA_TSS3_RX_CHECKS
    };

    SET_RX_CHECKS(toyota_tss3_rx_checks, ret);
  } else if (toyota_secoc) {
    static RxCheck toyota_secoc_rx_checks[] = {
      TOYOTA_SECOC_RX_CHECKS
      TOYOTA_PCM_CRUISE_2_ADDR_CHECK
    };

    SET_RX_CHECKS(toyota_secoc_rx_checks, ret);
  } else if (toyota_lta) {
    // Check the quality flag for angle measurement when using LTA, since it's not set on TSS-P cars
    static RxCheck toyota_lta_rx_checks[] = {
      TOYOTA_RX_CHECKS(true)
      TOYOTA_PCM_CRUISE_2_ADDR_CHECK
    };

    SET_RX_CHECKS(toyota_lta_rx_checks, ret);
  } else {
    static RxCheck toyota_lka_rx_checks[] = {
      TOYOTA_RX_CHECKS(false)
      TOYOTA_PCM_CRUISE_2_ADDR_CHECK
    };
    static RxCheck toyota_lka_alt_brake_rx_checks[] = {
      TOYOTA_ALT_BRAKE_RX_CHECKS(false)
      TOYOTA_PCM_CRUISE_2_ADDR_CHECK
    };
    static RxCheck toyota_lka_unsupported_dsu_rx_checks[] = {
      TOYOTA_RX_CHECKS(false)
      TOYOTA_DSU_CRUISE_ADDR_CHECK
    };
    static RxCheck toyota_lka_alt_brake_unsupported_dsu_rx_checks[] = {
      TOYOTA_ALT_BRAKE_RX_CHECKS(false)
      TOYOTA_DSU_CRUISE_ADDR_CHECK
    };

    if (!toyota_alt_brake) {
      if (toyota_unsupported_dsu) {
        SET_RX_CHECKS(toyota_lka_unsupported_dsu_rx_checks, ret);
      } else {
        SET_RX_CHECKS(toyota_lka_rx_checks, ret);
      }
    } else {
      if (toyota_unsupported_dsu) {
        SET_RX_CHECKS(toyota_lka_alt_brake_unsupported_dsu_rx_checks, ret);
      } else {
        SET_RX_CHECKS(toyota_lka_alt_brake_rx_checks, ret);
      }
    }
  }

  if (enable_gas_interceptor) {
    SET_TX_MSGS(TOYOTA_INTERCEPTOR_TX_MSGS, ret);

    if (toyota_lta) {
      static RxCheck toyota_lta_interceptor_rx_checks[] = {
        TOYOTA_RX_CHECKS(true)
        TOYOTA_PCM_CRUISE_2_ADDR_CHECK
        TOYOTA_GAS_INTERCEPTOR_ADDR_CHECK
      };

      SET_RX_CHECKS(toyota_lta_interceptor_rx_checks, ret);
    } else {
      static RxCheck toyota_lka_interceptor_rx_checks[] = {
        TOYOTA_RX_CHECKS(false)
        TOYOTA_PCM_CRUISE_2_ADDR_CHECK
        TOYOTA_GAS_INTERCEPTOR_ADDR_CHECK
      };
      static RxCheck toyota_lka_alt_brake_interceptor_rx_checks[] = {
        TOYOTA_ALT_BRAKE_RX_CHECKS(false)
        TOYOTA_PCM_CRUISE_2_ADDR_CHECK
        TOYOTA_GAS_INTERCEPTOR_ADDR_CHECK
      };
      static RxCheck toyota_lka_unsupported_dsu_interceptor_rx_checks[] = {
        TOYOTA_RX_CHECKS(false)
        TOYOTA_DSU_CRUISE_ADDR_CHECK
        TOYOTA_GAS_INTERCEPTOR_ADDR_CHECK
      };
      static RxCheck toyota_lka_alt_brake_unsupported_dsu_interceptor_rx_checks[] = {
        TOYOTA_ALT_BRAKE_RX_CHECKS(false)
        TOYOTA_DSU_CRUISE_ADDR_CHECK
        TOYOTA_GAS_INTERCEPTOR_ADDR_CHECK
      };

      if (!toyota_alt_brake) {
        if (toyota_unsupported_dsu) {
          SET_RX_CHECKS(toyota_lka_unsupported_dsu_interceptor_rx_checks, ret);
        } else {
          SET_RX_CHECKS(toyota_lka_interceptor_rx_checks, ret);
        }
      } else {
        if (toyota_unsupported_dsu) {
          SET_RX_CHECKS(toyota_lka_alt_brake_unsupported_dsu_interceptor_rx_checks, ret);
        } else {
          SET_RX_CHECKS(toyota_lka_alt_brake_interceptor_rx_checks, ret);
        }
      }
    }
  }

  return ret;
}

static bool toyota_fwd_hook(int bus_num, int addr) {
  bool block = false;
  // TSS 3.0 pass-through of the camera's 0x160 ACC request.
  // The camera sits on bus 2; the gateway on bus 0. openpilot emits its own
  // 0x160 (substituting or relaying) EXACTLY when longitudinal is allowed
  // (controls_allowed && !gas). So block the camera's copy under that same
  // condition -- never two writers, and never a gap: the instant openpilot stops
  // emitting (disengaged, or gas override), the camera's 0x160 forwards again.
  // Using get_longitudinal_allowed() (not raw controls_allowed) is what keeps
  // gas-override gap-free.
  // 0x160 carries both accel and steer. Block the camera's copy exactly when
  // openpilot is emitting its own (longitudinal allowed) so there is one writer;
  // the instant openpilot stops, the camera's 0x160 forwards again (gap-free).
  // Lateral rides in this same frame, so no separate 0x1A0 forwarding rule.
  if (toyota_tss3 && (bus_num == 2) && (addr == 0x160)) {
    block = get_longitudinal_allowed();
  }
  return block;
}

const safety_hooks toyota_hooks = {
  .init = toyota_init,
  .rx = toyota_rx_hook,
  .tx = toyota_tx_hook,
  .fwd = toyota_fwd_hook,
  .get_checksum = toyota_get_checksum,
  .compute_checksum = toyota_compute_checksum,
  .get_quality_flag_valid = toyota_get_quality_flag_valid,
};
