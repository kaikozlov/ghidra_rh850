#!/usr/bin/env python3
"""Decode 0x1a0 (LTA steering command): angle field + scale, effort field, and the
request/active bit that toggles with LTA engagement."""
import sys, bisect, math
from collections import defaultdict, Counter

def s16be(d,i):
    v=(d[i]<<8)|d[i+1]; return v-0x10000 if v>=0x8000 else v

def main(paths):
    from openpilot.tools.lib.logreader import LogReader as OP
    from opendbc.car.logreader import LogReader as CAN
    ta=[];va=[];t0=None
    for p in paths:
        for m in OP(p):
            if m.which()=="carState":
                t=m.logMonoTime/1e9
                if t0 is None:t0=t
                ta.append(t-t0);va.append(m.carState.steeringAngleDeg)
    def A(tq):
        i=bisect.bisect_left(ta,tq)
        if i<=0:return va[0]
        if i>=len(ta):return va[-1]
        return va[i] if abs(ta[i]-tq)<abs(ta[i-1]-tq) else va[i-1]
    fr=[];eng=[];t0b=None
    for p in paths:
        for m in CAN(p,only_union_types=True):
            if m.which()!="can":continue
            t=m.logMonoTime/1e9
            if t0b is None:t0b=t
            for c in m.can:
                if c.src==0 and c.address==0x1a0: fr.append((t-t0b,bytes(c.dat)))
                if c.src==1 and c.address==0x8A and len(bytes(c.dat))>=23: eng.append((t-t0b,1 if bytes(c.dat)[22]&0x10 else 0))
    et=[e[0] for e in eng]
    def E(tq):
        if not et:return 0
        i=min(bisect.bisect_left(et,tq),len(eng)-1);return eng[i][1]
    dlc=min(len(d) for _,d in fr)
    print(f"0x1a0 len {dlc}, frames {len(fr)}")
    # 1) angle field: correlate each 16-bit BE offset vs measured angle (whole drive = LTA turns)
    print("\nangle-field search (16-bit BE vs measured angle, whole drive):")
    best=[]
    for off in range(dlc-1):
        xs=[s16be(d,off) for _,d in fr]; ys=[A(t) for t,_ in fr]
        n=len(xs);mx=sum(xs)/n;my=sum(ys)/n
        sxx=sum((x-mx)**2 for x in xs);syy=sum((y-my)**2 for y in ys)
        if sxx<=0 or syy<=0:continue
        sxy=sum((x-mx)*(y-my) for x,y in zip(xs,ys)); r=sxy/math.sqrt(sxx*syy)
        if abs(r)>0.7: best.append((abs(r),off,r,sxy/sxx,min(xs),max(xs)))
    best.sort(reverse=True)
    for _,off,r,scale,lo,hi in best[:6]:
        print(f"  byte {off:2d}: r={r:+.2f} scale={scale:.4f} deg/cnt range {lo}..{hi}")
    # 2) request/active bit: a bit that is 0 when LTA off and 1 when engaged+steering
    print("\nrequest-bit search (bit 0 when off, ~1 when engaged & |angle|>3):")
    for byte in range(dlc):
        for bit in range(8):
            on=off_=0; on_tot=off_tot=0
            for t,d in fr:
                b=(d[byte]>>bit)&1
                if E(t)==1 and abs(A(t))>3: on+=b; on_tot+=1
                elif E(t)==0: off_+=b; off_tot+=1
            if on_tot>50 and off_tot>50:
                on_r=on/on_tot; off_r=off_/off_tot
                if on_r>0.8 and off_r<0.2:
                    print(f"  byte {byte} bit {bit}: ON={on_r:.0%} OFF={off_r:.0%}  <- request/active bit")
    return 0

if __name__=="__main__":
    sys.exit(main(sys.argv[1:]))
