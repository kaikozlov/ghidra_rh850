# Panda safety spec — TSS 3.0 longitudinal (0x160 modify-and-forward)

This is the remaining piece for LIVE longitudinal. It is the actual safety
barrier, it must pass the opendbc/panda safety test suite (`test_toyota`) before
flashing, and it is the component the edit classifier blocks the assistant from
writing. Written as a precise spec so it can be implemented and reviewed
deliberately, not pasted in blind.

All file references are `opendbc_repo/opendbc/safety/modes/toyota.h` unless noted.

## Context that makes this different from every existing Toyota

`toyota_rx_hook` processes **only `msg->bus == 0U`**. On this car's STOCK wiring:

- bus 0 / bus 2 = the ADAS CAN FD bus (camera, relayed pair)
- bus 1        = the powertrain (speed, brake, gas, cruise state) — UNRELAYED

So the existing RX hook reads none of the safety inputs on TSS3: `0x260`, `0xaa`,
`0x1D2`/`0x176`, brake and gas are all absent from bus 0 here. A TSS3 branch must
read them from **bus 1**. Without it, `controls_allowed` never sets correctly and
the accel check either blocks everything or is mis-gated.

## 1. TX allowlist

Add a TSS3 long TX table (guard behind the TSS3 param, ALLOW_DEBUG like SECOC):

```c
#define TOYOTA_TSS3_LONG_TX_MSGS \
  {0x160, 0, 32, .check_relay = true},   /* ADAS_ACC_REQUEST, camera->gateway */

static const CanMsg TOYOTA_TSS3_LONG_TX_MSGS_ARR[] = { TOYOTA_TSS3_LONG_TX_MSGS };
```

`{0x160, 0, 32, .check_relay = true}` does double duty:
- permits openpilot to transmit 0x160 on bus 0 (to the gateway), and
- blocks the camera's own 0x160 from auto-forwarding bus2->bus0
  (`safety_fwd_hook` blocks a `check_relay` msg whose addr matches and whose
  `bus == destination_bus`).

VERIFY: `CanMsg.len` and the tx path accept 32 (CAN FD) on the cuatro/H7 build.
The forwarding path (panda `board/drivers/fdcan.h`) already preserves FD; confirm
the tx allowlist length check does too (`len == 32` must be permitted).

## 2. TX hook — accel bounds on 0x160

In `toyota_tx_hook`, before the generic checks, add:

```c
if (toyota_tss3 && (msg->addr == 0x160U) && (msg->bus == 0U)) {
  // ACCEL_REQ: bits 33..47, 15-bit signed big-endian, 0.001 m/s^2.
  // byte4 bit7 (0x80) is a constant flag ABOVE the field -- mask it off.
  int accel = ((msg->data[4] & 0x7FU) << 8) | msg->data[5];
  accel = to_signed(accel, 15);              // 15-bit two's complement
  const LongitudinalLimits TOYOTA_TSS3_LONG_LIMITS = {
    .max_accel = 1500,                        // 1.5 m/s^2 * 1000
    .min_accel = -1500,                       // clamp matches carcontroller
  };
  bool violation = longitudinal_accel_checks(accel, TOYOTA_TSS3_LONG_LIMITS);
  return !violation;
}
```

Units: `longitudinal_accel_checks` compares against the limits in the same raw
units as the extracted value, so keep the extracted `accel` in counts (0.001)
and set the limits in counts (±1500). Double-check against how the existing
`TOYOTA_LONG_LIMITS` are scaled in this build before trusting the numbers.

## 3. RX hook — a TSS3 branch reading bus 1

Add, gated on `toyota_tss3`, reading from `msg->bus == 1U`:

```c
if (toyota_tss3 && (msg->bus == 1U)) {
  // cruise engaged: 0x8A STEER_ANGLE_ACC_STATUS, ACC_ENGAGED (byte 22 mask 0x10)
  // decoded 2026-09-09, 99.67% agreement with 0x13C LON_ACTIVE, leads by ~100ms
  if (msg->addr == 0x8AU) {
    bool cruise_engaged = (msg->data[22] & 0x10U) != 0U;
    pcm_cruise_check(cruise_engaged);
  }
  // speed: 0xaa WHEEL_SPEEDS, same layout/scale as classic Toyota (raw*0.01-67.67)
  if (msg->addr == 0xAAU) {
    int speed = 0;
    for (uint8_t i = 0U; i < 8U; i += 2U) {
      int ws = ((msg->data[i] & 0x7FU) << 8U) | msg->data[i + 1U];
      speed += ws - 6767;
    }
    vehicle_moving = speed != 0;
    UPDATE_VEHICLE_SPEED(speed / 4.0 * 0.01 * KPH_TO_MS);
  }
  // brake: 0x101 BRAKE_MODULE, bit 3 (same as the SECOC rav4 path)
  if (msg->addr == 0x101U) {
    brake_pressed = GET_BIT(msg, 3U);
  }
  // gas: 0x116 GAS_PEDAL, byte 1 (== byte 0). DECODED + VALIDATED route 16:
  // 0 at rest, 100% zero while braking, gas+brake never overlap. This is the
  // exact address+byte the existing SecOC path already uses, so match it.
  if (msg->addr == 0x116U) {
    gas_pressed = msg->data[1] != 0U;
  }
}
```

### Gas pedal — DECODED (gap closed 2026-09-09)

`0x116` GAS_PEDAL, byte 1, on bus 1. Verified against route 16: 72% zero
overall, **100% zero while braking**, max 154, and gas!=0 & brake!=0 never
co-occur (0 frames). carstate now sets `ret.gasPressed = GAS_PEDAL_USER != 0`,
matching this `!= 0` check so openpilot and panda agree (no controls mismatch).
This is byte-identical to what the panda SecOC path reads on other Toyotas.

## 4. Param + init wiring

- Define `TOYOTA_PARAM_TSS3 = 16UL << TOYOTA_PARAM_OFFSET;` (guard ALLOW_DEBUG
  like SECOC), and `static bool toyota_tss3 = false;` set from the param.
- In `toyota_init`, when `toyota_tss3`: `SET_TX_MSGS(TOYOTA_TSS3_LONG_TX_MSGS_ARR, ret)`
  and `SET_RX_CHECKS` to a TSS3 set covering the bus-1 messages above
  (0x8A, 0xAA, 0x101 on bus 1). Use `.ignore_checksum`/`.ignore_counter` for the
  ones whose checksum/counter the panda does not verify.
- The safetyParam from interface.py must include this TSS3 flag (values.py
  ToyotaSafetyFlags.TSS3 = 16 << 8 already exists).

## 5. Relay

Opens automatically: any non-silent safety (toyota) drives
`set_intercept_relay(true, false)`. No change needed.

## 6. Test before flashing — MANDATORY

- Run `test_toyota.py` in the opendbc safety suite with a TSS3 case: assert
  0x160 tx is blocked when accel is out of bounds, allowed in bounds only when
  controls_allowed, and that cruise/brake/speed gate controls_allowed from bus 1.
- Confirm the camera's 0x160 is blocked from forwarding (no duplicate on bus 0).
- Only then build + flash. Bring up in SHADOW first (safety stays noOutput,
  planner runs, nothing transmits), compare openpilot's intended accel to the
  camera's request offline (shadow_compare.py / find_adas_accel.py), and only
  raise to LIVE once that looks sane.
