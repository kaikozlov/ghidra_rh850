#!/usr/bin/env python3
"""SHADOW lateral: openpilot's desired steer angle vs the gateway's 0x1A0 command.

In TSS3_LAT_MODE = SHADOW the panda stays noOutput (nothing tx'd) but openpilot
runs its angle planner and logs carControl.actuators.steeringAngleDeg. This
compares that against the gateway's own 0x1A0 STEER_ANGLE_CMD while LTA is active.
If openpilot's desired angle tracks the stock command, the angle path is sane and
LIVE (relay-first, then nudge) is reasonable.

    python shadow_compare_1a0.py rlog... 
"""
import sys, math, bisect

STEER_SCALE = 0.0148

def gw_angle(d):
    v = (d[11] << 8) | d[12]
    if v >= 0x8000: v -= 0x10000
    return v * STEER_SCALE

def main(paths):
    from openpilot.tools.lib.logreader import LogReader as OP
    from opendbc.car.logreader import LogReader as CAN
    op=[]; t0=None
    for p in paths:
        for m in OP(p):
            if m.which()=="carControl":
                t=m.logMonoTime/1e9
                if t0 is None: t0=t
                cc=m.carControl
                try: op.append((t-t0, cc.actuators.steeringAngleDeg, bool(cc.latActive)))
                except Exception: pass
    gw=[]; req=[]; t0b=None
    for p in paths:
        for m in CAN(p, only_union_types=True):
            if m.which()!="can": continue
            t=m.logMonoTime/1e9
            if t0b is None: t0b=t
            for c in m.can:
                if c.src in (0,2) and c.address==0x1a0:
                    d=bytes(c.dat)
                    gw.append((t-t0b, gw_angle(d)))
                    req.append((t-t0b, (d[6]>>6)&1))
    if not op: 
        print("no carControl -- SHADOW needs openpilot lateral active (engage on a marked road)"); return 1
    if not gw:
        print("no 0x1A0 on bus 0/2"); return 1
    rt=[r[0] for r in req]
    def steering(tq):
        if not rt: return False
        i=min(bisect.bisect_left(rt,tq),len(req)-1); return req[i][1]==1
    gt=[g[0] for g in gw]
    pairs=[]
    for t,a_op,la in op:
        if not la or not steering(t): continue
        i=bisect.bisect_left(gt,t); best=None
        for j in (i-1,i):
            if 0<=j<len(gw) and abs(gw[j][0]-t)<0.1:
                if best is None or abs(gw[j][0]-t)<abs(gw[best][0]-t): best=j
        if best is not None: pairs.append((t, gw[best][1], a_op))
    print(f"carControl {len(op)}, 0x1A0 {len(gw)}, compared (op lat + LTA steering) {len(pairs)}")
    if len(pairs)<50:
        print("too few overlapping samples; engage openpilot lateral while stock LTA steers")
        return 1
    n=len(pairs); xs=[p[1] for p in pairs]; ys=[p[2] for p in pairs]
    mx=sum(xs)/n; my=sum(ys)/n
    sxy=sum((x-mx)*(y-my) for x,y in zip(xs,ys)); sxx=sum((x-mx)**2 for x in xs); syy=sum((y-my)**2 for y in ys)
    r=sxy/math.sqrt(sxx*syy) if sxx>0 and syy>0 else float('nan')
    rms=math.sqrt(sum((x-y)**2 for x,y in zip(xs,ys))/n)
    print(f"\ngateway angle  mean {mx:+.2f}  range {min(xs):+.1f}..{max(xs):+.1f} deg")
    print(f"openpilot want mean {my:+.2f}  range {min(ys):+.1f}..{max(ys):+.1f} deg")
    print(f"correlation r : {r:+.3f}")
    print(f"RMS diff      : {rms:.2f} deg")
    print("\nGo/no-go: r>0.8 and RMS<3 deg -> openpilot's angle tracks the stock LTA; LIVE reasonable.")
    print("r near 0 or big RMS -> planner/units/sign issue; do NOT go LIVE.")
    return 0

if __name__=="__main__":
    sys.exit(main(sys.argv[1:]))
