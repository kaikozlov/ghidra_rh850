#!/usr/bin/env python3
"""Dependency-free structural check of a DBC.

Catches the class of mistake that is easy to make when hand-converting
"byte N, mask 0xNN" notes into DBC start bits: signals that run off the end of
the message, and signals that silently overlap each other.

Usage: python lint_dbc.py ../opendbc/dbc/toyota_corolla_tss3_pt.dbc
"""
import re
import sys

BO_RE = re.compile(r"^BO_ (\d+) (\w+) *: *(\d+) *(\w+)")
SG_RE = re.compile(r"^\s*SG_ (\w+) *: *(\d+)\|(\d+)@(\d)([-+])")


def be_bits(start, length):
    """MSB-first stream indices occupied by a big-endian signal."""
    stream_start = (start // 8) * 8 + (7 - (start % 8))
    return list(range(stream_start, stream_start + length))


def le_bits(start, length):
    return [(b // 8) * 8 + (7 - (b % 8)) for b in range(start, start + length)]


def main(path):
    errors, warnings, msgs = [], [], []
    addr = name = None
    dlc = 0
    occupied = {}

    for lineno, line in enumerate(open(path, encoding="utf-8"), 1):
        m = BO_RE.match(line)
        if m:
            addr, name, dlc = int(m.group(1)), m.group(2), int(m.group(3))
            occupied = {}
            msgs.append((addr, name, dlc))
            continue
        m = SG_RE.match(line)
        if not m:
            continue
        if addr is None:
            errors.append(f"{lineno}: SG_ before any BO_")
            continue
        sig, start, length, endian = m.group(1), int(m.group(2)), int(m.group(3)), m.group(4)
        bits = be_bits(start, length) if endian == "0" else le_bits(start, length)
        if max(bits) >= dlc * 8:
            errors.append(
                f"{lineno}: {name}({addr:#x}).{sig} runs past DLC {dlc}: "
                f"needs bit {max(bits)}, message has {dlc * 8}"
            )
        for b in bits:
            if b in occupied:
                warnings.append(
                    f"{lineno}: {name}({addr:#x}).{sig} overlaps {occupied[b]} at stream bit {b}"
                )
                break
        for b in bits:
            occupied[b] = sig
        if length % 8 == 0 and min(bits) % 8 != 0:
            warnings.append(
                f"{lineno}: {name}({addr:#x}).{sig} is {length} bits but not byte aligned "
                f"(startbit {start}; byte {min(bits) // 8} aligned would be {(min(bits) // 8) * 8 + 7})"
            )
        byte0, byteN = min(bits) // 8, max(bits) // 8
        span = f"byte {byte0}" if byte0 == byteN else f"bytes {byte0}-{byteN}"
        print(f"  {name:<24} {addr:#5x} {sig:<16} {start}|{length}@{endian} -> {span}")

    dupes = {a for a, _, _ in msgs if [x[0] for x in msgs].count(a) > 1}
    for a in dupes:
        errors.append(f"duplicate address {a:#x}")

    print(f"\n{len(msgs)} messages")
    for w in warnings:
        print(f"WARN  {w}")
    for e in errors:
        print(f"ERROR {e}")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
