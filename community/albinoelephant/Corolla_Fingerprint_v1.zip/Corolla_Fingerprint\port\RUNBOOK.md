# TSS 3.0 longitudinal — bring-up runbook

Every command below is matched to YOUR actual setup (verified 2026-09-09):
WSL build tree at `~/tss3`, device at `192.168.1.91`, device python
`/usr/local/venv/bin/python3` with `PYTHONPATH=/data/openpilot`.

Do the steps in order. Do not skip step 2 (safety tests) or step 4 (SHADOW).

--------------------------------------------------------------------------------
## Step 1 — Build the panda firmware (WSL)

The new safety code (`toyota.h`, 0x160 modify-and-forward) is ALREADY copied into
your build tree at `~/tss3/opendbc_repo/opendbc/safety/modes/toyota.h`. If you
ever need to re-sync it:

    cp /mnt/c/Users/plata/Documents/Random_Programs/Corolla_Fingerprint/port/panda_src/toyota.h \
       ~/tss3/opendbc_repo/opendbc/safety/modes/toyota.h

Build (DEBUG build auto-defines ALLOW_DEBUG, which the TSS3 param needs):

    source ~/tss3/venv/bin/activate
    cd ~/tss3/panda_tss3
    export PYTHONPATH=~/tss3/opendbc_repo:$PYTHONPATH
    rm -f board/obj/panda_h7.bin.signed
    scons -u -j$(nproc) board/obj/panda_h7.bin.signed

Success = `board/obj/panda_h7.bin.signed` exists with a fresh timestamp.
Do NOT set the RELEASE env var — that would drop ALLOW_DEBUG and the TSS3 mode
would silently do nothing.

--------------------------------------------------------------------------------
## Step 2 — Safety tests on the EXACT code you just built (WSL)  [MANDATORY]

This is the barrier between openpilot and your brakes. Run it against the same
opendbc tree the firmware was built from.

    cp /mnt/c/Users/plata/Documents/Random_Programs/Corolla_Fingerprint/port/tools/test_toyota_tss3.py \
       ~/tss3/opendbc_repo/opendbc/safety/tests/
    cd ~/tss3/opendbc_repo
    ALLOW_DEBUG=1 PYTHONPATH=. python3 opendbc/safety/tests/test_toyota_tss3.py

Expect: `Ran 7 tests ... OK`.

Regression — confirm you did not break stock Toyota safety:

    ALLOW_DEBUG=1 PYTHONPATH=. python3 opendbc/safety/tests/test_toyota.py

Expect: `OK (skipped=...)`, ~1118 tests. If ANYTHING fails, STOP and fix before
flashing.

--------------------------------------------------------------------------------
## Step 3 — Put the firmware on the device and flash it

pandad flashes the panda to whatever `board/obj/panda_h7.bin.signed` is ON THE
DEVICE, and refuses to start if the running panda does not match it. So you just
replace that file and let pandad do the flash. This is why it sticks.

From WSL (or the PC):

    # copy the new firmware to the device, overwriting the one openpilot ships
    scp ~/tss3/panda_tss3/board/obj/panda_h7.bin.signed \
        comma@192.168.1.91:/data/openpilot/panda/board/obj/panda_h7.bin.signed

Then on the device, restart openpilot so pandad reflashes the internal panda:

    ssh comma@192.168.1.91
    # note the CURRENT signature so you can confirm it changed
    cd /data/openpilot/panda && PYTHONPATH=/data/openpilot /usr/local/venv/bin/python3 \
      -c "from panda import Panda; print('before', Panda().get_signature().hex()[:16])"
    sudo systemctl restart comma
    # give it ~60s to detect the mismatch and reflash, then verify:
    cd /data/openpilot/panda && PYTHONPATH=/data/openpilot /usr/local/venv/bin/python3 \
      -c "from panda import Panda; print('after ', Panda().get_signature().hex()[:16])"

The `after` signature MUST differ from `before`. If it did not change, pandad
did not reflash -- check `board/obj/panda_h7.bin.signed` on the device is really
your new file (compare `sha256sum` on both ends).

DisableUpdates=1 is already set, so openpilot will not overwrite /data/openpilot
with a fresh release and revert your files.

--------------------------------------------------------------------------------
## Step 4 — SHADOW: planner runs, NOTHING is transmitted  [MANDATORY before LIVE]

SHADOW keeps the panda in noOutput (zero tx, stock ACC drives the car) while
openpilot runs its longitudinal planner. You compare intent vs the camera's
request offline. Zero risk.

On the device, set the mode and enable the alpha-long toggle:

    ssh comma@192.168.1.91
    sed -i 's/^TSS3_LONG_MODE = .*/TSS3_LONG_MODE = TSS3LongMode.SHADOW/' \
      /data/openpilot/opendbc_repo/opendbc/car/toyota/values.py
    grep -n "TSS3_LONG_MODE = " /data/openpilot/opendbc_repo/opendbc/car/toyota/values.py
    # enable openpilot longitudinal (read at car start -> needs an ignition cycle)
    echo -n "1" > /data/params/d/AlphaLongitudinalEnabled
    sudo systemctl restart comma

Confirm the safety model is STILL noOutput in SHADOW (nothing can transmit):

    cd /data/openpilot && PYTHONPATH=/data/openpilot /usr/local/venv/bin/python3 -c "
    from opendbc.car.toyota.interface import CarInterface
    r=CarInterface.get_params('TOYOTA_COROLLA_TSS3', {i:{} for i in range(8)}, [], alpha_long=True, is_release=False, docs=False)
    CarInterface.get_params_sp(r, 'TOYOTA_COROLLA_TSS3', {i:{} for i in range(8)}, [], True, False, False)
    print('safety', [(str(c.safetyModel),c.safetyParam) for c in r.safetyConfigs], 'oplong', r.openpilotLongitudinalControl)
    "
    # EXPECT: safety [('noOutput', 0)]  oplong True   <- planner runs, tx blocked

Drive: engage the STOCK ACC (stalk) as normal and let openpilot's longitudinal
be "engaged" at the same time. Do your usual +/- and lead-follow. Then pull the
route and compare:

    # from the PC:
    scp C:/Users/plata/Documents/Random_Programs/Corolla_Fingerprint/port/tools/shadow_compare_160.py comma@192.168.1.91:/tmp/
    ssh comma@192.168.1.91 'cd /data/openpilot && PYTHONPATH=/data/openpilot /usr/local/venv/bin/python3 \
      /tmp/shadow_compare_160.py /data/media/0/realdata/<ROUTE>--*/rlog.zst'

GO / NO-GO:
  r > 0.8 and RMS < 0.5 m/s^2  -> planner tracks the camera. LIVE is reasonable.
  r near 0, or large bias      -> STOP. Sign/units/planner problem. Do not go LIVE.

--------------------------------------------------------------------------------
## Step 5 — LIVE: openpilot actually transmits 0x160

Only after a clean SHADOW result.

    ssh comma@192.168.1.91
    sed -i 's/^TSS3_LONG_MODE = .*/TSS3_LONG_MODE = TSS3LongMode.LIVE/' \
      /data/openpilot/opendbc_repo/opendbc/car/toyota/values.py
    sudo systemctl restart comma

Confirm the panda is now in toyota safety with the TSS3 flag:

    cd /data/openpilot && PYTHONPATH=/data/openpilot /usr/local/venv/bin/python3 -c "
    from opendbc.car.toyota.interface import CarInterface
    r=CarInterface.get_params('TOYOTA_COROLLA_TSS3', {i:{} for i in range(8)}, [], alpha_long=True, is_release=False, docs=False)
    CarInterface.get_params_sp(r, 'TOYOTA_COROLLA_TSS3', {i:{} for i in range(8)}, [], True, False, False)
    print('safety', [(str(c.safetyModel),c.safetyParam) for c in r.safetyConfigs], 'oplong', r.openpilotLongitudinalControl)
    "
    # EXPECT: safety [('toyota', <n>)]  oplong True   (n includes the TSS3 flag)

FIRST DRIVE:
  - empty road, no traffic, hand hovering the brake, ready to cancel
  - openpilot only overrides while the STOCK ACC is already active: engage ACC
    with the stalk exactly as normal; openpilot then adjusts the accel
  - a brake tap or the stalk cancel drops stock ACC -> openpilot stops overriding
  - the accel is hard-clamped to +/-1.5 m/s^2 in BOTH the carcontroller and the
    panda; the panda blocks anything outside that or when not engaged

To go back to lateral-only / read-only at any time:

    sed -i 's/^TSS3_LONG_MODE = .*/TSS3_LONG_MODE = TSS3LongMode.OFF/' \
      /data/openpilot/opendbc_repo/opendbc/car/toyota/values.py
    sudo systemctl restart comma

--------------------------------------------------------------------------------
## If something goes wrong

- Device won't go onroad after flashing / pandad crashes: the device's
  `board/obj/panda_h7.bin.signed` and the flashed panda disagree. Re-copy the
  file (step 3) and restart. Worst case, restore the stock fw by re-copying the
  release's obj file and restarting.
- "CAN bus disconnected / faulty cable": that was the OLD 0x13C-on-bus-1 attempt.
  It should not recur -- 0x160 is on the relayed ADAS bus, the supported
  topology. If it does, set TSS3_LONG_MODE = OFF and restart, then tell me.
- Camera/ACC warnings on the dash in LIVE: expected transient while openpilot
  takes over the request; if persistent, disengage and pull the route.
