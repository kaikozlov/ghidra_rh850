#!/usr/bin/env python3
"""For idle-when-off candidates, correlate the field vs measured steer angle
DURING ENGAGED periods, and fit a scale. The steering COMMAND (target angle)
tracks the measured angle; report r, fitted deg/count, and message length."""
import sys, bisect, math
from collections import defaultdict

CANDS=[(0,0x1a0,17),(1,0x27c,3),(1,0x671,2),(1,0x5af,26),(1,0x252,1),(0,0x201,45)]

def s16be(d,i):
    if i+1>=len(d): return None
    v=(d[i]<<8)|d[i+1]; return v-0x10000 if v>=0x8000 else v

def main(paths):
    from openpilot.tools.lib.logreader import LogReader as OP
    from opendbc.car.logreader import LogReader as CAN
    ang=[]; t0=None
    for p in paths:
        for m in OP(p):
            if m.which()=="carState":
                t=m.logMonoTime/1e9
                if t0 is None: t0=t
                ang.append((t-t0,m.carState.steeringAngleDeg))
    at=[a[0] for a in ang]
    def ang_at(tq):
        i=bisect.bisect_left(at,tq)
        for j in (i-1,i):
            if 0<=j<len(ang) and abs(ang[j][0]-tq)<0.05: return ang[j][1]
        return None
    eng=[]; frames=defaultdict(list); lens={}; t0b=None
    want={a for _,a,_ in CANDS}|{0x8A}
    for p in paths:
        for m in CAN(p, only_union_types=True):
            if m.which()!="can": continue
            t=m.logMonoTime/1e9
            if t0b is None: t0b=t
            for c in m.can:
                if c.address in want and c.src in (0,1,2):
                    d=bytes(c.dat)
                    if c.address==0x8A and c.src==1 and len(d)>=23: eng.append((t-t0b,1 if d[22]&0x10 else 0))
                    frames[(c.src,c.address)].append((t-t0b,d)); lens[(c.src,c.address)]=len(d)
    et=[e[0] for e in eng]
    def eng_at(tq):
        if not et: return 0
        i=min(bisect.bisect_left(et,tq),len(eng)-1); return eng[i][1]
    print(f"{'bus':>3} {'addr':>7} {'byte':>4} {'len':>3} {'r_eng':>7} {'deg/cnt':>9}  note")
    for bus,addr,off in CANDS:
        fr=frames.get((bus,addr))
        if not fr: continue
        xs=[];ys=[]
        for t,d in fr:
            if eng_at(t)!=1: continue
            a=ang_at(t); v=s16be(d,off)
            if a is None or v is None: continue
            xs.append(v); ys.append(a)
        if len(xs)<50: 
            print(f"{bus:3d} {addr:#07x} {off:4d} {lens[(bus,addr)]:3d}  (few samples)"); continue
        n=len(xs); mx=sum(xs)/n; my=sum(ys)/n
        sxx=sum((x-mx)**2 for x in xs); syy=sum((y-my)**2 for y in ys)
        sxy=sum((x-mx)*(y-my) for x,y in zip(xs,ys))
        r=sxy/math.sqrt(sxx*syy) if sxx>0 and syy>0 else float('nan')
        scale=sxy/sxx if sxx>0 else float('nan')   # deg per count
        print(f"{bus:3d} {addr:#07x} {off:4d} {lens[(bus,addr)]:3d} {r:+7.2f} {scale:9.4f}")
    return 0

if __name__=="__main__":
    sys.exit(main(sys.argv[1:]))
