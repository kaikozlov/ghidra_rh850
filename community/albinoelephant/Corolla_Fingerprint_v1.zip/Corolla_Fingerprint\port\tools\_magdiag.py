import glob, bisect
from openpilot.tools.lib.logreader import LogReader as OP
segs=sorted(glob.glob("/data/media/0/realdata/00000023--4b94a1ecef--*/rlog.zst"))
op=[]; meas=[]
for s in segs:
    for m in OP(s):
        if m.which()=="carControl" and m.carControl.latActive:
            op.append(m.carControl.actuators.steeringAngleDeg)
        elif m.which()=="carState":
            meas.append(abs(m.carState.steeringAngleDeg))
op_abs=sorted(abs(x) for x in op)
def pct(a,p): return a[int(len(a)*p)] if a else 0
print("op desired |angle| percentiles (latActive):")
for p in (0.5,0.8,0.9,0.95,0.99):
    print(f"  p{int(p*100)}: {pct(op_abs,p):.1f} deg")
print(f"  max: {op_abs[-1]:.1f}")
over17=sum(1 for x in op_abs if x>17)/len(op_abs)
print(f"frac of latActive frames with |desired|>17 deg: {over17*100:.0f}%")
ms=sorted(meas)
print(f"measured |angle| p90={pct(ms,0.9):.0f} p99={pct(ms,0.99):.0f} max={ms[-1]:.0f}")
