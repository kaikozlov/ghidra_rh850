#!/usr/bin/env python3
"""Find the camera's ACC request on the TSS 3.0 ADAS CAN FD bus.

0x13C ACC_CONTROL lives on the POWERTRAIN bus (bus 1, unrelayed), so openpilot
can never replace it by opening the harness relay. But the front camera sits on
the ADAS CAN FD bus (bus 0 <-> bus 2), which IS relayed. If the camera is what
asks for acceleration, some message there must track 0x13C.ACCEL_CMD -- and that
message IS interceptable.

This scans every (address, byte-offset) on bus 0 as a candidate 16-bit signed
big-endian field, time-aligns it against 0x13C.ACCEL_CMD on bus 1, and ranks by
|Pearson r|. It also reports which addresses merely change state with ACC, which
is a weaker but still useful signal (engage/disengage, gap setting, HUD).

    python find_adas_accel.py rlog.zst [rlog2.zst ...]

Needs a drive where ACCEL_CMD actually MOVES. A constant-speed cruise correlates
with everything and nothing.
"""
import sys
import math
import bisect
from collections import defaultdict

try:
    from opendbc.car.logreader import LogReader
except ImportError as e:  # pragma: no cover
    sys.exit(f"need opendbc importable: {e}")

PT_BUS = 1        # powertrain, where 0x13C is
ADAS_BUS = 0      # relayed CAN FD bus, where the camera is
ACC_CONTROL = 0x13C


def s16be(d, i):
    if i + 1 >= len(d):
        return None
    v = (d[i] << 8) | d[i + 1]
    return v - 0x10000 if v >= 0x8000 else v


def pearson(xs, ys):
    n = len(xs)
    if n < 30:
        return float('nan')
    mx, my = sum(xs) / n, sum(ys) / n
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    sxx = sum((x - mx) ** 2 for x in xs)
    syy = sum((y - my) ** 2 for y in ys)
    if sxx <= 0 or syy <= 0:
        return float('nan')
    return sxy / math.sqrt(sxx * syy)


def main(paths):
    stock = []                                  # (t, accel_m_s2, lon_active)
    adas = defaultdict(list)                    # addr -> [(t, bytes)]
    t0 = None

    for path in paths:
        for msg in LogReader(path, only_union_types=True):
            if msg.which() != "can":
                continue
            t = msg.logMonoTime / 1e9
            if t0 is None:
                t0 = t
            for c in msg.can:
                if c.src == PT_BUS and c.address == ACC_CONTROL:
                    d = bytes(c.dat)
                    if len(d) >= 8:
                        raw = s16be(d, 0)
                        stock.append((t - t0, raw * 0.001, bool(d[4] & 0x20)))
                elif c.src == ADAS_BUS:
                    adas[c.address].append((t - t0, bytes(c.dat)))

    if not stock:
        sys.exit(f"no 0x13C on bus {PT_BUS} -- wrong bus, or ACC never used?")
    if not adas:
        sys.exit(f"no traffic on bus {ADAS_BUS}")

    active = [s for s in stock if s[2]]
    accels = [s[1] for s in active]
    print(f"0x13C frames        : {len(stock)}  ({len(active)} with LON_ACTIVE)")
    if active:
        print(f"ACCEL_CMD while active: {min(accels):+.2f} .. {max(accels):+.2f} m/s^2, "
              f"spread {max(accels) - min(accels):.2f}")
    print(f"ADAS bus {ADAS_BUS} addresses: {len(adas)}\n")

    if len(active) < 200:
        print("!! Too few LON_ACTIVE samples. Drive with ACC ENGAGED for longer.\n")
    elif max(accels) - min(accels) < 0.5:
        print("!! ACCEL_CMD barely moved. Correlation needs the car to actually\n"
              "   speed up and slow down under ACC.\n")

    at = [a[0] for a in active]
    results = []
    for addr, frames in sorted(adas.items()):
        if len(frames) < 100:
            continue
        maxlen = min(len(f[1]) for f in frames)
        ft = [f[0] for f in frames]
        # align each ADAS frame to the nearest 0x13C sample within 60 ms
        idx = []
        for t, _ in frames:
            i = bisect.bisect_left(at, t)
            best = None
            for j in (i - 1, i):
                if 0 <= j < len(active) and abs(at[j] - t) < 0.06:
                    if best is None or abs(at[j] - t) < abs(at[best] - t):
                        best = j
            idx.append(best)
        ys = [active[j][1] for j in idx if j is not None]
        if len(ys) < 100:
            continue
        for off in range(maxlen - 1):
            xs = [s16be(f[1], off) for f, j in zip(frames, idx) if j is not None]
            if any(x is None for x in xs):
                continue
            r = pearson(xs, ys)
            if not math.isnan(r) and abs(r) > 0.5:
                results.append((abs(r), r, addr, off, min(xs), max(xs)))

    results.sort(reverse=True)
    print("=== 16-bit big-endian fields on the ADAS bus vs 0x13C.ACCEL_CMD ===")
    if not results:
        print("nothing above |r| = 0.5.")
        print("Either the camera does not send an accel request in this form")
        print("(try little-endian / different width), or ACCEL_CMD did not move.")
    else:
        print(f"{'addr':>7} {'byte':>5} {'r':>7}  raw range")
        for _, r, addr, off, lo, hi in results[:25]:
            print(f"  {addr:#05x} {off:5d} {r:+7.3f}  {lo} .. {hi}")
        print("\nA field with r near +/-1.0 whose raw range is roughly")
        print("ACCEL_CMD/scale is the camera's acceleration request.")

    # weaker signal: which addresses change payload when ACC engages
    print("\n=== addresses whose payload differs ACC-active vs ACC-idle ===")
    idle = [s for s in stock if not s[2]]
    if not idle or not active:
        print("need both engaged and disengaged time in the same drive -- skipped.")
        return 0
    act_spans = _spans([(t, a) for t, _, a in stock])
    changed = []
    for addr, frames in sorted(adas.items()):
        on, off_ = [], []
        for t, d in frames:
            (on if _in(act_spans, t) else off_).append(d)
        if len(on) < 20 or len(off_) < 20:
            continue
        maxlen = min(min(len(x) for x in on), min(len(x) for x in off_))
        diff = [i for i in range(maxlen)
                if not ({x[i] for x in on[:400]} & {x[i] for x in off_[:400]})]
        if diff:
            changed.append((addr, diff))
    for addr, diff in changed:
        print(f"  {addr:#05x}  bytes {diff}")
    if not changed:
        print("  none -- the ADAS bus payloads do not visibly track ACC state.")
    return 0


def _spans(samples):
    spans, start = [], None
    for t, a in samples:
        if a and start is None:
            start = t
        elif not a and start is not None:
            spans.append((start, t))
            start = None
    if start is not None:
        spans.append((start, samples[-1][0]))
    return spans


def _in(spans, t):
    return any(lo <= t <= hi for lo, hi in spans)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
