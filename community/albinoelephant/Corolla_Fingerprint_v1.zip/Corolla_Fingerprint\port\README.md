# Toyota Corolla TSS 3.0 — sunnypilot port (fingerprint + longitudinal)

Bring-up of a **2023 Toyota Corolla (TSS 3.0: CAN FD + SecOC)** on sunnypilot,
running on a comma 3X/4-class device (`mici` UI, `cuatro` internal panda).

This document records exactly what was changed, and why, to get (A) the car to
fingerprint and render a normal drive view with live carState, and (B) openpilot
longitudinal control working by replacing the camera's acceleration request.

It is written against these baselines ("the branches provided"):

| Component | Baseline |
|---|---|
| opendbc | `b4ef5e1cf406ff143fa67bdbfb154739d43279c9` (as vendored in sunnypilot) |
| panda   | `75aa44bec9140849868239b1f1e3f22624adb8fe` |
| sunnypilot | staging (`v2026.003.000`) |

Everything below is additive: no existing Toyota behavior changes. The full
panda safety regression (`test_toyota.py`, 1118 tests) still passes.

--------------------------------------------------------------------------------
## 1. Why TSS 3.0 is different

Older Toyotas openpilot supports are classic CAN (500 kbps, 8-byte frames), with
the ACC command (`0x343`/`0x183`) plaintext or a simple checksum. TSS 3.0 changes
three things at once:

1. **CAN FD** — the ADAS bus is CAN FD (32-byte frames, 2 Mbit/s data phase).
2. **SecOC** — powertrain safety messages carry AES-CMAC authenticators.
3. **AUTOSAR E2E** — the camera's ACC request carries a CRC + rolling counter.

And the physical bus layout is not what a classic Toyota harness assumes. Getting
the bus map right (Section 3) was a prerequisite for everything else.

--------------------------------------------------------------------------------
## 2. Bus topology (measured, not assumed)

With **stock harness wiring** (comma harness intercepting the T21 camera
connector, pins 9-16; pins 1-8 untouched), measured on real routes:

```
panda bus 1  = POWERTRAIN  (149 addrs incl. 0x13C, speed, brake, gas, cruise)
               classic + some 32-byte FD (SecOC). UNRELAYED.
panda bus 0  \ ADAS CAN FD (camera + radar/gateway). THE RELAYED PAIR.
panda bus 2  / camera is on bus 2; radar + gateway on bus 0.
```

Key facts established by measurement:
- The **powertrain is on bus 1**, not bus 0. Classic Toyota ports assume bus 0,
  so the port reads carState from bus 1 (`TSS3_PT_BUS = 1`).
- The **camera alone sits on bus 2**; a camera-unplug test showed `0x020, 0x160,
  0x230, 0x440` vanish when the camera is disconnected, while the other ~18 ADAS
  addresses (radar/gateway) remain on bus 0.
- The comma relay switches the bus 0 <-> bus 2 pair. This is the correct topology
  for interception: opening the relay isolates the camera, and the panda forwards
  bus 2 -> bus 0. (An earlier pin-swapped wiring put the *powertrain* on the
  relay pair, which bus-off'd when the relay opened — do not do that.)

--------------------------------------------------------------------------------
## 3. Part A — Fingerprint + Phase 1 (read-only)

Goal: the car identifies as `TOYOTA_COROLLA_TSS3`, the model runs and renders
lanes, carState is populated, and **nothing is ever transmitted**.

### Fingerprinting: forced platform, not a fingerprint dict

TSS 3.0 messages are CAN FD and SecOC; the classic byte-length fingerprint under
0x800 does not cleanly identify this car, and generating one was unnecessary.
Instead the platform is forced via the **`CarPlatformBundle`** param, which
sunnypilot/`card.py` applies as `fixed_fingerprint` — an unconditional platform
override. Set once on the device:

```
CarPlatformBundle = {"platform": "TOYOTA_COROLLA_TSS3", "make": "Toyota",
                     "brand": "toyota", "model": "Corolla", "year": ["2023"],
                     "package": "All", "name": "Toyota Corolla 2023"}
```

So there is no `fingerprints.py` change — the platform is selected directly.

### opendbc/car/toyota/values.py

- `ToyotaFlags.CAN_FD = 4096` — new static flag marking this platform.
- `ToyotaSafetyFlags.TSS3 = (16 << 8)` — new panda safety-param flag.
- `ToyotaCanFDSecOCPlatformConfig` — new PlatformConfig; loads the new DBC and
  sets flags `TSS2 | NO_DSU | SECOC | CAN_FD`. (Deliberately NOT a subclass of
  the existing SecOC config, which loads an 8-byte DBC + radar bus that don't
  apply here.)
- `CAR.TOYOTA_COROLLA_TSS3` — the platform, `CarSpecs` reusing the vetted E210
  Corolla numbers (mass, wheelbase 2.64 m coupled to the DBC steer factor,
  steerRatio 13.9, tireStiffnessFactor 0.444), `ToyotaSecOcCarDocs`,
  `minEnableSpeed = MIN_ACC_SPEED` (~19 mph, so no standstill/resume needed for
  Phase 1).
- `TSS3_PT_BUS = 1` — the powertrain bus (see Section 2).

### opendbc/dbc/toyota_corolla_tss3_pt.dbc (new)

Hand-built DBC, every bit decoded from passive rlogs and (where noted) validated
on the car. Messages:

```
0x00F SECOC_SYNCHRONIZATION   trip/reset/authenticator counters
0x030 STEER_ANGLE_SENSOR      32B FD
0x08A STEER_ANGLE_ACC_STATUS  32B FD: steer angle, ACC_STATE, ACC_ENGAGED,
                              ACC_STANDSTILL, ACC_BUTTON (the ACC state source)
0x090 KINEMATICS              yaw rate
0x0AA WHEEL_SPEEDS            4 wheels (classic Toyota scale)
0x0DA STEER_TORQUE_SENSOR
0x116 GAS_PEDAL               driver gas (byte 1)
0x101 BRAKE_MODULE            brake pressed
0x113 ACC_HUD / 0x251 ACC_HUD set speed (mph), engaged HUD bit
0x13C ACC_CONTROL            the gateway's filtered accel command (powertrain)
0x2A1 GEAR_PACKET / 0x3BF GEAR_PACKET_2
0x160 ADAS_ACC_REQUEST        32B FD: the CAMERA's accel request (see Part B)
```

Validated-on-car highlights: `STEER_ANGLE` factor 0.061 deg/count (proven by the
raw int16 saturating at -8211 = -500.9 deg at the steering lock);
`ACC_ENGAGED` (0x8A byte 22 mask 0x10) 99.67% agreement with `0x13C.LON_ACTIVE`;
set speed is the raw byte in mph; `GAS_PEDAL` byte 1 is 100% zero while braking.

### opendbc/car/toyota/carstate.py

- New `update_tss3()` read-only path: wheel speeds, steer angle, yaw, torque,
  brake, **gas** (`GAS_PEDAL` byte 1 != 0), gear, and cruiseState from the 0x8A
  ACC bits and the 0x251 set speed. cruiseState.standstill from the 0x8A hold bit.
- `get_can_parsers()` TSS3 branch: powertrain parser on `TSS3_PT_BUS` (bus 1),
  camera parser on bus 2 (carries `ADAS_ACC_REQUEST` for the longitudinal
  template — see Part B).

### opendbc/car/toyota/interface.py

- TSS3 branch in `_get_params` / `_get_params_sp` setting `flags`, DBC,
  `minEnableSpeed`, and the safety config. In OFF/SHADOW the safety model is
  `noOutput` (panda receives everything, transmits nothing; model still runs and
  renders). `dashcamOnly` stays False — that pair is the Phase-1 guarantee.

### Result

`TOYOTA_COROLLA_TSS3`, `source: fixed`, safety `noOutput`, carState correct,
lanes rendering. Validated on the car (route `00000016`): 54,517 carState msgs,
zero `canError`, gears/brake/cruise all correct.

--------------------------------------------------------------------------------
## 4. Part B — Longitudinal

### The insight: replace the camera, not the powertrain command

`0x13C` (ACC_CONTROL, powertrain bus) is the *gateway's* filtered accel command —
downstream and on the unrelayed bus, so not interceptable. The **camera's**
acceleration request is `0x160` (ADAS_ACC_REQUEST) on the relayed ADAS bus. A
camera-unplug test proved `0x160` is camera-sourced, and it correlates with
`0x13C.ACCEL_CMD` at r = 0.99. So openpilot replaces `0x160`; the gateway filters
it into `0x13C` exactly as it does the camera's.

### Cracking the E2E protection (opendbc/car/toyota/e2e.py, new)

`0x160` bytes 0-1 are an **AUTOSAR E2E CRC**, not a SecOC MAC — keyless, so
forgeable:

```
CRC-16/CCITT  poly 0x1021  init 0x0000  no reflection
over payload[2:] + DataID(0x444A, little-endian)
stored little-endian in bytes 0-1; byte 2 is a +1 rolling counter
```

Verified 100% on 26,290 frames across two sessions. `e2e.py` provides
`e2e_160_checksum`, `apply_e2e_160`, `e2e_160_valid`.

### Modify-and-forward, NO HANDOFF (carcontroller.py, toyotacan.py)

openpilot does **not** synthesize `0x160` (its 32 bytes carry undecoded
perception data). It takes the camera's live frame (captured in carstate from the
bus-2 parser) and re-emits it.

The critical design point, learned on the car: **openpilot is the SOLE emitter of
`0x160` the entire time it is engaged — there is no CAN-level handoff back to the
camera.** Handing control to/from the camera (at stops, at low-speed engage)
created a seam the gateway rejected ("System Malfunction"). Instead openpilot
emits one frame per camera frame (40 Hz), **always stamped with the camera's own
counter** (byte 2) so the E2E sequence is byte-identical to the camera's:

- **actively controlling** (longActive, above `TSS3_MIN_OVERRIDE_SPEED`, no gas):
  substitute `ACCEL_REQ` (bits 33-47, 15-bit signed BE, 0.001 m/s^2) with
  openpilot's accel, clamped to +/-1.5 m/s^2.
- **otherwise** (standstill / below min speed / gas override): **relay** the
  camera's frame verbatim (`accel=None` keeps its bytes), so Toyota's own request
  — including its standstill hold — drives the car while openpilot keeps the
  stream alive.

Only the accel bytes ever vary; the emitter and counter are continuous, so there
is no seam. `toyotacan.modify_accel_160(template, accel_or_None, counter)` does
the byte work (counter + CRC always re-stamped).

The engage gate is aligned across all three layers so a gap can never open:
openpilot emits when `cruiseState.enabled && !gasPressed`; the panda forwards the
camera exactly when `!get_longitudinal_allowed()` (disengaged or gas); the panda
accepts openpilot's tx under the same condition.

### TSS3_LONG_MODE (values.py)

A single switch gates the whole longitudinal path:

- `OFF` — Phase 1. safety `noOutput`, nothing transmitted, no planner.
- `SHADOW` — planner runs, safety stays `noOutput`, nothing transmitted; used to
  compare openpilot's intended accel against the camera's request offline
  (`tools/shadow_compare_160.py`). Zero risk.
- `LIVE` — safety `toyota` with the TSS3 flag; openpilot transmits `0x160`.

SHADOW/LIVE are driven directly by `TSS3_LONG_MODE`, independent of the
`AlphaLongitudinalEnabled` param (that param is auto-deleted offroad, which would
otherwise silently stop the planner).

`TSS3_MIN_OVERRIDE_SPEED = 1.3 m/s` — below this openpilot hands longitudinal
back to the stock system so Toyota's own standstill mechanism does the final stop
and hold (openpilot cannot signal the hold through `0x160`).

### Panda safety (opendbc/safety/modes/toyota.h)

All additive, gated behind `ALLOW_DEBUG` (like SecOC). See
`panda-safety-tss3.patch`. Because the powertrain is on bus 1, the entire TSS3
safety reads from bus 1, unlike every other Toyota (which reads bus 0):

- `static bool toyota_tss3`, param `TOYOTA_PARAM_TSS3 = 16 << 8`.
- **TX allowlist** `{0x160, 0, 32, .check_relay = true, .disable_static_blocking
  = true}` — only message openpilot may send. No lateral tx.
- **TX accel check**: `0x160` ACCEL_REQ bounded to +/-1.5 m/s^2, only when
  `controls_allowed`.
- **RX branch on bus 1**: cruise engaged from `0x8A` (byte 22 bit 4), speed from
  `0xAA`, brake from `0x101` bit 3, gas from `0x116` byte 1.
- **TX accel envelope** = stock Toyota range (max 2000 / min -3500 counts),
  because openpilot RELAYS the camera's own frame (which brakes to ~-3.3 at
  stops) when not actively controlling. openpilot's own substituted accel is
  separately clamped to +/-1.5 in the carcontroller.
- **Forwarding hook** `toyota_fwd_hook`: forwards the camera's `0x160`
  (bus 2 -> bus 0) when `!get_longitudinal_allowed()` (disengaged or gas
  override), and blocks it only when longitudinal is allowed (openpilot is
  emitting its own). Keyed on the exact same state openpilot uses to decide to
  emit, so the gateway always sees a continuous `0x160` and there is never a gap
  (silent openpilot + blocked camera) — the failure mode of the first attempts.
- The relay opens automatically under the (non-silent) `toyota` safety mode.

### On-car status — VALIDATED

LIVE longitudinal works on the car: following, speed control, and **stop-and-go
down to 0 mph with the standstill hold**, tap-gas to resume. Confirmed in the log
(route `0000001f`): openpilot transmits `0x160` at 40 Hz with a **continuous
stream (max inter-frame gap 0.051 s)** and **zero canError**. The earlier trips
were transition seams (stopping; low-speed engage); the no-handoff design removed
them. openpilot does the higher-speed following and hands the final approach/stop/
hold to the stock system via the gap-free forward path — so standstill and resume
feel exactly like stock.

(A benign `faultTemp` = `interruptRateCan2` appears at startup — a bus-1 FD-reinit
transient that does not gate CAN; cosmetic.)

--------------------------------------------------------------------------------
## 5. File-by-file change summary (vs baseline)

opendbc (`opendbc/car/toyota/`):
- `values.py`      — CAN_FD/TSS3 flags, `ToyotaCanFDSecOCPlatformConfig`,
                     `CAR.TOYOTA_COROLLA_TSS3`, `TSS3LongMode`, `TSS3_LONG_MODE`,
                     `TSS3_PT_BUS`, `TSS3_MIN_OVERRIDE_SPEED`.
- `carstate.py`    — `update_tss3()`, TSS3 `get_can_parsers` branch (pt on bus 1,
                     cam on bus 2), `0x160` template capture, gasPressed.
- `carcontroller.py` — TSS3 CAN_FD block: modify-and-forward `0x160`, camera-
                     counter stamping, standstill handback, +/-1.5 clamp.
- `toyotacan.py`   — `modify_accel_160()`.
- `interface.py`   — TSS3 params in both passes; OFF/SHADOW/LIVE safety config;
                     param-independent SHADOW/LIVE.
- `e2e.py`         — NEW: E2E CRC helper.
- `dbc/toyota_corolla_tss3_pt.dbc` — NEW: the TSS3 DBC.

panda (`opendbc/safety/modes/`):
- `toyota.h`       — NEW TSS3 safety: param, TX allowlist, accel check, bus-1 RX,
                     selective `toyota_fwd_hook`. See `panda-safety-tss3.patch`.

Device params:
- `CarPlatformBundle` = TOYOTA_COROLLA_TSS3 (forces the platform).
- `DisableUpdates = 1` (so edits persist).

No `fingerprints.py`, `car_list.json`, or `substitute.toml` change is required
for function (the platform is forced via `CarPlatformBundle`).

--------------------------------------------------------------------------------
## 6. Build, flash, test

Firmware must be built with **ALLOW_DEBUG** (default DEBUG build) — the TSS3 param
is debug-gated. See `RUNBOOK.md` for exact commands. In short:

1. Build panda fw from the patched `toyota.h` (`scons ... board/obj/panda_h7.bin.signed`).
2. Run the safety suites: `test_toyota_tss3.py` (7 tests) + `test_toyota.py`
   (1118 regression). Both must pass before flashing.
3. Copy the fw to the device's `panda/board/obj/` and restart — pandad flashes it
   and refuses to boot on a mismatch, so it sticks.
4. Bring up staged: `OFF` (Phase 1) -> `SHADOW` (compare intent offline) ->
   `LIVE` (empty road first).

--------------------------------------------------------------------------------
## 7. Tools (port/tools/)

- `test_tss3_port.py`        — end-to-end opendbc smoke test (carState decode,
                               read-only invariants, LONG_MODE matrix).
- `test_toyota_tss3.py`      — panda safety suite for the TSS3 mode.
- `test_counter_continuity.py` — validates the `0x160` counter stamping (40 Hz,
                               no breaks, matches the camera).
- `shadow_compare_160.py`    — SHADOW go/no-go: openpilot intent vs camera request.
- `find_adas_accel.py` / `scan_bitfields.py` / `crack_crc.py` / `crc_e2e.py` /
  `verify_crc.py` — how `0x160` and its E2E were reverse-engineered.
- `find_gas.py`              — how the gas pedal was found on bus 1.

--------------------------------------------------------------------------------
## 8. Known limitations

- **Standstill**: openpilot keeps emitting `0x160` but RELAYS the camera's own
  request below ~3 mph, so Toyota's standstill hold does the actual holding;
  openpilot does not itself compute a dead-stop hold command.
- **No lateral**: the camera->EPS steering command rides on the untapped camera
  bus (T21 pins 1-2) and is not in this DBC. Lateral is not attempted.
- **Radar unavailable**: openpilot uses the vision model's lead, not the Toyota
  radar (which is not decoded). Lead tracking confirmed working via vision.
- **Debug firmware**: the TSS3 safety param requires an ALLOW_DEBUG panda build.
- Several DBC signals remain unvalidated on the car (marked in the DBC comments).

See `NOTES.md` for the full chronological record, including every dead end.
