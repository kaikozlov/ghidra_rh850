import glob
from openpilot.tools.lib.logreader import LogReader
from collections import Counter
c=Counter(); lat=0; eng=0
for s in sorted(glob.glob("/data/media/0/realdata/00000023--4b94a1ecef--*/rlog.zst")):
    for m in LogReader(s):
        w=m.which(); c[w]+=1
        if w=="carControl":
            if m.carControl.latActive: lat+=1
            if m.carControl.enabled: eng+=1
print("carControl:", c.get("carControl"), "carState:", c.get("carState"))
print("cc.enabled:", eng, "cc.latActive:", lat)
