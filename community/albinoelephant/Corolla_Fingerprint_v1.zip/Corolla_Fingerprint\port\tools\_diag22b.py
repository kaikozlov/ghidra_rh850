import glob
from openpilot.tools.lib.logreader import LogReader
from collections import Counter
ev=Counter(); states=Counter(); n=0
for s in sorted(glob.glob("/data/media/0/realdata/00000022--6299eff795--*/rlog.zst")):
    for m in LogReader(s):
        w=m.which()
        if w=="onroadEvents":
            for e in m.onroadEvents: ev[str(e.name)]+=1
        elif w=="selfdriveState":
            n+=1; states[str(m.selfdriveState.state)]+=1
        elif w=="managerState":
            pass
# also check for which openpilot processes were logging
print("onroadEvents:", dict(ev.most_common(12)))
print("selfdriveState msgs:", n, "states:", dict(states))
