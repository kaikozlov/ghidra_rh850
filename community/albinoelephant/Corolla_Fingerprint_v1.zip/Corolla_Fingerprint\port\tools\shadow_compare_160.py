#!/usr/bin/env python3
"""SHADOW-mode validation: openpilot's intended accel vs the camera's request.

In TSS3_LONG_MODE = SHADOW the panda safety stays noOutput (nothing is
transmitted, the stock ACC drives the car), but openpilot runs its longitudinal
planner and logs carControl.actuators.accel. This compares that intent against
the camera's own 0x160 ACCEL_REQ on the ADAS bus -- the thing openpilot will
replace in LIVE. If openpilot wants roughly what the camera wants while the
stock ACC is active, the planner and the command path are sane and LIVE is
reasonable to try.

    python shadow_compare_160.py rlog.zst [rlog2.zst ...]

Reads (openpilot LogReader for the sunnypilot union types):
  carControl.actuators.accel   openpilot intent (m/s^2)
  carControl.longActive        openpilot longitudinally engaged
CAN (opendbc LogReader):
  0x160 ACCEL_REQ (bus 0/2)    camera request (m/s^2), bits 33-47 signed
  0x13C LON_ACTIVE (bus 1)     stock ACC actively controlling
"""
import sys, math, bisect


def accel_from_160(d):
  raw = ((d[4] & 0x7F) << 8) | d[5]
  if d[4] & 0x40:
    raw -= 0x8000
  return raw * 0.001


def main(paths):
  from openpilot.tools.lib.logreader import LogReader as OPReader
  from opendbc.car.logreader import LogReader as CANReader

  op = []          # (t, accel, longActive)
  t0 = None
  for p in paths:
    for m in OPReader(p):
      if m.which() != "carControl":
        continue
      t = m.logMonoTime / 1e9
      if t0 is None:
        t0 = t
      cc = m.carControl
      try:
        op.append((t - t0, cc.actuators.accel, bool(cc.longActive)))
      except Exception:
        pass

  cam = []         # (t, accel)
  stock_active = []  # (t, active)
  t0b = None
  for p in paths:
    for m in CANReader(p, only_union_types=True):
      if m.which() != "can":
        continue
      t = m.logMonoTime / 1e9
      if t0b is None:
        t0b = t
      for c in m.can:
        if c.src in (0, 2) and c.address == 0x160:
          cam.append((t - t0b, accel_from_160(bytes(c.dat))))
        elif c.src == 1 and c.address == 0x13C:
          d = bytes(c.dat)
          if len(d) >= 8:
            stock_active.append((t - t0b, bool(d[4] & 0x20)))

  if not op:
    print("NO carControl found. In SHADOW the planner must run:")
    print("  - TSS3_LONG_MODE = SHADOW in values.py")
    print("  - AlphaLongitudinalEnabled = 1 (toggle in the UI, needs an ignition cycle)")
    print("  - car fingerprinted as TOYOTA_COROLLA_TSS3")
    return 1
  if not cam:
    print("no 0x160 on bus 0/2 -- camera not on the relayed bus?")
    return 1

  # align camera samples onto openpilot samples, only where BOTH openpilot and
  # the stock ACC were active (that is the regime LIVE will actually run in)
  sa_t = [x[0] for x in stock_active]
  def stock_on(tq):
    if not sa_t:
      return False
    i = min(bisect.bisect_left(sa_t, tq), len(stock_active) - 1)
    return stock_active[i][1]

  ct = [c[0] for c in cam]
  pairs = []
  for t, a_op, la in op:
    if not la or not stock_on(t):
      continue
    i = bisect.bisect_left(ct, t)
    best = None
    for j in (i - 1, i):
      if 0 <= j < len(cam) and abs(cam[j][0] - t) < 0.1:
        if best is None or abs(cam[j][0] - t) < abs(cam[best][0] - t):
          best = j
    if best is not None:
      pairs.append((t, cam[best][1], a_op))

  print(f"carControl samples : {len(op)}")
  print(f"0x160 samples      : {len(cam)}")
  print(f"compared (op long + stock active): {len(pairs)}")
  if len(pairs) < 50:
    print("\nToo few overlapping samples. openpilot must be ENGAGED (its own long)")
    print("while the stock ACC is also active. Engage openpilot longitudinal in")
    print("SHADOW and drive under stock ACC at the same time.")
    return 1

  n = len(pairs)
  xs = [p[1] for p in pairs]      # camera
  ys = [p[2] for p in pairs]      # openpilot
  mx, my = sum(xs)/n, sum(ys)/n
  sxy = sum((x-mx)*(y-my) for x, y in zip(xs, ys))
  sxx = sum((x-mx)**2 for x in xs)
  syy = sum((y-my)**2 for y in ys)
  r = sxy/math.sqrt(sxx*syy) if sxx > 0 and syy > 0 else float('nan')
  rms = math.sqrt(sum((x-y)**2 for x, y in zip(xs, ys))/n)
  bias = my - mx
  worst = max(pairs, key=lambda p: abs(p[1]-p[2]))

  print(f"\ncamera    mean {mx:+.3f}  range {min(xs):+.2f}..{max(xs):+.2f} m/s^2")
  print(f"openpilot mean {my:+.3f}  range {min(ys):+.2f}..{max(ys):+.2f} m/s^2")
  print(f"\ncorrelation r : {r:+.3f}")
  print(f"RMS difference: {rms:.3f} m/s^2")
  print(f"mean bias     : {bias:+.3f} m/s^2 (openpilot minus camera)")
  print(f"worst sample  : t={worst[0]:.1f}s camera {worst[1]:+.2f} op {worst[2]:+.2f}")
  print("\nGo/no-go for LIVE:")
  print("  r > 0.8 and RMS < 0.5  -> planner tracks the camera; LIVE is reasonable")
  print("  large positive bias    -> openpilot would accelerate harder than stock")
  print("  large negative bias    -> openpilot would brake harder than stock")
  print("  r near 0               -> STOP: sign/units/planner problem, do not go LIVE")
  return 0


if __name__ == "__main__":
  sys.exit(main(sys.argv[1:]))
