#!/usr/bin/env python3
"""Test 0x160 bytes 0-1 as an AUTOSAR E2E Profile 5 CRC.

E2E P05 layout is exactly what 0x160 shows:
    [CRC 16-bit @ offset 0][Counter 8-bit @ byte 2][Data ...]

The CRC is computed over the data bytes AFTER the CRC field, with a 16-bit
Data ID appended (not transmitted). Appending bytes shifts the CRC register,
which is why the plain linear test missed it -- that test XORs two messages of
the same length and an appended constant only cancels if the length matches.

Fix: test L((m1 XOR m2) || 0x00*k) == crc1 XOR crc2 for k = 0,1,2,4.
That covers any appended constant of that length, Data ID included.
"""
import sys
from opendbc.car.logreader import LogReader

ADDR = 0x160
REV8 = [int(f"{i:08b}"[::-1], 2) for i in range(256)]


def rev16(x):
    return int(f"{x:016b}"[::-1], 2)


def crc_raw(data, poly, refin, refout):
    reg = 0
    for b in data:
        if refin:
            b = REV8[b]
        reg ^= b << 8
        for _ in range(8):
            reg = ((reg << 1) ^ poly) & 0xFFFF if reg & 0x8000 else (reg << 1) & 0xFFFF
    return rev16(reg) if refout else reg


def crc_full(data, poly, init, refin, refout, xorout):
    reg = init
    for b in data:
        if refin:
            b = REV8[b]
        reg ^= b << 8
        for _ in range(8):
            reg = ((reg << 1) ^ poly) & 0xFFFF if reg & 0x8000 else (reg << 1) & 0xFFFF
    if refout:
        reg = rev16(reg)
    return reg ^ xorout


def main(paths):
    data = []
    for p in paths:
        for m in LogReader(p, only_union_types=True):
            if m.which() != "can":
                continue
            for c in m.can:
                if c.src == 0 and c.address == ADDR:
                    data.append(bytes(c.dat))
    print(f"{len(data)} frames")

    ranges = {"2..31": lambda d: d[2:], "2..23": lambda d: d[2:24]}
    found = []
    for ename, get in (("BE", lambda d: (d[0] << 8) | d[1]),
                       ("LE", lambda d: (d[1] << 8) | d[0])):
        for rname, rfn in ranges.items():
            base = data[0]
            for pad in (0, 1, 2, 4):
                pairs = []
                for d in data[1:40]:
                    x = bytes(a ^ b for a, b in zip(rfn(base), rfn(d))) + b"\x00" * pad
                    pairs.append((x, get(base) ^ get(d)))
                for refin in (False, True):
                    for refout in (False, True):
                        for poly in range(0x10000):
                            m0, t0 = pairs[0]
                            if crc_raw(m0, poly, refin, refout) != t0:
                                continue
                            if all(crc_raw(m, poly, refin, refout) == t
                                   for m, t in pairs[:15]):
                                print(f"*** LINEAR MATCH: {ename} bytes {rname} "
                                      f"pad={pad} poly={poly:#06x} "
                                      f"refin={refin} refout={refout}")
                                found.append((ename, rname, rfn, pad, poly, refin, refout, get))
    if not found:
        print("\nno linear CRC even with 1/2/4 appended constant bytes.")
        return 1

    # recover the appended constant (the Data ID) and init/xorout by brute force
    for ename, rname, rfn, pad, poly, refin, refout, get in found[:2]:
        print(f"\nrecovering Data ID for {ename} {rname} pad={pad} poly={poly:#06x}")
        sample = data[:200]
        hit = None
        for init in (0x0000, 0xFFFF):
            for xorout in (0x0000, 0xFFFF):
                for did in range(1 << (8 * pad)) if pad and pad <= 2 else [0]:
                    suffix = did.to_bytes(pad, "little") if pad else b""
                    if all(crc_full(rfn(d) + suffix, poly, init, refin, refout, xorout)
                           == get(d) for d in sample[:8]):
                        if all(crc_full(rfn(d) + suffix, poly, init, refin, refout, xorout)
                               == get(d) for d in sample):
                            hit = (init, xorout, did, suffix)
                            break
                if hit:
                    break
            if hit:
                break
        if hit:
            init, xorout, did, suffix = hit
            ok = all(crc_full(rfn(d) + suffix, poly, init, refin, refout, xorout) == get(d)
                     for d in data)
            print(f"  *** SOLVED: poly={poly:#06x} init={init:#06x} xorout={xorout:#06x} "
                  f"refin={refin} refout={refout} DataID={did:#06x} ({suffix.hex()})")
            print(f"  VERIFIED on all {len(data)} frames: {ok}")
            return 0
        print("  could not recover init/xorout/DataID from the tried set")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
