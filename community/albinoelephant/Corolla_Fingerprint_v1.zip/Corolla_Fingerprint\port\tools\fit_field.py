#!/usr/bin/env python3
"""Least-squares fit a candidate ADAS bit-field to 0x13C.ACCEL_CMD.

scan_bitfields.py reports the same |r| for every width at a given start bit,
because truncating low bits barely moves a correlation. This separates them:
it fits ACCEL_CMD = scale*raw + offset and reports residual RMS. The true width
is the narrowest one whose residual is at the quantisation floor, and its scale
should be a round number.

    python fit_field.py rlog.zst [rlog2.zst ...]
"""
import sys, math, bisect

from opendbc.car.logreader import LogReader

PT_BUS, ADAS_BUS, ACC_CONTROL, ADAS_ADDR = 1, 0, 0x13C, 0x160
# (start bit, endianness) candidates that scored |r| ~ 0.99
CANDIDATES = [(35, "be"), (97, "be"), (98, "be")]
WIDTHS = (8, 10, 11, 12, 13, 14, 16)


def bits_be(d, start, width):
    v = 0
    for i in range(width):
        b = start + i
        if (b >> 3) >= len(d):
            return None
        v = (v << 1) | ((d[b >> 3] >> (7 - (b & 7))) & 1)
    return v


def main(paths):
    stock, frames = [], []
    t0 = None
    for path in paths:
        for msg in LogReader(path, only_union_types=True):
            if msg.which() != "can":
                continue
            t = msg.logMonoTime / 1e9
            if t0 is None:
                t0 = t
            for c in msg.can:
                if c.src == PT_BUS and c.address == ACC_CONTROL:
                    d = bytes(c.dat)
                    if len(d) >= 8 and (d[4] & 0x20):
                        r = (d[0] << 8) | d[1]
                        stock.append((t - t0, (r - 0x10000 if r >= 0x8000 else r) * 0.001))
                elif c.src == ADAS_BUS and c.address == ADAS_ADDR:
                    frames.append((t - t0, bytes(c.dat)))

    at = [s[0] for s in stock]
    aligned = []
    for t, d in frames:
        i = bisect.bisect_left(at, t)
        best = None
        for j in (i - 1, i):
            if 0 <= j < len(stock) and abs(at[j] - t) < 0.06:
                if best is None or abs(at[j] - t) < abs(at[best] - t):
                    best = j
        if best is not None:
            aligned.append((d, stock[best][1]))
    ys = [a[1] for a in aligned]
    n = len(ys)
    my = sum(ys) / n
    print(f"{len(aligned)} aligned pairs, ACCEL_CMD {min(ys):+.2f} .. {max(ys):+.2f}\n")
    print(f"{'start':>5} {'w':>3} {'scale':>12} {'offset':>9} {'resid RMS':>10} "
          f"{'r':>7}  implied range")
    rows = []
    for start, _end in CANDIDATES:
        for w in WIDTHS:
            xs = [bits_be(a[0], start, w) for a in aligned]
            if any(x is None for x in xs):
                continue
            half, full = 1 << (w - 1), 1 << w
            xs = [x - full if x >= half else x for x in xs]
            if len(set(xs)) < 8:
                continue
            mx = sum(xs) / n
            sxx = sum((x - mx) ** 2 for x in xs)
            sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
            if sxx <= 0:
                continue
            scale = sxy / sxx
            off = my - scale * mx
            resid = math.sqrt(sum((y - (scale * x + off)) ** 2
                                  for x, y in zip(xs, ys)) / n)
            syy = sum((y - my) ** 2 for y in ys)
            r = sxy / math.sqrt(sxx * syy)
            rows.append((resid, start, w, scale, off, r, min(xs), max(xs)))
    for resid, start, w, scale, off, r, lo, hi in sorted(rows):
        print(f"{start:5d} {w:3d} {scale:12.8f} {off:+9.4f} {resid:10.4f} "
              f"{r:+7.3f}  {scale*lo:+.2f} .. {scale*hi:+.2f}")
    print("\nLowest residual with a round scale is the real field.")
    print("Residual is in m/s^2; the 0x13C quantum itself is 0.001.")


if __name__ == "__main__":
    main(sys.argv[1:])
