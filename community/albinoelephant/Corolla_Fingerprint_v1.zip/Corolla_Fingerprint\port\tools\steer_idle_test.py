#!/usr/bin/env python3
"""Command vs feedback via idle test: a steering COMMAND is flat when LTA is off;
feedback keeps reporting the wheel. Report each candidate field's stddev when
ENGAGED vs NOT-engaged, plus message length + a SecOC-shape hint.
"""
import sys, bisect, statistics
from collections import defaultdict

CANDS=[(0,0x1a0,11),(2,0x160,22),(1,0x371,16),(1,0x90,12),(1,0x81,16),(1,0x25,1)]

def s16be(d,i):
    if i+1>=len(d): return None
    v=(d[i]<<8)|d[i+1]; return v-0x10000 if v>=0x8000 else v

def main(paths):
    from opendbc.car.logreader import LogReader as CAN
    eng=[]; frames=defaultdict(list); lens={}; t0=None
    want={a for _,a,_ in CANDS}|{0x8A}
    for p in paths:
        for m in CAN(p, only_union_types=True):
            if m.which()!="can": continue
            t=m.logMonoTime/1e9
            if t0 is None: t0=t
            for c in m.can:
                if c.address in want and c.src in (0,1,2):
                    d=bytes(c.dat)
                    if c.address==0x8A and c.src==1 and len(d)>=23:
                        eng.append((t-t0,1 if d[22]&0x10 else 0))
                    frames[(c.src,c.address)].append((t-t0,d)); lens[(c.src,c.address)]=len(d)
    et=[e[0] for e in eng]
    def eng_at(tq):
        if not et: return 0
        i=min(bisect.bisect_left(et,tq),len(eng)-1); return eng[i][1]
    print(f"{'bus':>3} {'addr':>7} {'byte':>4} {'len':>3} {'std_ENG':>9} {'std_OFF':>9}  verdict")
    for bus,addr,off in CANDS:
        fr=frames.get((bus,addr))
        if not fr: continue
        ve=[];vo=[]
        for t,d in fr:
            v=s16be(d,off)
            if v is None: continue
            (ve if eng_at(t)==1 else vo).append(v)
        se=statistics.pstdev(ve) if len(ve)>10 else float('nan')
        so=statistics.pstdev(vo) if len(vo)>10 else float('nan')
        import math
        verdict="COMMAND (idle when off)" if (not math.isnan(se) and se>50 and (math.isnan(so) or so<se*0.15)) else ("feedback (active both)" if (not math.isnan(so) and so>se*0.3) else "?")
        print(f"{bus:3d} {addr:#07x} {off:4d} {lens[(bus,addr)]:3d} {se:9.0f} {so:9.0f}  {verdict}  (nENG={len(ve)},nOFF={len(vo)})")
    return 0

if __name__=="__main__":
    sys.exit(main(sys.argv[1:]))
