#!/usr/bin/env python3
"""Decide whether bytes 0-1 of 0x160 are ANY linear CRC-16, or a keyed MAC.

A CRC is affine: CRC(m) = L(m) XOR K, where L is linear in the message and K
depends only on init/xorout/length. Therefore for two equal-length messages

    CRC(m1) XOR CRC(m2) == L(m1 XOR m2)

and L is just the CRC with init=0, xorout=0. That removes init and xorout from
the search, so 65536 polynomials x 4 reflection modes is exhaustive and fast.

If no polynomial satisfies this across many pairs, the field is NOT a linear
CRC of the message -- which for a Toyota TSS3 ACC request means a SecOC MAC.
"""
import sys
from opendbc.car.logreader import LogReader

ADDR = 0x160
TBL = {}


def rev8(x):
    return int(f"{x:08b}"[::-1], 2)


def rev16(x):
    return int(f"{x:016b}"[::-1], 2)


REV8 = [rev8(i) for i in range(256)]


def crc_raw(data, poly, refin, refout):
    reg = 0
    for b in data:
        if refin:
            b = REV8[b]
        reg ^= b << 8
        for _ in range(8):
            reg = ((reg << 1) ^ poly) & 0xFFFF if reg & 0x8000 else (reg << 1) & 0xFFFF
    return rev16(reg) if refout else reg


def main(paths):
    data = []
    for p in paths:
        for m in LogReader(p, only_union_types=True):
            if m.which() != "can":
                continue
            for c in m.can:
                if c.src == 0 and c.address == ADDR:
                    data.append(bytes(c.dat))
    print(f"{len(data)} frames")

    ranges = {
        "2..31": lambda d: d[2:],
        "2..23": lambda d: d[2:24],
        "3..31": lambda d: d[3:],
        "0..31 (self-incl)": lambda d: d[2:],
    }
    for endian in ("BE", "LE"):
        get = (lambda d: (d[0] << 8) | d[1]) if endian == "BE" else (lambda d: (d[1] << 8) | d[0])
        for rname, rfn in list(ranges.items())[:3]:
            base = data[0]
            pairs = []
            for d in data[1:40]:
                m = bytes(a ^ b for a, b in zip(rfn(base), rfn(d)))
                pairs.append((m, get(base) ^ get(d)))
            for refin in (False, True):
                for refout in (False, True):
                    for poly in range(0x10000):
                        m0, t0 = pairs[0]
                        if crc_raw(m0, poly, refin, refout) != t0:
                            continue
                        if all(crc_raw(m, poly, refin, refout) == t for m, t in pairs[:12]):
                            print(f"*** LINEAR CRC FOUND: {endian} bytes {rname} "
                                  f"poly={poly:#06x} refin={refin} refout={refout}")
                            return 0
            print(f"  {endian} bytes {rname}: no linear CRC over 65536 polys x 4 modes")
    print("\nCONCLUSION: bytes 0-1 are not a linear CRC of the message payload.")
    print("For a TSS3 ACC request that means a keyed SecOC MAC.")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
