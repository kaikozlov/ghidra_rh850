#!/usr/bin/env python3
"""Confirm the 0x160 E2E CRC across every segment and a SECOND session.

If the Data ID and CRC parameters hold on a drive recorded on a different day,
they are properties of the message, not a coincidence fitted to one segment.
"""
import sys
import glob
from opendbc.car.logreader import LogReader

ADDR = 0x160
POLY, INIT, XOROUT, DATAID = 0x1021, 0x0000, 0x0000, 0x444A
SUFFIX = DATAID.to_bytes(2, "little")   # 4a 44


def crc16(data):
    reg = INIT
    for b in data:
        reg ^= b << 8
        for _ in range(8):
            reg = ((reg << 1) ^ POLY) & 0xFFFF if reg & 0x8000 else (reg << 1) & 0xFFFF
    return reg ^ XOROUT


def check(path):
    ok = bad = 0
    ctr_ok = ctr_bad = 0
    prev = None
    for m in LogReader(path, only_union_types=True):
        if m.which() != "can":
            continue
        for c in m.can:
            if c.src != 0 or c.address != ADDR:
                continue
            d = bytes(c.dat)
            want = (d[1] << 8) | d[0]           # CRC field, little-endian
            got = crc16(d[2:] + SUFFIX)
            ok, bad = (ok + 1, bad) if got == want else (ok, bad + 1)
            if prev is not None:
                exp = (prev + 1) & 0xFF
                ctr_ok, ctr_bad = (ctr_ok + 1, ctr_bad) if d[2] == exp else (ctr_ok, ctr_bad + 1)
            prev = d[2]
    return ok, bad, ctr_ok, ctr_bad


def main():
    routes = {
        "route16 (all segs)": sorted(glob.glob("/data/media/0/realdata/00000016--2d1a51e74f--*/rlog.zst")),
        "route15 (prior session)": sorted(glob.glob("/data/media/0/realdata/00000015--*/rlog.zst")),
        "route14 (prior session)": sorted(glob.glob("/data/media/0/realdata/00000014--*/rlog.zst")),
    }
    for name, paths in routes.items():
        if not paths:
            print(f"{name}: no rlogs found")
            continue
        tok = tbad = tcok = tcbad = 0
        for p in paths:
            o, b, co, cb = check(p)
            tok += o; tbad += b; tcok += co; tcbad += cb
        total = tok + tbad
        if total == 0:
            print(f"{name}: no 0x160 frames (camera bus not on bus 0 here?)")
            continue
        print(f"{name}: CRC {tok}/{total} ok ({100*tok/total:.2f}%), "
              f"{tbad} bad | counter {tcok}/{tcok+tcbad} sequential")
    return 0


if __name__ == "__main__":
    sys.exit(main())
