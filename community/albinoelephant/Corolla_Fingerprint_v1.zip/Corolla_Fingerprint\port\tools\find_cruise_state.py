#!/usr/bin/env python3
"""Find the cruise-button / ACC-state message by correlating against events we
already decoded.

This is the last software blocker for TSS3_LONG_MODE = LIVE. See NOTES.md:
cruiseState.enabled currently comes from 0x13C LON_ACTIVE, which is the STOCK
system's own command -- the moment openpilot transmits 0x13C that signal becomes
its own output and can no longer report driver intent. A separate message has to
be found.

No fingerprint, no car port, no device needed. Raw CAN from an rlog is enough,
and logs recorded while the car was MOCK work exactly as well.

    python find_cruise_state.py rlog1.zst [rlog2.zst ...] [--window 0.5]

Method: the port doc already established that 0x13C byte 4 goes 0x10 -> 0x30
when the factory longitudinal controller starts commanding, and that 0x8A byte
24 goes 0 -> 100 at the ACC main button. Those give us timestamped ground-truth
events. Any message reporting ACC state or button presses must change at those
same moments -- so we score every other byte on bus 0 by how much its changes
cluster around the events versus how much it changes the rest of the time.

A byte that changes ONLY near events is the signal. A byte that changes
constantly (wheel speeds, counters, MACs) scores near zero.
"""
import argparse
import sys
from collections import defaultdict

try:
    from opendbc.car.logreader import LogReader
except ImportError as e1:  # pragma: no cover
    try:
        from openpilot.tools.lib.logreader import LogReader
    except ImportError as e2:
        # report the real cause -- it is usually a missing dep (zstandard,
        # pycapnp), not a missing checkout
        sys.exit("cannot import a LogReader.\n"
                 f"  opendbc.car.logreader         -> {e1}\n"
                 f"  openpilot.tools.lib.logreader -> {e2}\n"
                 "Need the sunnypilot root and opendbc_repo on PYTHONPATH, "
                 "plus 'pip install zstandard pycapnp'.")

ACC_CONTROL = 0x13C      # byte 4, mask 0x20 = LON_ACTIVE
ACC_STATUS = 0x8A        # byte 24 = ACC_MAIN_ON (0 / 100)

# already decoded, or structurally noisy -- never candidates
IGNORE = {
    0x13C,   # the command itself
    0xAA,    # wheel speeds
    0x30, 0x8A,   # steering angle / acc status
    0x90,    # yaw
    0xDA,    # steering torque
    0x0F,    # SecOC sync (counter + MAC, changes constantly)
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("rlogs", nargs="+", help="rlog.zst / rlog.bz2 paths (NOT qlogs)")
    ap.add_argument("--window", type=float, default=0.5,
                    help="seconds around an event that counts as 'near' (default 0.5)")
    ap.add_argument("--bus", type=int, default=0)
    ap.add_argument("--top", type=int, default=25)
    args = ap.parse_args()

    events: list[float] = []
    # (addr, byte_index) -> list of timestamps where the value changed
    changes: dict[tuple[int, int], list[float]] = defaultdict(list)
    last_val: dict[tuple[int, int], int] = {}
    last_lon_active: int | None = None
    last_main: int | None = None
    first_t = last_t = None
    frames = 0

    for path in args.rlogs:
        for msg in LogReader(path, only_union_types=True):
            if msg.which() != "can":
                continue
            t = msg.logMonoTime / 1e9
            if first_t is None:
                first_t = t
            last_t = t
            for c in msg.can:
                if c.src != args.bus:
                    continue
                frames += 1
                dat = bytes(c.dat)

                # --- ground-truth events ---------------------------------
                if c.address == ACC_CONTROL and len(dat) > 4:
                    lon_active = 1 if (dat[4] & 0x20) else 0
                    if last_lon_active is not None and lon_active != last_lon_active:
                        events.append(t)
                    last_lon_active = lon_active
                elif c.address == ACC_STATUS and len(dat) > 24:
                    main_on = 1 if dat[24] > 50 else 0
                    if last_main is not None and main_on != last_main:
                        events.append(t)
                    last_main = main_on

                # --- every byte's change history -------------------------
                if c.address in IGNORE:
                    continue
                for i, b in enumerate(dat):
                    key = (c.address, i)
                    prev = last_val.get(key)
                    if prev is not None and b != prev:
                        changes[key].append(t)
                    last_val[key] = b

    if first_t is None:
        sys.exit("no CAN frames found -- is this an rlog and not a qlog?")
    duration = last_t - first_t
    print(f"# {frames} frames on bus {args.bus}, {duration:.1f}s, {len(args.rlogs)} log(s)")

    if not events:
        print("\nNO EVENTS FOUND. Neither 0x13C LON_ACTIVE nor 0x8A ACC_MAIN_ON changed"
              "\nstate in these logs, so there is nothing to correlate against."
              "\nUse a segment where you switched ACC on and off, or engaged and"
              "\ncancelled it. Without a transition this method cannot work.")
        return 1

    # collapse events closer together than the window
    events.sort()
    merged = [events[0]]
    for e in events[1:]:
        if e - merged[-1] > args.window:
            merged.append(e)
    print(f"# {len(merged)} distinct ACC state transitions to correlate against")
    print(f"# at t+{', t+'.join(f'{e - first_t:.1f}s' for e in merged[:12])}"
          + (" ..." if len(merged) > 12 else ""))

    # fraction of "near event" time in the log -- the baseline a random byte hits
    near_span = min(len(merged) * 2 * args.window, duration)
    baseline = near_span / duration if duration > 0 else 0

    scored = []
    for key, ts in changes.items():
        if len(ts) < len(merged):        # must change at least once per event
            continue
        near = sum(1 for t in ts if any(abs(t - e) <= args.window for e in merged))
        frac = near / len(ts)
        # how many distinct events did this byte actually respond to?
        covered = sum(1 for e in merged if any(abs(t - e) <= args.window for t in ts))
        if covered < max(2, len(merged) // 2):
            continue
        scored.append((frac / baseline if baseline else 0, frac, covered, len(ts), key))

    scored.sort(reverse=True)
    print(f"\n# baseline (a byte changing at random would score ~1.0x): "
          f"{baseline * 100:.1f}% of time is 'near an event'")
    print(f"\n{'addr':>7} {'byte':>4} {'lift':>7} {'near':>6} {'events':>7} {'changes':>8}")
    print("-" * 46)
    for lift, frac, covered, total, (addr, i) in scored[:args.top]:
        print(f"{addr:>#7x} {i:>4} {lift:>6.1f}x {frac*100:>5.0f}% "
              f"{covered:>3}/{len(merged):<3} {total:>8}")

    if not scored:
        print("  (nothing scored -- try a larger --window, or a log with more"
              "\n   ACC on/off cycles)")
        return 1

    print("\nHow to read this:")
    print("  lift   = how much more this byte changes near an ACC transition than")
    print("           chance would predict. Anything above ~5x is worth opening in")
    print("           cabana; a button/state byte often scores 20x or more.")
    print("  events = how many of the transitions it responded to. You want ALL of")
    print("           them -- a byte that catches only half is probably something")
    print("           else that correlates loosely (speed, gear, brake).")
    print("\nThen confirm in cabana: the message should latch while ACC is engaged")
    print("(a state field) or pulse for ~100ms (a button field). Once found, add it")
    print("to the DBC and read it into cruiseState instead of 0x13C LON_ACTIVE.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
