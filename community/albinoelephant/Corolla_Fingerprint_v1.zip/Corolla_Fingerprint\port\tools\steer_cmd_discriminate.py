#!/usr/bin/env python3
"""Separate steering COMMAND from FEEDBACK: a command tracks angle only when LTA
is engaged; feedback tracks in both engaged and manual steering.

Uses ACC_ENGAGED (0x8A byte22 mask 0x10) as the LTA-engaged proxy. For each
candidate (bus,addr,byte) reports correlation with steer angle when ENGAGED vs
when MANUAL (not engaged but angle moving). COMMAND = high engaged, low manual.
"""
import sys, math, bisect
from collections import defaultdict

CANDS = [(0,0x1a0),(2,0x160),(1,0x371),(0,0x160),(1,0x90),(1,0x81),(1,0x1b1),(1,0x489)]

def s16be(d,i):
    if i+1>=len(d): return None
    v=(d[i]<<8)|d[i+1]; return v-0x10000 if v>=0x8000 else v

def corr(xs,ys):
    n=len(xs)
    if n<50: return float('nan')
    mx=sum(xs)/n; my=sum(ys)/n
    sxx=sum((x-mx)**2 for x in xs); syy=sum((y-my)**2 for y in ys)
    if sxx<=0 or syy<=0: return float('nan')
    return sum((x-mx)*(y-my) for x,y in zip(xs,ys))/math.sqrt(sxx*syy)

def main(paths):
    from openpilot.tools.lib.logreader import LogReader as OP
    from opendbc.car.logreader import LogReader as CAN
    ang=[]; t0=None
    for p in paths:
        for m in OP(p):
            if m.which()=="carState":
                t=m.logMonoTime/1e9
                if t0 is None: t0=t
                ang.append((t-t0, m.carState.steeringAngleDeg))
    at=[a[0] for a in ang]
    def ang_at(tq):
        i=bisect.bisect_left(at,tq)
        for j in (i-1,i):
            if 0<=j<len(ang) and abs(ang[j][0]-tq)<0.05: return ang[j][1]
        return None
    # engaged timeline from 0x8A b22
    eng=[]; frames=defaultdict(list); t0b=None
    want={a for _,a in CANDS}|{0x8A}
    for p in paths:
        for m in CAN(p, only_union_types=True):
            if m.which()!="can": continue
            t=m.logMonoTime/1e9
            if t0b is None: t0b=t
            for c in m.can:
                if c.address in want and c.src in (0,1,2):
                    if c.address==0x8A and c.src==1:
                        d=bytes(c.dat)
                        if len(d)>=23: eng.append((t-t0b, 1 if d[22]&0x10 else 0))
                    frames[(c.src,c.address)].append((t-t0b, bytes(c.dat)))
    et=[e[0] for e in eng]
    def eng_at(tq):
        if not et: return 0
        i=min(bisect.bisect_left(et,tq),len(eng)-1); return eng[i][1]
    print(f"{'bus':>3} {'addr':>7} {'byte':>4} {'r_engaged':>10} {'r_manual':>9}  verdict")
    for bus,addr in CANDS:
        fr=frames.get((bus,addr))
        if not fr: continue
        dlc=min(len(d) for _,d in fr)
        best=None
        for off in range(dlc-1):
            xe=[];ye=[];xm=[];ym=[]
            for t,d in fr:
                a=ang_at(t)
                if a is None: continue
                v=s16be(d,off)
                if v is None: continue
                if eng_at(t)==1: xe.append(v); ye.append(a)
                elif abs(a)>3:   xm.append(v); ym.append(a)   # manual & actually turning
            re=corr(xe,ye); rm=corr(xm,ym)
            if not math.isnan(re) and (best is None or abs(re)>abs(best[1])): best=(off,re,rm)
        if best:
            off,re,rm=best
            verdict="COMMAND?" if abs(re)>0.8 and (math.isnan(rm) or abs(rm)<0.5) else ("feedback" if abs(rm)>0.7 else "?")
            print(f"{bus:3d} {addr:#07x} {off:4d} {re:+10.2f} {rm:+9.2f}  {verdict}")
    return 0

if __name__=="__main__":
    sys.exit(main(sys.argv[1:]))
