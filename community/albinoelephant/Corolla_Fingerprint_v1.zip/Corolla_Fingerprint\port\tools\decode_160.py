#!/usr/bin/env python3
"""Structural decode of 0x160, the camera's ACC request on the TSS 3.0 ADAS bus.

Order of business:
  1. Is it SecOC-signed? If a group of bytes changes every frame even when the
     rest of the payload is byte-identical, that is a MAC + freshness counter and
     the message cannot be forged without the key. Everything else is moot.
  2. Counter / checksum detection.
  3. Which bits track ACC engagement.

    python decode_160.py rlog.zst [rlog2.zst ...]
"""
import sys
import math
from collections import Counter, defaultdict

from opendbc.car.logreader import LogReader

ADAS_BUS, ADDR, PT_BUS, ACC_CONTROL = 0, 0x160, 1, 0x13C


def entropy(vals):
    n = len(vals)
    c = Counter(vals)
    return -sum((k / n) * math.log2(k / n) for k in c.values())


def main(paths):
    frames = []          # (t, bytes)
    acc = []             # (t, lon_active)
    t0 = None
    for path in paths:
        for msg in LogReader(path, only_union_types=True):
            if msg.which() != "can":
                continue
            t = msg.logMonoTime / 1e9
            if t0 is None:
                t0 = t
            for c in msg.can:
                if c.src == ADAS_BUS and c.address == ADDR:
                    frames.append((t - t0, bytes(c.dat)))
                elif c.src == PT_BUS and c.address == ACC_CONTROL:
                    d = bytes(c.dat)
                    if len(d) >= 8:
                        acc.append((t - t0, bool(d[4] & 0x20)))

    dlc = min(len(f[1]) for f in frames)
    print(f"{ADDR:#05x}: {len(frames)} frames, dlc {dlc}\n")

    data = [f[1] for f in frames]

    # ---- 1. SecOC probe -----------------------------------------------------
    # Group frames by the payload EXCLUDING each candidate trailing region.
    # If a region varies while everything else is identical, it is a MAC.
    print("=== SecOC probe: bytes that differ while the REST is byte-identical ===")
    suspicious = defaultdict(set)
    groups = defaultdict(list)
    for d in data:
        groups[d[:16]].append(d)          # key on the first half
    multi = {k: v for k, v in groups.items() if len(v) > 3}
    print(f"{len(multi)} distinct first-16-byte prefixes seen more than 3 times")
    for _k, v in list(multi.items())[:5000]:
        for i in range(16, dlc):
            if len({x[i] for x in v}) > 1:
                suspicious[i].add(len({x[i] for x in v}))
    if suspicious:
        print("bytes 16.. that vary under an identical 0..15 prefix:")
        for i in sorted(suspicious):
            print(f"  byte {i:2d}: up to {max(suspicious[i])} distinct values")
    else:
        print("  none -- bytes 16..31 are a deterministic function of bytes 0..15")

    # ---- 2. per-byte character ---------------------------------------------
    print("\n=== per-byte character ===")
    print(f"{'byte':>4} {'distinct':>8} {'entropy':>8} {'chg/frame':>10}  note")
    counters, macs = [], []
    for i in range(dlc):
        col = [d[i] for d in data]
        dis = len(set(col))
        ent = entropy(col)
        chg = sum(1 for a, b in zip(col, col[1:]) if a != b) / (len(col) - 1)
        note = ""
        # counter: increments by a constant step almost every frame
        steps = Counter((b - a) % 256 for a, b in zip(col, col[1:]))
        top, cnt = steps.most_common(1)[0]
        if top != 0 and cnt / (len(col) - 1) > 0.9:
            note = f"COUNTER (+{top} mod 256, {cnt/(len(col)-1):.0%})"
            counters.append(i)
        elif dis > 200 and ent > 7.0 and chg > 0.9:
            note = "high-entropy, changes constantly -> MAC/checksum?"
            macs.append(i)
        elif dis == 1:
            note = f"CONSTANT {col[0]:#04x}"
        elif dis <= 4:
            note = "few values: " + " ".join(f"{v:#04x}" for v in sorted(set(col))[:4])
        print(f"{i:4d} {dis:8d} {ent:8.2f} {chg:10.2f}  {note}")

    print(f"\ncounter bytes: {counters}")
    print(f"MAC-like bytes: {macs}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
