# TSS 3.0 longitudinal in Toyota panda safety

For a personal, non-distributed build.

**STATUS: compiled and tested.** Superseded my earlier "proposed, not compiled"
note — the change is now in `port/panda-safety-tss3.patch` (45 added lines,
3 removed) with tests in `port/tools/test_toyota_tss3.py`.

Ran 2026-09-08 in WSL Ubuntu 24.04, gcc 13.3.0:

```
compile   clean with the stock libsafety flags, including -Wall -Wextra -Werror
          (-DALLOW_DEBUG, the non-release build, same as libsafety_py uses)
existing  opendbc/safety/tests/test_toyota.py
          1009 passed, 443 skipped, 810 subtests  -> no regression
new       opendbc/safety/tests/test_toyota_tss3.py
          6 passed
```

What the 6 new tests actually assert:

| test | asserts |
|---|---|
| `accel_within_limits_allowed` | −1.5 … +1.5 m/s² passes |
| `accel_outside_limits_blocked` | −4.0 … −1.55 and +1.55 … +4.0 rejected |
| `stock_toyota_envelope_is_rejected` | −3.5, −2.0, +1.8, +2.0 rejected — the tighter TSS3 envelope actually binds instead of inheriting Toyota's |
| `no_lateral_or_legacy_addrs` | `0x2E4`, `0x191`, `0x412`, `0x343`, `0x183`, `0x1D2`, `0x131` never transmit, engaged or not |
| `accel_blocked_when_not_engaged` | nothing goes out with `controls_allowed = false` |
| `wrong_bus_blocked` | `0x13C` rejected on buses 1 and 2 |

Not run: `tests/misra/` (needs cppcheck) and the `gcovr --fail-under-line=100`
coverage gate from `tests/test.sh`. The coverage gate matters if you ever
upstream this; for a local build it does not.

## How to re-run it yourself

```bash
# isolated, no sudo, nothing system-wide -- delete ~/tss3 to undo
python3 -m venv --without-pip ~/tss3/venv
curl -sS https://bootstrap.pypa.io/get-pip.py | ~/tss3/venv/bin/python
~/tss3/venv/bin/pip install numpy cffi pycapnp pytest

cp -r <sunnypilot>/opendbc_repo ~/tss3/
cd ~/tss3/opendbc_repo && git apply <path>/port/panda-safety-tss3.patch
cp <path>/port/tools/test_toyota_tss3.py opendbc/safety/tests/
PYTHONPATH=$PWD ~/tss3/venv/bin/python -m pytest opendbc/safety/tests/test_toyota.py opendbc/safety/tests/test_toyota_tss3.py -q
```

There is no scons and no Makefile — `libsafety_py.py` compiles `safety.c` with
plain `cc` on first import, so pytest is the build.

## Correction first

I earlier said the panda safety source isn't in your branch. That was wrong —
it **moved into opendbc**. It is at:

```
opendbc_repo/opendbc/safety/modes/toyota.h
opendbc_repo/opendbc/safety/tests/test_toyota.py     <- the safety test suite
```

`panda/python/__init__.py` gives it away: `CAN_PACKET_VERSION =
compute_version_hash(opendbc.INCLUDE_PATH + "opendbc/safety/can.h")`. So you do
not need a separate panda repo to *edit* safety — only to build and flash the
firmware.

## Two gates you'd hit before anything works

**1. The SecOC param is behind `ALLOW_DEBUG`.**

```c
#ifdef ALLOW_DEBUG
  const uint32_t TOYOTA_PARAM_SECOC = 8UL << TOYOTA_PARAM_OFFSET;
  toyota_secoc = GET_FLAG(param, TOYOTA_PARAM_SECOC);
#endif
```

Release panda firmware is built without `ALLOW_DEBUG`, so `toyota_secoc` stays
false no matter what openpilot sends. Your platform *does* set that param today
(`interface.py` ORs in `ToyotaSafetyFlags.SECOC` for any SecOC car), and on a
release panda build it is silently ignored.

Good news: **TSS3 longitudinal does not need it.** `0x13C` is plaintext, not
SecOC-signed, so the design below never touches `toyota_secoc` and its flag sits
outside the `ALLOW_DEBUG` block.

**2. The stock Toyota RX checks do not match your car.** This is the one that
would bite you: RX checks failing means `controls_allowed` drops and nothing is
sent, with no obvious explanation.

`TOYOTA_SECOC_RX_CHECKS` expects, on bus 0:

| addr | len | freq | present on TSS3? |
|---|---|---|---|
| `0xAA` wheel speeds | 8 | 83 Hz | yes, 8B — but the **rate is unmeasured**, verify it |
| `0x260` steer torque | 8 | 50 Hz | **no** — TSS3 steering torque is `0xDA` @ 42 Hz |
| `0x176` | 8 | 32 Hz | **unknown**, not in the decoded set |
| `0x116` | 8 | 42 Hz | yes (SecOC, 42 Hz) but decoded as longitudinal/motor |
| `0x101` brake | 8 | 50 Hz | yes, 8B — rate unmeasured |
| `0x1D3` PCM_CRUISE_2 | 8 | 33 Hz | **no** |

So TSS3 needs its own RX check set, not the SecOC one.

## The change

All in `opendbc/safety/modes/toyota.h`.

### 1. TX list — longitudinal only, by design

Add near the other TX macros. Note what is deliberately **absent**: no `0x2E4`,
no `0x191`, no `0x412`. The camera→EPS steering command rides on CA2, which the
harness never routes to the device, so there is no lateral command to permit and
this mode must never permit one.

```c
/* TSS 3.0 (Corolla, CAN FD). 0x13C ACC_CONTROL is 8B, 20 Hz, plaintext, bus 0. */
#define TOYOTA_TSS3_LONG_TX_MSGS \
  {0x13C, 0, 8, .check_relay = true},  /* ACC_CONTROL (TSS3) */ \

/* Steering torque is 0xDA here, not 0x260, and there is no 0x1D2 PCM_CRUISE.
   Frequencies are UNMEASURED -- confirm from an rlog before flashing, a wrong
   value drops controls_allowed. */
#define TOYOTA_TSS3_RX_CHECKS                                                                                                              \
  {.msg = {{ 0xaa, 0, 8, 83U, .ignore_checksum = true, .ignore_counter = true}, { 0 }, { 0 }}},                               \
  {.msg = {{ 0xda, 0, 8, 42U, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}},  \
  {.msg = {{0x101, 0, 8, 50U, .ignore_checksum = true, .ignore_counter = true, .ignore_quality_flag = true}, { 0 }, { 0 }}},  \
```

### 2. Param flag

Used bits today: `ALT_BRAKE 1<<8`, `STOCK_LONGITUDINAL 2<<8`, `LTA 4<<8`,
`SECOC 8<<8`. Next free is `16<<8`. In `toyota_init`, next to the others:

```c
  /* NOT inside the ALLOW_DEBUG block, unlike TOYOTA_PARAM_SECOC: the TSS3 accel
     command is plaintext, so toyota_secoc need not be set for this to work. */
  const uint32_t TOYOTA_PARAM_TSS3 = 16UL << TOYOTA_PARAM_OFFSET;
```

and with the other `GET_FLAG` assignments:

```c
  toyota_tss3 = GET_FLAG(param, TOYOTA_PARAM_TSS3);
```

plus a `static bool toyota_tss3;` alongside `toyota_secoc` / `toyota_lta` in the
file's state declarations.

### 3. Accel check

Modelled exactly on the existing `0x183` SecOC accel check — same encoding,
bytes 0–1, int16 BE, 0.001 m/s². Put it right after that block in
`toyota_tx_hook`:

```c
    // TSS3 ACC_CONTROL. Same encoding as 0x183.
    if (msg->addr == 0x13CU) {
      int desired_accel = (msg->data[0] << 8) | msg->data[1];
      desired_accel = to_signed(desired_accel, 16);

      tx = !longitudinal_accel_checks(desired_accel, TOYOTA_TSS3_LONG_LIMITS);
    }
```

### 4. Tighter limits than stock Toyota

Stock is `max_accel 2000 / min_accel -3500`. The car's own system was only
ever observed commanding **−1.56 .. +2.37 m/s²**, and your `0x13C` decode is
unvalidated, so start well inside that rather than inheriting the generic Toyota
envelope. Next to `TOYOTA_LONG_LIMITS`:

```c
  const LongitudinalLimits TOYOTA_TSS3_LONG_LIMITS = {
    .max_accel = 1500,   // 1.5 m/s2
    .min_accel = -1500,  // -1.5 m/s2
  };
```

### 5. Selection in `toyota_init`

TX, before the `toyota_secoc` branch:

```c
  safety_config ret;
  if (toyota_tss3) {
    static const CanMsg TOYOTA_TSS3_TX_MSGS[] = {
      TOYOTA_TSS3_LONG_TX_MSGS
    };
    SET_TX_MSGS(TOYOTA_TSS3_TX_MSGS, ret);
  } else if (toyota_secoc) {
    ...
```

RX, the same shape:

```c
  if (toyota_tss3) {
    static RxCheck toyota_tss3_rx_checks[] = {
      TOYOTA_TSS3_RX_CHECKS
    };
    SET_RX_CHECKS(toyota_tss3_rx_checks, ret);
  } else if (toyota_secoc) {
    ...
```

### 6. The car side

In `opendbc/car/toyota/values.py`, add to `ToyotaSafetyFlags`:

```python
  TSS3 = (16 << 8)
```

The existing entries are `ALT_BRAKE = (1 << 8)`, `STOCK_LONGITUDINAL = (2 << 8)`,
`LTA = (4 << 8)`, `SECOC = (8 << 8)` — the low byte is the EPS scaling factor, so
the flags start at bit 8. `(16 << 8)` matches `TOYOTA_PARAM_TSS3 = 16UL <<
TOYOTA_PARAM_OFFSET` on the C side.

Then in the CAN FD branch of `interface.py` `_get_params`, in the `else` arm
where longitudinal is enabled:

```python
        ret.safetyConfigs[0].safetyParam |= ToyotaSafetyFlags.TSS3.value
        ret.safetyConfigs[0].safetyParam &= ~ToyotaSafetyFlags.STOCK_LONGITUDINAL.value
```

and flip `TSS3_LONG_IMPLEMENTED = True` in `values.py` plus add the `0x13C` tx
path to `carcontroller.py` (the ready-made
`create_accel_command_tss3()` is in `port/opendbc/car/toyota/carcontroller_tss3_long.snippet.py`).

## Testing it before it touches the car

`opendbc/safety/tests/test_toyota.py` is a real suite — the safety C is compiled
into a shared library and driven from Python, so you can test **without
flashing**, on a PC. Add a TSS3 test class mirroring the SecOC long one, then:

```
cd opendbc_repo && scons -j8 opendbc/safety && pytest opendbc/safety/tests/test_toyota.py
```

There is also `opendbc/safety/tests/misra/` (MISRA-C checks) and `mutation.py`,
which the project runs on safety changes. Worth running both — they exist
precisely because this code is the last line of defence.

Then build and flash panda firmware. `ALLOW_DEBUG` is not needed for this design,
but if you want the SecOC param honoured for anything else, you need a debug
build.

## What this still does not fix

Panda safety is a *limiter*, not an enabler. After all of the above:

- **The driver-cancel signal is still unmapped** (port doc §12.2 item 2). Nothing
  in panda substitutes for openpilot being able to see the driver cancel. This
  remains the blocker your own doc flags, and it is a safety blocker rather than
  a nicety.
- **`0x13C` construction is still unvalidated on the car.** Run the shadow test
  (§12.4) and `validate_dbc.py`'s byte-exact repack check against a real rlog
  first — that check exists to catch exactly this.
- **RX check frequencies above are guesses.** Measure them from an rlog, or the
  panda will drop controls at random.

Order: validate `0x13C` from logs → safety tests on a PC → shadow mode on the
road → only then permit tx.
