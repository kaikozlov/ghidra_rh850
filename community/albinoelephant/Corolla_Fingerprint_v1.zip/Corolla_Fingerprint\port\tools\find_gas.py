#!/usr/bin/env python3
"""Find the gas pedal on the TSS 3.0 powertrain bus (bus 1).

During the manual-driving phase before ACC is first engaged, the driver's gas
pedal is the thing that makes the car accelerate. So a gas-pedal field is:
  - on bus 1
  - ~0 when coasting / braking, positive when the car speeds up
  - strongly correlated with forward acceleration (d vEgo / dt) while ACC is OFF

First checks 0x116 byte 1 (the SecOC Toyota gas address) explicitly, then scans
every bus-1 byte as a fallback.

    python find_gas.py rlog... 
"""
import sys, glob, bisect, math
from collections import defaultdict

from opendbc.car.logreader import LogReader as OP  # for carState we need openpilot's

def main(paths):
  # 1) gather vEgo (carState) and its time base; find first-ACC time from 0x13C
  import importlib
  # carState needs openpilot LogReader (sunnypilot union types)
  from openpilot.tools.lib.logreader import LogReader as CSReader
  ts_v, vego = [], []
  first_acc_t = None
  t0 = None
  for p in paths:
    for m in CSReader(p):
      w = m.which()
      t = m.logMonoTime/1e9
      if t0 is None: t0 = t
      if w == "carState":
        ts_v.append(t-t0); vego.append(m.carState.vEgo)

  # acceleration by finite difference over ~0.2s
  def accel_at(tq):
    i = bisect.bisect_left(ts_v, tq)
    a = max(0, i-2); b = min(len(ts_v)-1, i+2)
    if b<=a or ts_v[b]==ts_v[a]: return None
    return (vego[b]-vego[a])/(ts_v[b]-ts_v[a])

  # 2) gather bus-1 frames and 0x13C LON_ACTIVE timeline (to restrict to ACC-off)
  from opendbc.car.logreader import LogReader
  bus1 = defaultdict(list)   # addr -> [(t, bytes)]
  acc_active = []            # (t, active)
  t0b = None
  for p in paths:
    for m in LogReader(p, only_union_types=True):
      if m.which()!="can": continue
      t = m.logMonoTime/1e9
      if t0b is None: t0b=t
      for c in m.can:
        if c.src==1:
          bus1[c.address].append((t-t0b, bytes(c.dat)))
        if c.src==1 and c.address==0x13C:
          d=bytes(c.dat)
          if len(d)>=8: acc_active.append((t-t0b, bool(d[4]&0x20)))

  at=[x[0] for x in acc_active]
  def is_acc_off(tq):
    if not at: return True
    i=bisect.bisect_left(at,tq)
    j=min(max(0,i),len(acc_active)-1)
    return not acc_active[j][1]

  print(f"carState vEgo samples {len(vego)}, bus1 addrs {len(bus1)}")

  # explicit 0x116 check
  if 0x116 in bus1:
    fr=bus1[0x116]
    b1=[d[1] for _,d in fr]
    print(f"\n0x116 present on bus1: {len(fr)} frames, byte1 range {min(b1)}..{max(b1)}, distinct {len(set(b1))}")
  else:
    print("\n0x116 NOT on bus1")

  # 3) correlate every bus-1 byte against forward accel during ACC-off
  print("\nscanning bus1 bytes vs forward acceleration (ACC off only)...")
  results=[]
  for addr, fr in bus1.items():
    if len(fr)<300: continue
    dlc=min(len(d) for _,d in fr)
    # build aligned (byteval, accel) pairs during ACC-off, moving
    samples=[]
    for t,d in fr:
      if not is_acc_off(t): continue
      a=accel_at(t)
      if a is None: continue
      samples.append((d,a))
    if len(samples)<200: continue
    ys=[s[1] for s in samples]; n=len(ys); my=sum(ys)/n
    syy=sum((y-my)**2 for y in ys)
    if syy<=0: continue
    for off in range(dlc):
      xs=[s[0][off] for s in samples]
      if len(set(xs))<6: continue
      mx=sum(xs)/n; sxx=sum((x-mx)**2 for x in xs)
      if sxx<=0: continue
      r=sum((x-mx)*(y-my) for x,y in zip(xs,ys))/math.sqrt(sxx*syy)
      # a gas pedal: positive r with accel, and mostly-zero when not accelerating
      zero_frac=sum(1 for x in xs if x==0)/n
      if r>0.35:
        results.append((r, addr, off, min(xs), max(xs), zero_frac))
  results.sort(reverse=True)
  print(f"\n{'r':>6} {'addr':>7} {'byte':>4} {'range':>12} {'zero%':>6}")
  for r,addr,off,lo,hi,zf in results[:20]:
    print(f"{r:+6.3f} {addr:#07x} {off:4d}  {lo:3d}..{hi:<3d}     {zf*100:5.0f}")
  if not results:
    print("nothing > 0.35 -- widen or check a manual-accel segment exists")
  return 0

if __name__=="__main__":
  sys.exit(main(sys.argv[1:]))
