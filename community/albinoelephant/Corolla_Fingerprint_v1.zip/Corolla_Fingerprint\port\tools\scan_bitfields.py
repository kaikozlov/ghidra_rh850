#!/usr/bin/env python3
"""Exhaustive bit-field scan of one ADAS message against 0x13C.ACCEL_CMD.

find_adas_accel.py only tried 16-bit big-endian at byte boundaries and found
nothing that held up. This tries EVERY bit offset, widths 8/10/12/14/16, both
endiannesses, signed and unsigned. If the camera sends an acceleration request
in any conventional encoding, it is in here.

    python scan_bitfields.py ADDR rlog.zst [rlog2.zst ...]
"""
import sys, math, bisect
from collections import defaultdict

from opendbc.car.logreader import LogReader

PT_BUS, ADAS_BUS, ACC_CONTROL = 1, 0, 0x13C
WIDTHS = (8, 10, 12, 14, 16)


def bits_be(d, start, width):
    """big-endian / Motorola: MSB first from absolute bit position `start`."""
    v = 0
    for i in range(width):
        b = start + i
        if (b >> 3) >= len(d):
            return None
        v = (v << 1) | ((d[b >> 3] >> (7 - (b & 7))) & 1)
    return v


def bits_le(d, start, width):
    """little-endian / Intel: LSB first."""
    v = 0
    for i in range(width):
        b = start + i
        if (b >> 3) >= len(d):
            return None
        v |= ((d[b >> 3] >> (b & 7)) & 1) << i
    return v


def pearson(xs, ys, n, my, syy):
    mx = sum(xs) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    if sxx <= 0:
        return 0.0
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    return sxy / math.sqrt(sxx * syy)


def main(argv):
    addr = int(argv[0], 0)
    stock, frames = [], []
    t0 = None
    for path in argv[1:]:
        for msg in LogReader(path, only_union_types=True):
            if msg.which() != "can":
                continue
            t = msg.logMonoTime / 1e9
            if t0 is None:
                t0 = t
            for c in msg.can:
                if c.src == PT_BUS and c.address == ACC_CONTROL:
                    d = bytes(c.dat)
                    if len(d) >= 8 and (d[4] & 0x20):
                        r = (d[0] << 8) | d[1]
                        stock.append((t - t0, (r - 0x10000 if r >= 0x8000 else r) * 0.001))
                elif c.src == ADAS_BUS and c.address == addr:
                    frames.append((t - t0, bytes(c.dat)))

    if not stock or not frames:
        sys.exit("missing data")
    dlc = min(len(f[1]) for f in frames)
    print(f"{addr:#05x}: {len(frames)} frames, dlc {dlc}, "
          f"{len(stock)} LON_ACTIVE 0x13C samples")

    at = [s[0] for s in stock]
    aligned = []
    for t, d in frames:
        i = bisect.bisect_left(at, t)
        best = None
        for j in (i - 1, i):
            if 0 <= j < len(stock) and abs(at[j] - t) < 0.06:
                if best is None or abs(at[j] - t) < abs(at[best] - t):
                    best = j
        if best is not None:
            aligned.append((d, stock[best][1]))
    print(f"aligned pairs: {len(aligned)}")
    if len(aligned) < 200:
        sys.exit("too few aligned pairs")

    ys = [a[1] for a in aligned]
    n = len(ys)
    my = sum(ys) / n
    syy = sum((y - my) ** 2 for y in ys)

    # which bytes actually move at all -- skip constants, they can't be a command
    varying = {i for i in range(dlc) if len({a[0][i] for a in aligned[:2000]}) > 3}
    print(f"varying bytes ({len(varying)}): {sorted(varying)}\n")

    out = []
    for start in range(dlc * 8 - 7):
        if (start >> 3) not in varying and ((start + 7) >> 3) not in varying:
            continue
        for w in WIDTHS:
            if (start + w) > dlc * 8:
                continue
            for name, fn in (("be", bits_be), ("le", bits_le)):
                xs = [fn(a[0], start, w) for a in aligned]
                if any(x is None for x in xs):
                    continue
                if len(set(xs)) < 8:
                    continue
                r = pearson(xs, ys, n, my, syy)
                out.append((abs(r), r, start, w, name, "u", min(xs), max(xs)))
                half, full = 1 << (w - 1), 1 << w
                sx = [x - full if x >= half else x for x in xs]
                rs = pearson(sx, ys, n, my, syy)
                out.append((abs(rs), rs, start, w, name, "s", min(sx), max(sx)))

    out.sort(reverse=True)
    print(f"{'bit':>5} {'byte.bit':>9} {'w':>3} {'end':>3} {'sgn':>3} {'r':>7}  range")
    seen = set()
    shown = 0
    for _, r, start, w, end, sgn, lo, hi in out:
        key = (start // 8, w, end, sgn)
        if key in seen:
            continue
        seen.add(key)
        print(f"{start:5d} {start//8:6d}.{start%8} {w:3d} {end:>3} {sgn:>3} "
              f"{r:+7.3f}  {lo} .. {hi}")
        shown += 1
        if shown >= 20:
            break
    print("\nA real acceleration request should reach |r| > 0.9 and its range,")
    print("times a clean scale, should span roughly -2.6 .. +2.4 m/s^2.")


if __name__ == "__main__":
    main(sys.argv[1:])
