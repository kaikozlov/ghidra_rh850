#!/usr/bin/env python3
"""End-to-end smoke test for the TSS 3.0 Phase 1 port.

Builds synthetic CAN frames with CANPacker, feeds them through the real
CANParser, runs the real CarState.update(), and checks the decoded values come
back as the values that went in. Then runs the real CarController and asserts it
emits ZERO messages -- the Phase 1 read-only guarantee, at the opendbc layer.

This does NOT validate the bit positions against the car. It validates that the
port is wired correctly: DBC loads, signals resolve, carState populates, and
nothing is ever transmitted.

Run from inside a sunnypilot checkout's opendbc_repo:

    PYTHONPATH=$PWD python /path/to/test_tss3_port.py
"""
import sys

from opendbc.can import CANPacker
from opendbc.car import Bus, structs
from opendbc.car.toyota.carcontroller import CarController
from opendbc.car.toyota.carstate import CarState
from opendbc.car.toyota.interface import CarInterface
from opendbc.car.toyota.values import CAR, DBC, ToyotaFlags, TSS3_PT_BUS

PLATFORM = "TOYOTA_COROLLA_TSS3"

# what we will encode, and expect to read back
SPEED_KPH = 68.0
ANGLE_DEG = -12.5      # negative = right, since positive = left
YAW_DEG_S = 3.4
GEAR_DRIVE = 4         # byte-4 one-hot: P=1 R=2 D=4 N=8

failures = []


def check(name, got, want, tol=None):
    ok = abs(got - want) <= tol if tol is not None else got == want
    print(f"  {'ok  ' if ok else 'FAIL'} {name:<28} got {got!r:<24} want {want!r}")
    if not ok:
        failures.append(name)


def main():
    CP = structs.CarParams()
    CP.carFingerprint = PLATFORM
    CP.flags = int(CAR.TOYOTA_COROLLA_TSS3.config.flags)
    # get_std_params() sets this to 1.0 in the real stack; a bare CarParams has
    # 0.0, which would silently zero vEgo (parse_wheel_speeds multiplies by it).
    CP.wheelSpeedFactor = 1.0
    CP_SP = structs.CarParamsSP()

    assert CP.flags & ToyotaFlags.CAN_FD.value, "CAN_FD flag not set on the platform"
    dbc_name = DBC[PLATFORM][Bus.pt]
    print(f"platform {PLATFORM}, dbc {dbc_name}, flags {ToyotaFlags(CP.flags)!r}\n")

    cs = CarState(CP, CP_SP)
    parsers = CarState.get_can_parsers(CP, CP_SP)
    cp = parsers[Bus.pt]
    packer = CANPacker(dbc_name)

    def frame():
        wheel = SPEED_KPH + 67.67  # DBC offset is -67.67
        return [
            packer.make_can_msg("WHEEL_SPEEDS", TSS3_PT_BUS, {
                "WHEEL_SPEED_FL": SPEED_KPH, "WHEEL_SPEED_FR": SPEED_KPH,
                "WHEEL_SPEED_RL": SPEED_KPH, "WHEEL_SPEED_RR": SPEED_KPH}),
            # ACC_STATE/ACC_ENGAGED values are the ones decoded from the real
            # drive on 2026-09-09: 0x47 = engaged, 0x12 = on but not engaged.
            packer.make_can_msg("STEER_ANGLE_ACC_STATUS", TSS3_PT_BUS, {
                "STEER_ANGLE": ANGLE_DEG,
                "ACC_STATE": 0x47, "ACC_ENGAGED": 1}),
            packer.make_can_msg("ACC_HUD", TSS3_PT_BUS, {"SET_SPEED": 25}),
            packer.make_can_msg("STEER_ANGLE_SENSOR", TSS3_PT_BUS, {"STEER_ANGLE": ANGLE_DEG}),
            packer.make_can_msg("KINEMATICS", TSS3_PT_BUS, {"YAW_RATE": YAW_DEG_S}),
            packer.make_can_msg("STEER_TORQUE_SENSOR", TSS3_PT_BUS, {
                "TORQUE_1": 120, "TORQUE_2": -35}),
            packer.make_can_msg("BRAKE_MODULE", TSS3_PT_BUS, {
                "BRAKE_PRESSED": 0, "BRAKE_PRESSURE": 0}),
            packer.make_can_msg("GEAR_PACKET", TSS3_PT_BUS, {"GEAR": GEAR_DRIVE}),
            packer.make_can_msg("GAS_PEDAL", TSS3_PT_BUS, {"GAS_PEDAL_USER": 40}),
            packer.make_can_msg("SECOC_SYNCHRONIZATION", TSS3_PT_BUS, {
                "TRIP_CNT": 0x0D7B, "RESET_CNT": 1234, "AUTHENTICATOR": 0}),
            # the STOCK longitudinal command, actively controlling
            packer.make_can_msg("ACC_CONTROL", TSS3_PT_BUS, {
                "ACCEL_CMD": -0.5, "BYTE2_FLAGS": 0xFF, "LON_BASE": 1,
                "LON_ACTIVE": 1, "DISTANCE_ACTIVE": 0}),
            # the CAMERA's 0x160 ACC request on the ADAS bus (bus 2). Carries a
            # distinct accel (+0.30) and a counter so the template is realistic.
            packer.make_can_msg("ADAS_ACC_REQUEST", 2, {
                "ACCEL_REQ": 0.30, "COUNTER": 0x11, "BYTE03": 0x82,
                "BYTE06": 0x40, "BYTE15": 0x80, "BYTE16": 0x02}),
        ]

    # several iterations so the speed Kalman filter settles
    t = 0
    cam = parsers[Bus.cam]
    for _ in range(60):
        t += 10_000_000  # 10 ms
        msgs = frame()
        # each parser filters by its own bus, so feed the full list to both --
        # the ADAS_ACC_REQUEST template lives on bus 2 (the cam parser).
        cp.update([(t, msgs)])
        cam.update([(t, msgs)])
        ret, ret_sp = cs.update(parsers)

    print("carState decode:")
    check("vEgo (m/s)", ret.vEgo, SPEED_KPH / 3.6, tol=0.2)
    check("steeringAngleDeg", ret.steeringAngleDeg, ANGLE_DEG, tol=0.1)
    check("yawRate (deg/s)", ret.yawRate, YAW_DEG_S, tol=0.05)
    check("steeringTorque", ret.steeringTorque, 120, tol=0.5)
    check("steeringTorqueEps", ret.steeringTorqueEps, -35, tol=0.5)
    check("brakePressed", ret.brakePressed, False)
    check("gasPressed", ret.gasPressed, True)
    check("gearShifter", str(ret.gearShifter), "drive")
    check("cruiseState.available", ret.cruiseState.available, True)
    # from 0x8A ACC_ENGAGED -- independent of 0x13C, so valid in LIVE too
    check("cruiseState.enabled", ret.cruiseState.enabled, True)
    check("cruiseState.speed (25 mph)", ret.cruiseState.speed, 25 * 0.44704, tol=0.01)
    check("secoc TRIP_CNT", int(cs.secoc_synchronization["TRIP_CNT"]), 0x0D7B)
    check("secoc RESET_CNT", int(cs.secoc_synchronization["RESET_CNT"]), 1234)

    print("\nCarParams the device would actually build:")
    real = CarInterface.get_params(PLATFORM, {i: {} for i in range(8)}, [],
                                   alpha_long=False, is_release=False, docs=False)
    # noOutput = the panda receives everything and transmits nothing. dashcamOnly
    # False so the driving model still runs and renders lanes. That pair IS the
    # Phase 1 requirement from section 7 item 5 of the port doc.
    check("safetyModel", str(real.safetyConfigs[0].safetyModel), "noOutput")
    check("safetyParam", real.safetyConfigs[0].safetyParam, 0)
    check("dashcamOnly (model runs)", real.dashcamOnly, False)
    check("openpilotLongitudinalControl", real.openpilotLongitudinalControl, False)
    check("secOcRequired", real.secOcRequired, True)
    # no stop-and-go: openpilot must hand back before standstill, since the ACC
    # standstill/hold state is not decoded yet
    check("minEnableSpeed (19 mph)", real.minEnableSpeed, 19 * 0.44704, tol=0.01)

    print("\nPhase 1 read-only invariants:")

    # brake pressed should follow the bit
    cp.update([(t + 10_000_000, [packer.make_can_msg("BRAKE_MODULE", TSS3_PT_BUS, {
        "BRAKE_PRESSED": 1, "BRAKE_PRESSURE": 300})])])
    ret, _ = cs.update(parsers)
    check("brakePressed (asserted)", ret.brakePressed, True)

    print("\ncarController must transmit nothing:")
    cc = CarController(DBC[PLATFORM], CP, CP_SP)
    cs.out = ret
    sent_any = False
    for i in range(200):  # >1s at 100 Hz, covers every framing interval
        CC = structs.CarControl()
        CC.enabled = True
        CC.latActive = True
        CC.longActive = True
        CC.actuators.accel = 1.5
        CC.actuators.torque = 1.0
        # carcontroller does actuators.as_builder(), so CC must be a reader --
        # this mirrors how the real stack hands CarControl to the interface.
        _, can_sends = cc.update(CC.as_reader(), structs.CarControlSP(),
                                 cs, i * 10_000_000)
        if can_sends:
            sent_any = True
            print(f"  FAIL frame {i} emitted {len(can_sends)} msg(s): "
                  f"{[hex(m[0]) for m in can_sends]}")
            break
    check("messages sent over 200 frames", sent_any, False)

    # ---- the three longitudinal modes -------------------------------------
    # Each is checked for what the panda would be told AND what the
    # carcontroller actually emits, since those are separate gates.
    print("\nTSS3_LONG_MODE matrix:")
    import opendbc.car.toyota.carcontroller as ccmod
    import opendbc.car.toyota.interface as imod
    from opendbc.car.toyota.values import TSS3LongMode

    expected = {
        # mode:              (toggle offered, safety model, addrs sent when on)
        TSS3LongMode.OFF:    (False, "noOutput", []),
        TSS3LongMode.SHADOW: (True,  "noOutput", []),
        TSS3LongMode.LIVE:   (True,  "toyota",   [0x160]),
    }
    for mode, (want_shown, want_safety, want_addrs) in expected.items():
        imod.TSS3_LONG_MODE = mode
        ccmod.TSS3_LONG_MODE = mode
        fp_m = {i: {} for i in range(8)}
        cp_m = CarInterface.get_params(PLATFORM, fp_m, [], alpha_long=True,
                                       is_release=False, docs=False)
        # MUST also run get_params_sp: sunnypilot's second pass overwrites
        # openpilotLongitudinalControl for every TSS2 car and previously left
        # oplong=True alongside a noOutput safety config -- openpilot thinking
        # it controlled longitudinal while the panda blocked every frame.
        CarInterface.get_params_sp(cp_m, PLATFORM, fp_m, [], True, False, False)
        # The invariant: the panda is only ever put in a TX-permitting mode when
        # openpilot actually has longitudinal control AND we are in LIVE.
        # SHADOW is deliberately oplong=True + noOutput -- planner runs, nothing
        # is transmitted. What must never happen is toyota safety without
        # oplong, or LIVE+oplong without toyota safety.
        tx_permitting = str(cp_m.safetyConfigs[0].safetyModel) == "toyota"
        check(f"mode {mode} tx-permitting iff LIVE+oplong",
              tx_permitting,
              cp_m.openpilotLongitudinalControl and mode == TSS3LongMode.LIVE)
        check(f"mode {mode} toggle offered", cp_m.alphaLongitudinalAvailable, want_shown)
        check(f"mode {mode} safety", str(cp_m.safetyConfigs[0].safetyModel), want_safety)

        cp_m.wheelSpeedFactor = 1.0
        cc_m = CarController(DBC[PLATFORM], cp_m, CP_SP)
        cc_m.CP = cp_m
        from opendbc.car.toyota.e2e import apply_e2e_160
        _out = structs.CarState(vEgo=20.0)     # above the standstill handback
        _out.cruiseState.enabled = True
        _out.gasPressed = False
        cs.out = _out
        cs.tss3_stock_lon_active = True
        base = bytearray(32); base[3] = 0x82; base[6] = 0x40; base[15] = 0x80; base[16] = 0x02
        addrs = set()
        for i in range(200):
            fr = bytearray(base); fr[2] = i & 0xFF   # advancing camera counter
            cs.tss3_accel_template = apply_e2e_160(bytes(fr))
            CC = structs.CarControl()
            CC.enabled = CC.latActive = CC.longActive = True
            CC.actuators.accel = 1.0
            CC.actuators.torque = 1.0
            _, sends = cc_m.update(CC.as_reader(), structs.CarControlSP(), cs, i * 10_000_000)
            addrs.update(m[0] for m in sends)
        check(f"mode {mode} addrs sent", sorted(addrs), sorted(want_addrs))

        # In LIVE, prove the forged 0x160 is a VALID E2E frame carrying
        # openpilot's accel (1.0), not the camera's template value (0.30).
        if mode == TSS3LongMode.LIVE:
            from opendbc.car.toyota.e2e import e2e_160_valid
            fr = bytearray(base); fr[2] = 250   # a fresh camera counter
            cs.tss3_accel_template = apply_e2e_160(bytes(fr))
            CC = structs.CarControl()
            CC.enabled = CC.latActive = CC.longActive = True
            CC.actuators.accel = 1.0
            _, sends = cc_m.update(CC.as_reader(), structs.CarControlSP(), cs, 999 * 10_000_000)
            msg = next(m for m in sends if m[0] == 0x160)
            d = bytes(msg[1])
            check("LIVE forged 0x160 length 32", len(d), 32)
            check("LIVE forged 0x160 on bus 0", msg[2], 0)
            check("LIVE forged 0x160 E2E CRC valid", e2e_160_valid(d), True)
            raw = ((d[4] & 0x7f) << 8) | d[5]
            if d[4] & 0x40:
                raw -= 0x8000
            check("LIVE forged accel is openpilot's (1.0)", raw * 0.001, 1.0, tol=0.02)
            # a preserved passthrough byte from the template (byte 3 = 0x82)
            check("LIVE template passthrough preserved", d[3], 0x82)

    imod.TSS3_LONG_MODE = TSS3LongMode.OFF
    ccmod.TSS3_LONG_MODE = TSS3LongMode.OFF

    print()
    if failures:
        print(f"FAILED: {len(failures)} check(s): {failures}")
        return 1
    print("ALL CHECKS PASSED (wiring only -- bit positions still unvalidated on the car)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
