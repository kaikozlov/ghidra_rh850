#!/usr/bin/env python3
"""Generate the fixed {addr: len} fingerprint dict from a real rlog.

FW fingerprinting is impossible on this car (the ECUs return zero UDS responses
on the tapped buses), so the fixed message-set fingerprint is the ONLY way it
gets identified. That makes this dict load-bearing.

Run with opendbc importable (sunnypilot repo root + opendbc_repo on PYTHONPATH):

    python gen_fingerprint.py path/to/rlog.bz2 [more_rlogs...] [--bus 0]

Pass EVERY segment you have. The dict is a superset (see below), so unioning
across segments is strictly safer than trusting one: a message that only appears
in some conditions (reverse, blinkers, a door open, standstill) is missing from
a single-segment dict and will eliminate the platform the moment it shows up.

Prints a dict ready to paste into opendbc/car/toyota/fingerprints.py.


HOW MATCHING ACTUALLY WORKS -- read before changing the filtering.
Verified against opendbc/car/fingerprints.py and car_helpers.can_fingerprint():

    is_valid_for_fingerprint(msg, fp):
        return (adr in fp and fp[adr] == len(msg.dat)) or adr >= 0x800

    can_fingerprint(): for each received message with
        can.address < 0x800 and can.address not in (0x7df, 0x7e0, 0x7e8)
      any candidate platform whose fingerprint does NOT contain that
      (address, length) is ELIMINATED.

Three consequences that drive this script:

  1. The dict must be a SUPERSET of everything the car emits below 0x800.
     One un-listed address eliminates the platform -- permanently, for that
     drive. So filtering out rare messages is actively harmful: this script
     keeps every address by default. --min-count exists only for diagnosing a
     noisy log and should normally be left at 1.

  2. Addresses >= 0x800 are auto-valid and never need listing, so they are
     dropped. 0x7df / 0x7e0 / 0x7e8 are the VIN-query addresses and are
     explicitly skipped by the matcher, so they are dropped too. NOTE the cut
     is 0x800, not 0x700 -- 0x700-0x7FF DO need to be listed if the car sends
     them.

  3. Fingerprinting runs independently on bus 0 and bus 1, and needs exactly
     ONE surviving candidate on some bus. A bus-0 dict is enough.
"""
import argparse
import sys
from collections import Counter

try:
    # opendbc ships its own reader: takes a plain rlog path or URL, no openpilot
    # dependency. Preferred.
    from opendbc.car.logreader import LogReader
except ImportError:  # pragma: no cover
    try:
        from openpilot.tools.lib.logreader import LogReader
    except ImportError:
        sys.exit("run this inside a sunnypilot/openpilot checkout, with the repo root "
                 "and opendbc_repo on PYTHONPATH")

VIN_QUERY_ADDRS = (0x7DF, 0x7E0, 0x7E8)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("rlogs", nargs="+",
                    help="one or more rlog.bz2 / rlog.zst paths or URLs. NOT qlogs -- "
                         "those are decimated and do not carry every CAN frame. Pass all "
                         "the segments you have; the results are unioned")
    ap.add_argument("--bus", type=int, default=0)
    ap.add_argument("--min-count", type=int, default=1,
                    help="drop addresses seen fewer than N times. LEAVE AT 1 unless "
                         "diagnosing: dropping a real message eliminates the platform")
    args = ap.parse_args()

    counts: Counter = Counter()
    lengths: dict[int, set[int]] = {}

    per_log: dict[str, set[int]] = {}
    for path in args.rlogs:
        before = set(counts)
        for msg in LogReader(path, only_union_types=True):
            if msg.which() != "can":
                continue
            for c in msg.can:
                if c.src != args.bus:
                    continue
                # exactly the matcher's own filter
                if c.address >= 0x800 or c.address in VIN_QUERY_ADDRS:
                    continue
                counts[c.address] += 1
                lengths.setdefault(c.address, set()).add(len(c.dat))
        per_log[path] = set(counts) - before
        print(f"# {path}: {len(counts)} cumulative, {len(per_log[path])} new", file=sys.stderr)

    if not counts:
        sys.exit(f"no messages found on bus {args.bus}")

    # qlog trap: cereal/services.py sets can decimation to 2053, i.e. roughly
    # THREE can events survive into a qlog for a whole segment. A qlog therefore
    # does not fail loudly here -- it yields a small, plausible-looking dict that
    # would eliminate the platform on the first unlisted message. Refuse it.
    total_events = sum(counts.values())
    if total_events < 1000:
        sys.exit(f"only {total_events} can frames on bus {args.bus} across "
                 f"{len(args.rlogs)} log(s). That is far too few for a real drive -- "
                 "you almost certainly passed a qlog (decimation 2053, ~3 can events "
                 "per segment) instead of an rlog. Use rlog.zst / rlog.bz2.")

    # If the last log still contributed new addresses, the set has not converged
    # and there are probably more messages you have not captured yet.
    last = args.rlogs[-1]
    if len(args.rlogs) > 1 and per_log[last]:
        print(f"# WARNING: the last log still added {len(per_log[last])} new address(es) "
              f"({[hex(a) for a in sorted(per_log[last])]}).", file=sys.stderr)
        print("# The set has not converged -- add more segments before trusting this dict.",
              file=sys.stderr)

    kept = {a: n for a, n in counts.items() if n >= args.min_count}
    dropped = sorted(set(counts) - set(kept))

    # An address whose DLC varies cannot be fingerprinted: the matcher compares
    # fp[addr] == len(dat) exactly, so whichever length you pick, the other one
    # eliminates the platform.
    unstable = {a: sorted(lengths[a]) for a in kept if len(lengths[a]) > 1}
    if unstable:
        print("ERROR: these addresses changed DLC within the log. A fingerprint cannot", file=sys.stderr)
        print("be built until that is understood -- whichever length you list, the other", file=sys.stderr)
        print("one will eliminate the platform at runtime:", file=sys.stderr)
        for a, ls in unstable.items():
            print(f"  {a:#x}: {ls}", file=sys.stderr)
        return 1

    fp = {a: next(iter(lengths[a])) for a in sorted(kept)}

    print(f"# bus {args.bus}, {len(fp)} messages, unioned from {len(args.rlogs)} log(s):")
    for path in args.rlogs:
        print(f"#   {path}")
    if dropped:
        print(f"# WARNING: dropped {len(dropped)} address(es) seen < {args.min_count}x: "
              f"{[hex(a) for a in dropped]}")
        print("# each of these will ELIMINATE the platform if it ever appears. Prefer --min-count 1.")
    print("  CAR.TOYOTA_COROLLA_TSS3: [{")
    line = "   "
    for a, l in fp.items():
        piece = f" {a}: {l},"
        if len(line) + len(piece) > 118:
            print(line)
            line = "   "
        line += piece
    if line.strip():
        print(line)
    print("  }],")

    if len(fp) != 142:
        print(f"\n# NOTE: got {len(fp)} messages; the port doc expected 142. Reconcile before", file=sys.stderr)
        print("# using -- a short set may fail to converge, a long one is harmless.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
