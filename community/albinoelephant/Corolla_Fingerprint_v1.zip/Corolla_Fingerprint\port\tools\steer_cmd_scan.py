#!/usr/bin/env python3
"""Find the LTA steering COMMAND: a field that is IDLE (flat) when LTA is off and
ACTIVE when engaged. Scans all buses; ranks by (std_engaged) with std_off ~ 0.
"""
import sys, bisect, statistics, math
from collections import defaultdict

def s16be(d,i):
    if i+1>=len(d): return None
    v=(d[i]<<8)|d[i+1]; return v-0x10000 if v>=0x8000 else v

def main(paths):
    from opendbc.car.logreader import LogReader as CAN
    eng=[]; frames=defaultdict(list); t0=None
    for p in paths:
        for m in CAN(p, only_union_types=True):
            if m.which()!="can": continue
            t=m.logMonoTime/1e9
            if t0 is None: t0=t
            for c in m.can:
                if c.src not in (0,1,2): continue
                d=bytes(c.dat)
                frames[(c.src,c.address)].append((t-t0,d))
                if c.address==0x8A and c.src==1 and len(d)>=23:
                    eng.append((t-t0,1 if d[22]&0x10 else 0))
    et=[e[0] for e in eng]
    def eng_at(tq):
        if not et: return 0
        i=min(bisect.bisect_left(et,tq),len(eng)-1); return eng[i][1]
    res=[]
    for (bus,addr),fr in frames.items():
        if len(fr)<300: continue
        dlc=min(len(d) for _,d in fr)
        for off in range(dlc-1):
            ve=[];vo=[]
            for t,d in fr:
                v=s16be(d,off)
                if v is None: continue
                (ve if eng_at(t)==1 else vo).append(v)
            if len(ve)<100 or len(vo)<100: continue
            se=statistics.pstdev(ve); so=statistics.pstdev(vo)
            # command signature: active engaged, flat off
            if se>20 and so<max(2.0, se*0.05):
                res.append((se, bus, addr, off, so, min(ve), max(ve)))
    res.sort(reverse=True)
    print(f"{'std_ENG':>8} {'std_OFF':>8} {'bus':>3} {'addr':>7} {'byte':>4}  eng range")
    for se,bus,addr,off,so,lo,hi in res[:20]:
        print(f"{se:8.0f} {so:8.1f} {bus:3d} {addr:#07x} {off:4d}  {lo}..{hi}")
    if not res: print("none found -- command may be sub-16-bit or not idle-when-off")
    return 0

if __name__=="__main__":
    sys.exit(main(sys.argv[1:]))
