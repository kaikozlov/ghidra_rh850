# Context: porting the 2023 GR Corolla (TSS 3.0) to sunnypilot

Engineering handoff for adding a **new CAN FD + SecOC Toyota platform**. Written to
be dropped into a repo and read by Claude Code (or a person) working against a live
sunnypilot/staging checkout.

> **Status discipline (read first).** Everything below is *decoded from passive
> rlogs*, i.e. **specified, not confirmed**. Correlation in an analysis script is not
> the same as openpilot's `CANParser` producing the right value live on the device.
> Nothing here is validated until it runs on the car (see §9 validation gate).
> Bit positions, factors, and the CAN FD parse path have **never executed** — treat
> them as strong hypotheses to verify, not ground truth.

---

## 0. TL;DR

- Car fingerprints as `MOCK` → `dashcamOnly`, `noOutput`. Unsupported; no existing
  profile fits (it's CAN FD + SecOC; no Toyota platform is CAN FD).
- FW fingerprinting is impossible (ECUs return zero UDS responses on tapped buses)
  → identification must be a **fixed message-set fingerprint**.
- **Phase 1 (fingerprint + read-only carState + live model/lanes) needs NO wiring
  changes.** Buildable now; validated on-device.
- **Phase 2 (openpilot sends steering) is blocked on hardware:** the steering
  command rides on the camera's **CA2 bus (connector pins 1/2)**, which the comma
  Toyota-B harness passes straight through and never routes to the device. Proven
  absent from every tapped bus even with stock LTA actively steering.
- EPS SecOC verification is already bypassed in firmware (owner's mod), so a dummy
  MAC key will work for the command **once CA2 is physically intercepted**.

---

## 1. Vehicle identity — decoded

| | |
|---|---|
| VIN | `5YFS4MCE3PP163477` (check digit valid) |
| Decode | WMI `5YF` = Toyota Mississippi; MY code `P` = 2023; GR Corolla |
| VIN on bus | broadcast in clear on `0x580`/`0x581`/`0x582` (bus 0) |
| Wheelbase | 2.64 m (starting guess) |
| Camera doc | GR Corolla forward recognition camera, connector **T21** (16-pin) |

Redact the VIN before sharing logs publicly.

---

## 2. Stack architecture (why the edits look the way they do)

- **opendbc** is a git submodule at `opendbc_repo/` (`.gitmodules`:
  `url = ../../commaai/opendbc.git`). Since the 2024 refactor it holds the DBC files
  (`opendbc/dbc/`) AND the whole car layer (`opendbc/car/**` — values, carstate,
  carcontroller, interfaces, fingerprints, CANParser/CANPacker, `car.capnp`).
- **panda** is a *separate* submodule with its own C safety firmware flashed to the
  panda. It independently authorizes tx. opendbc edits alone can't make the device
  send steering — the panda safety mode must also permit it. `MOCK` → no-output
  safety → tx blocked by design.
- **Identification** (`opendbc/car/car_helpers.py`): (1) FW fingerprint vs
  `FW_VERSIONS` — dead here; (2) fixed fingerprint via `{addr:len}` vs `FINGERPRINTS`
  — our path; (3) `FINGERPRINT` env/param override — only to a platform already in
  `interfaces[]`; (4) no match → `MOCK`.
- **Runtime**: pandad → `can` → CarState.update() runs CANParser over the DBC
  (signals by name) → `carState`. Reverse: carController → CANPacker → `sendcan` →
  pandad → bus.
- **Consequence**: the real deliverable is a **DBC** encoding the signals in §4 plus
  a platform entry whose `dbc_dict` points at it. Python is thin glue.

---

## 3. Bus topology (as currently tapped) — decoded

The comma's harness intercepts camera connector pins **9–16** (not 1–8). That taps
two of the camera's three CAN buses:

| Camera T21 pins | Bus name | Tapped? | What the comma sees |
|---|---|---|---|
| 9/10 (CA1N/CA1P) | CA1 | yes | one of {powertrain, ADAS} |
| 11/12 (CANL/CANH) | CAN | yes | the other of {powertrain, ADAS} |
| **1/2 (CA2L/CA2P)** | **CA2** | **NO — passes through 1–8** | **the steering-command bus** |

Owner has swapped pink↔orange and blue↔green at the harness. Pink/orange are both
CAN-H, blue/green both CAN-L, so H/L polarity is preserved — the swap only relabels
CA1↔CAN(11/12) between transceivers. It does **not** and cannot reach CA2.

openpilot bus numbering as observed in logs:

| openpilot bus | content |
|---|---|
| 0 | powertrain: wheel speeds, steering angle, yaw, brake, ACC, gear, VIN, SecOC set |
| 1 | ADAS: pure CAN FD, object tracks (`0x180`–`0x18b`), lane data, angle echo |
| 2 | **byte-identical to bus 0** (two transceivers on the same physical bus — the redundant one) |

`bus0 ≡ bus2` is the tell that the CA2 intercept is not happening: one transceiver
is redundant, and CA2 reaches none of them.

Fixed fingerprint = 142 messages `{addr:len}` on bus 0, stable across every drive,
all 11-bit IDs, distinctive 32-byte DLCs → should converge to a single candidate.

---

## 4. Decoded carState signals

DBC convention: for a big-endian (`@0`) value at byte offset K, `startbit = K*8 + 7`.
**All positions pending live cabana/CANParser validation.**

### Higher confidence (strong IMU correlation, cross-checked across segments)

| Signal | Msg | Layout | Scale | Evidence |
|---|---|---|---|---|
| Wheel speeds ×4 | `0xAA` (170), 8B | `7\|16@0+`,`23\|16@0+`,`39\|16@0+`,`55\|16@0+` | `(0.01,-67.67)` km/h | legacy Toyota layout; inside wheels slower in turns |
| Steering angle | `0x30` (48), 32B | `167\|16@0-` (byte 20–21) | see note | r=0.999 vs curvature; 16-bit beats 8-bit (low byte fractional) |
| Steering angle (alt) | `0x8A` (138), 32B | `151\|16@0-` (byte 18–19) | same | r=0.999; same msg carries ACC state |
| Yaw rate | `0x90` (144), 32B | 12-bit signed @ stream bit 99 | ~50 raw/deg/s | r=0.999 vs gyro |
| Brake pressed | `0x101` (257), 8B | byte 0 bit 3 (`0x80`→`0x88`) | bool | r=0.85 vs decel |
| Brake pressure | `0x101`, 8B | `23\|16@0+` (byte 2–3) | 0–410 raw | tracks decel |
| ACC main-on | `0x8A`, 32B | byte 24 = 0 / 100 | enable flag | 0→100 at ACC button; confirmed across seg2 + seg3-10 |
| Gear (PRND) | `0x2A1` (673), 8B | byte 4 one-hot: P=`0x01` R=`0x02` D=`0x04` N=`0x08`(inferred) | enum | P→R→D caught at drive starts; agrees across logs |
| Gear (alt) | `0x3BF` (959), 8B | byte 0: P=`0x80` R=`0x40` D=`0x10` N=`0x20`(inferred) | enum | mirrors `0x2A1` b4 |
| Steering torque | `0xDA` (218), 8B, 42Hz, no MAC | four int16 | — | swung when wheel forced at standstill; confirm driver vs EPS field |

**Steering scale**: `scale/steerRatio = 0.061 ± 0.002 deg/count` (joint bicycle fit,
R²=0.993). Scale & steerRatio not separable from yaw alone; if steerRatio≈13.9 then
scale≈0.84 deg/count. NOT the legacy 1.5. Sign: **positive = left** (verified).

### Lower confidence

| Signal | Msg | Note |
|---|---|---|
| ACC set speed | `0x113` (275) byte 2 | held 27 (mph?) ≈ plateau, but never changed in any log |
| Neutral gear code | `0x2A1`/`0x3BF` | inferred from bit pattern; N never occurred |

### `0x8A` frame map (32B CAN FD, 40 Hz)

```
byte 18-19  STEER_ANGLE int16 BE   -> DBC 151|16@0-   [validate]
byte 24     ACC_MAIN_ON 0/100      -> DBC 195|8@0+    [validate]
byte 26     SecOC message counter
byte 28-31  SecOC MAC (random every frame)
```

---

## 5. SecOC — decoded

10 signed messages = payload + 4-byte truncated AES-CMAC, matching opendbc
`add_mac`/`build_sync_mac` (`opendbc/car/secoc.py`), i.e. RAV4-Prime/Sienna scheme:
`0x0F` (10Hz sync), `0x25`, `0x30`, `0x81`, `0x8A`, `0x90`, `0x97`, `0xD7`, `0x115`,
`0x116`. `0x0F`: TRIP_CNT bytes 0–1 (const `0x0D7B`), RESET_CNT bytes 2–3 (+1 every
4.80 s), MAC bytes 4–7.

Note: `0x115`/`0x116` are 42 Hz SecOC and were long suspected to be
STEERING_LKA/LTA. **Ruled out** — even with LTA actively steering they do not track
the wheel; `0x116` is a duplicated-byte scalar tracking acceleration (longitudinal),
`0x115`'s active byte is erratic. The steering command is NOT in the tapped SecOC set.

SecOC authenticates, does not encrypt → payloads readable, so Phase 1 needs no key.
Owner has **bypassed EPS SecOC verification in firmware**, so Phase-2 command can use
a **dummy 16-byte key** in `add_mac` — once CA2 is reachable.

---

## 6. LTA engagement + the command bus — decoded (KEY FINDING)

Route `6b311f199c`, segments 0–10 analysed. **LTA confirmed engaged**: segments 3–10
show ACC main-on 100%, 68–74 km/h, and in segments 6/7/9/10 the wheel holds within
~15 counts of center at speed = the stock system lane-centering. Owner's hands-off
curve was real.

**But the steering command is on no tapped bus, even mid-steer.** Verified three ways
on the engaged segments:
- `0x115`/`0x116` (42 Hz SecOC) do not track the wheel (r≈0.3).
- No message wakes as a command when LTA engages; nothing leads the angle-rate.
- Full scan of bus 0/1/2 returns only angle sensors, the angle echoed to the ADAS
  bus (`0x160`/`0x1A0`), and object-track positions that shift with heading.
- `bus0 ≡ bus2` exactly; `0x2E4`/`0x191` present on no bus.

**Conclusion (physical, not analytical):** the camera→EPS steering command
(`STEERING_LKA`/`LTA`, SecOC) rides on **CA2 = camera T21 pins 1/2**, which the
harness passes straight through (pins 1–8 not intercepted). No log from the current
harness can ever contain it. This is a wiring limitation, not a missing segment.

---

## 7. Phase 1 — fingerprint + read-only carState + live model (NO wiring changes)

Goal: car recognized off MOCK, correct live carState, and the comma's camera/model
rendering lanes + path on screen — with **guaranteed zero actuation**. This needs
only the buses already tapped.

**opendbc fork changes:**

1. **DBC** — new `opendbc/dbc/toyota_corolla_tss3_pt.dbc` (start fresh; legacy
   8-byte Toyota layouts mostly don't apply). Define: `WHEEL_SPEEDS` (170),
   `STEER_ANGLE` msgs (48/138 with `ACC_MAIN_ON`), `YAW` (144), `BRAKE` (257),
   `GEAR_PACKET` (673, byte-4 one-hot), `STEER_TORQUE` (218),
   `SECOC_SYNCHRONIZATION` (15). **Validate every bit in cabana against a real rlog.**
2. **values.py** — add `CAR.TOYOTA_COROLLA_TSS3`. CAN FD + SecOC, so do NOT reuse a
   stock `ToyotaSecOCPlatformConfig` (loads 8-byte DBC). Point `dbc_dict[Bus.pt]` at
   the new DBC. `CarSpecs(mass≈1470, wheelbase=2.64, steerRatio=13.9)` as a start.
   Flags: `TSS2 | NO_DSU | SECOC` + a CAN FD flag (new for Toyota — mirror the
   Hyundai CAN FD pattern).
3. **fingerprints.py** — add `FINGERPRINTS = {CAR.TOYOTA_COROLLA_TSS3: [ {…142…} ]}`
   (regenerate the full dict from a real rlog: bus-0 addrs, drop `>=0x700` and
   `0x18daXXf1`, emit `{addr:len(dat)}`).
4. **carstate.py** — read the named signals into `carState`. Stub all longitudinal.
5. **NOT dashcam.** Set the platform non-`dashcamOnly` so the driving model spins up
   and renders lanes/path — BUT keep the safety mode read-only/no-tx so there is
   **no actuation**. This is the combination that gives live model + guaranteed
   passive. (A dashcam-flagged car may not run the full model; a non-dashcam car
   with a tx-permitting safety mode WOULD try to actuate — neither is what we want.
   Non-dashcam + no-output safety = watch everything, send nothing.)

Reference to copy: **Hyundai CAN FD** (`hyundai/values.py`, `hyundaicanfd.py`,
`carstate.py`, `CanBus`) — the only mature CAN FD carState + multi-bus layout in the
tree. Toyota gives SecOC; Hyundai gives CAN FD; no single platform has both, which is
why this is a new platform, not a forced one.

On the road in Phase 1: the comma's camera + model render lanes and a predicted path,
carState reads correctly, and openpilot applies **no steering**. The factory LKA/LTA
underneath is untouched and steers as stock (that's the camera, not openpilot).

---

## 8. Phase 2 — sending steering (blocked on CA2 hardware)

Requires ALL of:
1. **CA2 intercept.** Cut CA2 (camera pins 1/2), route camera-side → a panda CAN
   transceiver RX (lands as openpilot bus 2, where Toyota code expects
   STEERING_LKA), transceiver TX → car-side. In-line, not a Y (a Y lets camera +
   comma both drive the EPS → conflict).
   - Hardware reality: all 3 panda transceivers are currently used (2 on CA1 → the
     bus0≡bus2 redundancy, 1 on CAN 11/12). Freeing the redundant bus-2 transceiver
     for CA2 is the likely path unless a genuine 4th CAN port is broken out.
   - **Verify before cutting:** (a) scope camera pins 1/2 during LTA to confirm 42 Hz
     SecOC traffic is actually there; (b) continuity-check that any "spare" Molex slot
     truly lands on a CAN transceiver (empty cavities are often unconnected).
2. **Decode the command.** Only possible once CA2 is captured — address, torque/angle
   field, counter, checksum/MAC are ALL currently unknown (never observed). Do NOT
   assume `0x2E4`/8-byte from other Toyotas.
3. **carcontroller.py** — `create_steer_command` + `add_mac` with a dummy 16-byte key
   (EPS bypass). Handle the rate and counter; reset on `0x0F` RESET_CNT change.
4. **panda safety** — Toyota safety mode must recognize + permit the command
   (address, checksum/counter, torque-rate limits). Non-standard address or CAN FD →
   edit + reflash panda firmware (separate compiled component).
5. **Mixed-SecOC caution** — only the EPS is bypassed; other ECUs still enforce.
   Community (3b1b Sienna) saw deactivations from this. Don't sign/verify non-steering
   SecOC msgs with the dummy key in a way that faults.

First live actuation: empty lot, low speed, hands on wheel. Reflashed EPS no longer
applies factory sanity checks the same way.

---

## 9. Validation gate — NOTHING is confirmed until this passes on the device

Decodes are hypotheses. Confirm live, in order:

1. **Fingerprint converges**: boot the build; confirm it lands on
   `TOYOTA_COROLLA_TSS3` (single candidate, off MOCK), not a fall-through.
2. **CAN FD parse loads**: run opendbc's DBC/parser tests + `CANParser` against a real
   rlog in the checkout before flashing.
3. **carState vs ground truth on the car**: speed vs dash; steering angle sign
   (left = +) by turning the wheel; gear tracks the shifter (P/R/D); ACC flag flips
   with the cruise button; torque responds to hand force.
4. **Model renders**: lanes + path draw and look sane against the road, with no
   actuation.
5. Only after all pass → consider Phase 2 / CA2 work.

---

## 10. Dead ends (already ruled out — don't retry)

- Force `TOYOTA_COROLLA_TSS2` — non-SecOC 8-byte; required msgs (`0x1D2`,`0xB4`,
  `0x260`,`0x3BC`,`0x1C4`) absent; overlapping `0x25` is 32-byte not 8. Invalid.
- Force RAV4 Prime / Sienna — right SecOC family but classic CAN, not CAN FD; same
  missing-message failure.
- FW fingerprint — ECUs return zero UDS responses on tapped buses.
- `0x115`/`0x116` as the steering command — ruled out; they don't track the wheel
  even with LTA engaged (they're longitudinal/motor).
- More logs from the current harness to find the command — impossible; CA2 (pins 1/2)
  is not routed to the device. Only a physical CA2 tap can capture it.
- sunnylink / portal / env-var "force TSS3" — none deliver code; they only select
  platforms already built into the device.
- Pink/orange/blue/green re-pin to expose the command — those wires are CA1 & CAN
  (11/12); the command is on CA2, unreachable by any re-pin.

---

## 11. Fork / build / deploy (Claude-Code-in-IDE workflow)

opendbc is a submodule → carry changes as a **fork of opendbc** with the submodule
pointer bumped in the sunnypilot fork. In the IDE with sunnypilot/staging checked out,
Claude Code edits the real `opendbc_repo/` tree. Then:

- commit opendbc fork branch; bump `opendbc_repo` pointer in the sunnypilot fork;
  push both (submodule pointer MUST be committed or the device pulls stock opendbc).
- build **on the device**: install-by-URL (device clones + `scons` builds there) for
  the initial switch; SSH + `git fetch` + incremental `scons` for iteration.
- a changed/new DBC REQUIRES the on-device `scons` build; there is no paste-a-binary.
- use a dev/alpha build, not release (release gates in-dev cars harder).
- sunnylink: set to not require it while leaving connect working — a params/settings
  edit in the fork, independent of everything above.

---

## 12. Phase 2-LONG — openpilot longitudinal (independent of, and ahead of, CA2/lateral)

**Why this can happen before lateral:** the longitudinal command is **plaintext (no
SecOC)** and on **bus 0**, which the harness already taps. No CA2 tap, no EPS bypass,
no connector surgery. This is the practical next actuation step after Phase 1.

> Same status discipline: decoded from passive logs, **specified not confirmed**.
> The one thing passive logs cannot prove is that the powertrain/brake ECU will honor
> a comma-originated `0x13C` — that needs a careful bench/road test (see gate below).

### 12.1 The command — `0x13C` (316) ACC_CONTROL, 8B, 20 Hz, plaintext — decoded

```
BO_ 316 ACC_CONTROL: 8 XXX
  SG_ ACCEL_CMD       : 7|16@0-  (0.001,0)  [-3.0|1.5] "m/s^2"   # bytes 0-1, signed BE
  # byte 2 = 0xFF constant (type/malfunction bits — all-set this dataset)
  # byte 3 = 0x00 constant
  SG_ LON_ACTIVE      : 45|1@0+                     # byte4 bit 0x20: 0x10 base -> 0x30 when actively controlling
  # byte 5 = 0x00 constant
  SG_ DISTANCE_ACTIVE : 60|1@0+                     # byte6 bit 0x08: pulses while distance/standstill controller runs
  SG_ CHECKSUM        : 63|8@0+                     # byte 7
  # rate 20 Hz
```

- **ACCEL_CMD**: signed 16-bit BE, **0.001 m/s²/count** (exact legacy Toyota scale).
  Observed −1561..+2367 counts = −1.56..+2.37 m/s².
- **Checksum (byte 7)**: standard Toyota = `(sum(bytes[0..6]) + (addr&0xFF) +
  (addr>>8) + dlc) & 0xFF`, dlc=8, addr=0x13C. **Verified 4799/4799** across
  flag-transition segments. openpilot's existing Toyota checksum fn computes this —
  reuse it, no new code.
- **Flag bytes** decoded from highway ACC use: byte4 `0x10`→`0x30` = longitudinal
  actively controlling; byte6 `+0x08` = distance/standstill state (pulses in control).
  Map these onto Toyota's existing `ACC_CONTROL` sub-signals (`PERMIT_BRAKING`,
  `RELEASE_STANDSTILL`, `ACC_TYPE`, `DISTANCE`) — same message family.

### 12.2 Still to fill (both from logs likely already captured)

1. **Full stop → hold → resume** flag states. This dataset didn't catch a complete
   ACC standstill; `RELEASE_STANDSTILL` / braking-hold bits fully reveal there. Pull
   a stop-and-go ACC segment if available.
2. **Cruise button / ACC-state carState** (set/resume/cancel/main). Receive-side
   signal, needed so OP knows when it may engage and when the driver cancels. Find by
   watching which message changes on stalk presses (not yet mapped).

### 12.3 Build steps for Phase 2-LONG

1. Add `0x13C ACC_CONTROL` to the DBC (§12.1). Add the cruise-state message once
   mapped (§12.2 item 2).
2. `carcontroller.py`: build `0x13C` with `ACCEL_CMD` from the longitudinal planner,
   set `LON_ACTIVE` when controlling, compute the Toyota checksum. (Mirror the
   existing Toyota `create_accel_command` — the format matches.)
3. `carstate.py`: read ACC main/engaged + set-speed + buttons into `carState.cruiseState`.
4. `values.py`: enable longitudinal for the platform (`openpilotLongitudinalControl`
   / `experimentalLongitudinalAvailable` as appropriate); set accel limits.
5. **panda safety**: Toyota **longitudinal** safety hooks must permit `0x13C` tx and
   clamp `ACCEL_CMD` to the safety limits. Separate compiled component (reflash panda).

### 12.4 Recommended half-step: long shadow (read-only) before enabling tx

Between Phase 1 and enabling long, run with `0x13C` **known but not transmitted** and
log openpilot's *intended* accel next to the stock ACC's actual `0x13C.ACCEL_CMD`. If
OP's planned accel tracks what the car did, that validates command construction
(scale, checksum, flags) with **zero actuation risk** — the longitudinal analogue of
"watch the green lines." Only after that looks right, enable tx.

### 12.5 Phase 2-LONG validation gate (on device)

1. Shadow: OP intended accel ≈ stock `0x13C` accel over a drive (§12.4).
2. Confirm panda actually transmits on bus 0 AND the ECU honors a comma `0x13C`
   (the one thing logs can't prove — careful low-risk test; be ready to disengage).
3. First live long: open road, light traffic, foot near brake. Verify smooth accel
   and, separately, braking authority and a clean disengage on brake tap.

### 12.6 Ordering (owner's plan)

1. Fingerprint → 2. custom branch (sunnylink: likely pairs on a custom fork since
   pairing is device-identity based, but **unconfirmed** — verify after flash; not a
   blocker, settings are also on-device) → 3. camera + green lines, no lat/long →
   4. long enabled (this section; reachable on current hardware) → 5/6. lat and
   lat+long (blocked on CA2 tap, §8).

(Other TSS/Chestnut vehicle reuse: deferred per owner. Note only that `ACC_CONTROL`
here is standard Toyota format, so §12 should port with minimal change later.)
