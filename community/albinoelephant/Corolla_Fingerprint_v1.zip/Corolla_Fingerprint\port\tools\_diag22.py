import sys, glob
from openpilot.tools.lib.logreader import LogReader
from collections import Counter
c=Counter(); lat=0; eng=0; cruise=0; cs=0
for s in sorted(glob.glob("/data/media/0/realdata/00000022--6299eff795--*/rlog.zst")):
    for m in LogReader(s):
        w=m.which(); c[w]+=1
        if w=="carControl":
            if m.carControl.latActive: lat+=1
            if m.carControl.enabled: eng+=1
        elif w=="carState":
            cs+=1
            if m.carState.cruiseState.enabled: cruise+=1
print("carControl:", c.get("carControl"), "carState:", c.get("carState"), "modelV2:", c.get("modelV2"))
print("cc.enabled:", eng, "cc.latActive:", lat, "cruiseEnabled(cs):", cruise, "of", cs)
print("types:", dict(c.most_common(6)))
