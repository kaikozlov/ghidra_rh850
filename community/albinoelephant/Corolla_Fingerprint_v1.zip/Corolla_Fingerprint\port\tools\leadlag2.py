#!/usr/bin/env python3
"""Clean lead/lag: which angle-tracking field LEADS the measured angle (=command)
vs lock-step (=feedback). Uses nearest-neighbour (no tolerance drop). Big LTA
turns => strong signal."""
import sys, bisect, math
from collections import defaultdict

CANDS=[(0,0x1a0,11),(1,0x371,16),(1,0x81,16),(1,0x90,12),(1,0x8A,18)]

def s16be(d,i):
    if i+1>=len(d): return None
    v=(d[i]<<8)|d[i+1]; return v-0x10000 if v>=0x8000 else v

def main(paths):
    from openpilot.tools.lib.logreader import LogReader as OP
    from opendbc.car.logreader import LogReader as CAN
    ta=[];va=[];t0=None
    for p in paths:
        for m in OP(p):
            if m.which()=="carState":
                t=m.logMonoTime/1e9
                if t0 is None:t0=t
                ta.append(t-t0);va.append(m.carState.steeringAngleDeg)
    def A(tq):
        i=bisect.bisect_left(ta,tq)
        if i<=0:return va[0]
        if i>=len(ta):return va[-1]
        return va[i] if abs(ta[i]-tq)<abs(ta[i-1]-tq) else va[i-1]
    frames=defaultdict(list);t0b=None
    want={a for _,a,_ in CANDS}
    for p in paths:
        for m in CAN(p,only_union_types=True):
            if m.which()!="can":continue
            t=m.logMonoTime/1e9
            if t0b is None:t0b=t
            for c in m.can:
                if c.address in want and c.src in (0,1,2):
                    frames[(c.src,c.address)].append((t-t0b,bytes(c.dat)))
    def corr(xs,ys):
        n=len(xs)
        if n<50:return float('nan')
        mx=sum(xs)/n;my=sum(ys)/n
        sxx=sum((x-mx)**2 for x in xs);syy=sum((y-my)**2 for y in ys)
        if sxx<=0 or syy<=0:return float('nan')
        return sum((x-mx)*(y-my) for x,y in zip(xs,ys))/math.sqrt(sxx*syy)
    print("field                best_lag(ms)  r     interpretation")
    for bus,addr,off in CANDS:
        fr=frames.get((bus,addr))
        if not fr:
            print(f"bus{bus} {addr:#07x} b{off}: no frames"); continue
        best=(None,0.0)
        for lag_ms in range(-500,501,50):
            lag=lag_ms/1000.0
            xs=[];ys=[]
            for t,d in fr:
                v=s16be(d,off)
                if v is None:continue
                xs.append(v);ys.append(A(t+lag))
            r=corr(xs,ys)
            if not math.isnan(r) and abs(r)>abs(best[1]):best=(lag_ms,r)
        if best[0] is None:
            print(f"bus{bus} {addr:#07x} b{off}: NaN"); continue
        interp="LEADS => COMMAND" if best[0]>=100 else ("lock-step => feedback" if abs(best[0])<100 else "lags")
        print(f"bus{bus} {addr:#07x} b{off:>2}   {best[0]:+5d}     {best[1]:+.2f}  {interp}")
    return 0

if __name__=="__main__":
    sys.exit(main(sys.argv[1:]))
