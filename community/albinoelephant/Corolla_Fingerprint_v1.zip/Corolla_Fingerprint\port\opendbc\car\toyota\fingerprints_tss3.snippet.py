# ############################################################################
# NOT APPLIED, AND THE DICT BELOW IS EMPTY ON PURPOSE.
#
# This is the ONE piece of the port that is not in sunnypilot-tss3.patch,
# because it is the one piece that cannot be written without data from the car.
# It is OPTIONAL: the platform selector ("Toyota Corolla 2023" in Settings >
# Vehicle) already forces the platform without it. This file only adds
# AUTOMATIC fingerprinting, so the car is recognised without selecting it.
# ############################################################################

# ============================================================================
# INSERT INTO: opendbc/car/toyota/fingerprints.py
# Verified against commaai/opendbc @ 3e92d11 (2026-08-28).
#
# HEADS UP: at 3e92d11 the Toyota fingerprints.py has NO `FINGERPRINTS` dict at
# all -- only FW_VERSIONS. Only body/ and gm/ still define one. So this is a NEW
# module-level attribute, not an append.
#
# It still works: opendbc/car/fingerprints.py does
#     _FINGERPRINTS = get_interface_attr('FINGERPRINTS', combine_brands=True,
#                                        ignore_none=True)
# which picks the attribute up from any brand that defines it. But you are the
# first Toyota entry, so nothing else in the brand will look like this.
#
# THE DICT ITSELF CANNOT BE GUESSED. It must be the exact {addr: len} set the
# car emits on bus 0 (~142 messages). Generate it:
#     python port/tools/gen_fingerprint.py <rlog|route> --bus 0
#
# FW_VERSIONS is deliberately NOT populated: the ECUs return zero UDS responses
# on the tapped buses, so FW fingerprinting is impossible on this car.
# ============================================================================

from opendbc.car.toyota.values import CAR

FINGERPRINTS = {
  CAR.TOYOTA_COROLLA_TSS3: [{
    # <<< PASTE GENERATED {addr: len} DICT HERE -- see gen_fingerprint.py >>>
  }],
}
